"""YAML → DocumentConfig parser.

Supported element kinds
-----------------------
paragraph        LLM-generated prose (finetuned or cot mode)
paragraph_file   Verbatim text from a .txt file in the ZIP
table            Single CSV rendered as a bordered table
multi_table      Multiple CSVs rendered sequentially (each with its own caption)
image            PNG/JPG figure — either a direct ``img_path``, or JSON-driven:
                     kind: image
                     para_input_from_json_path: "Harmonic.Harmonic_Result_Summary.{name}"
                 which resolves every nested ``*figure_id*`` value found under
                 that bundle.json path against ``tables/figure_name.csv``
                 (matched on "Updated Figure Number") to get the image file
                 ("Name") and caption ("Caption"). If the JSON node holds
                 several figure ids (including inside a list), all of them
                 are placed as separate figures, in order. See ImageElement
                 in models.py for full details.
math             Native Word OMML equation from a .docx snippet

Repeat block — three instance-source modes
------------------------------------------

1. **Inline** (fully static)::

     - kind: repeat
       instances:
         - name: X Direction
           number: "6"
           vars: { suffix: _x }

2. **instances_from_json** — list of instance dicts stored in bundle.json::

     - kind: repeat
       instances_from_json: harmonic_repeat_instances

   ``bundle.json["harmonic_repeat_instances"]`` must be a list of
   ``{name, number, vars}`` dicts (same shape as inline instances).

3. **instances_keys_from_json** — derive instances from the *keys* of a
   nested dict in bundle.json.  Use dot-notation to navigate::

     - kind: repeat
       instances_keys_from_json: "Static.Static_loads"
       number_start: 1          # optional, default 1

   This reads ``bundle.json["Static"]["Static_loads"]``, takes its keys
   (e.g. "Static Structural", "Static Structural 2", …), and creates one
   instance per key.  ``{name}`` = key string.  ``{instance_name}`` = same
   (URL-safe copy for use in further JSON lookups).  ``{number}`` = auto
   counter starting at ``number_start``.

4. **instances_list_from_json** — derive instances from a *list* stored at
   a (possibly dynamic) path in bundle.json.  Supports ``{instance_name}``
   in the path so inner repeats can resolve per-outer-instance lists::

     - kind: repeat
       instances_list_from_json: "Static.Static_result_details.{instance_name}"

   Each list item becomes one instance.  If the item is a dict it is used
   directly; otherwise it is wrapped as ``{value: item}``.
   ``{name}`` = ``str(index+1)``, ``{index}`` = 0-based index.

The four sources are merged: inline → from_json → keys → list (all that are
present).  Typically only one is used per repeat block.

Nested repeats — {name} vs {s_same}
------------------------------------
``{name}`` always means "this repeat level's own instance name" and gets
reset at every nested ``kind: repeat``. When an inner repeat needs to reach
back into a bundle.json path that also depends on an OUTER repeat's instance
(e.g. ``Solution_Combination.{outer}.loads.{inner}``), use ``{s_same}``:
it is set once, by the first (outermost) repeat in a branch, and every
deeper repeat inherits it unchanged even though its own ``{name}`` keeps
changing. Static (non-repeat) sections in between simply pass it through.

Example — "Solution Combination" (5) → one sub-section per flange (5.1, 5.2, …)
→ "Loads" (5.1.1, static) → one sub-section per load combination (5.1.1.1, …)::

    - kind: repeat
      instances_keys_from_json: "Solution_Combination"     # -> {name}/{s_same} = flange key
      template:
        Section_name: "{name}"
        sections:
          - number: "1"
            Section_name: Loads
            sections:
              - kind: repeat
                instances_keys_from_json: "Solution_Combination.{s_same}.loads"  # {name} = combo key
                template:
                  Section_name: "{name}"
                  elements:
                    - kind: image
                      para_input_from_json_path: "Solution_Combination.{s_same}.loads.{name}"
"""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path
from typing import Any

import yaml

from docgen.models import (
    DocumentConfig,
    FileParagraphElement,
    ImageElement,
    MathBlockElement,
    MultiTableElement,
    ParagraphElement,
    PatternRepeatElement,
    SectionNode,
    TableElement,
)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _sub(value: Any, vars_: dict[str, str]) -> Any:
    """Recursively substitute {var} placeholders in strings inside any structure.

    A nested ``kind: repeat`` block is left untouched (deep-copied verbatim):
    it resolves its own ``{name}``/``{s_same}``/etc. later, with its own
    per-instance vars, when THAT repeat expands. Substituting here — while
    walking the enclosing (outer) repeat's template — would freeze the inner
    repeat's placeholders to the outer instance's values before the inner
    repeat ever gets a chance to run.
    """
    if isinstance(value, str):
        for k, v in vars_.items():
            value = value.replace(f"{{{k}}}", v)
        return value
    if isinstance(value, dict):
        if str(value.get("kind") or "").lower() == "repeat":
            return copy.deepcopy(value)
        return {k: _sub(v, vars_) for k, v in value.items()}
    if isinstance(value, list):
        return [_sub(item, vars_) for item in value]
    return value


def _resolve_json_path(data: dict[str, Any], path: str, vars_: dict[str, str] | None = None) -> Any:
    """Navigate a dot-separated path through nested dicts/lists in bundle.json.

    Supports ``{var}`` substitution in path segments before traversal.
    E.g. ``"Static.Static_result_details.{instance_name}"``
    """
    if vars_:
        path = _sub(path, vars_)
    parts = path.split(".")
    node: Any = data
    for part in parts:
        if isinstance(node, dict):
            # Try exact key first, then case-insensitive
            if part in node:
                node = node[part]
            else:
                lp = part.lower()
                found = next((v for k, v in node.items() if k.lower() == lp), _MISSING)
                if found is _MISSING:
                    raise KeyError(f"Key {part!r} not found at this level of bundle.json path {path!r}")
                node = found
        elif isinstance(node, list):
            try:
                node = node[int(part)]
            except (ValueError, IndexError) as e:
                raise KeyError(f"Cannot index list with {part!r} in path {path!r}") from e
        else:
            raise KeyError(f"Cannot traverse into {type(node).__name__} at {part!r} in path {path!r}")
    return node


_MISSING = object()


def _safe_id(s: str) -> str:
    """Make a JSON key safe for use as a placeholder variable value."""
    return re.sub(r"[^A-Za-z0-9_]", "_", s).strip("_")


# ─────────────────────────────────────────────────────────────────────────────
# Element parsers
# ─────────────────────────────────────────────────────────────────────────────

def _parse_table_entry(raw: dict[str, Any]) -> TableElement:
    return TableElement(
        csv_path=str(raw.get("csv_path") or raw.get("csv") or ""),
        caption=str(
            raw.get("table_name") or raw.get("tbale_name")
            or raw.get("caption") or "Table"
        ),
    )


def _parse_element(raw: dict[str, Any], outer_vars: dict[str, str] | None = None) -> Any:
    kind = (raw.get("kind") or raw.get("type") or "").lower()
    # Substitute outer repeat vars into the element dict before parsing
    if outer_vars:
        raw = _sub(dict(raw), outer_vars)

    if not kind:
        if raw.get("text_path") or raw.get("para_text_file") or raw.get("text_file"):
            kind = "paragraph_file"
        elif raw.get("para_prompt") is not None or raw.get("prompt") is not None:
            kind = "paragraph"
        elif raw.get("tables") and isinstance(raw["tables"], list):
            kind = "multi_table"
        elif raw.get("csv_path") or raw.get("csv"):
            kind = "table"
        elif raw.get("img_path"):
            kind = "image"
        elif (raw.get("formula_docx") or raw.get("math_docx")
              or raw.get("derivation_docx") or raw.get("derivation_docx_paths")):
            kind = "math"

    if kind in ("paragraph_file", "para_from_file", "text_file", "file_paragraph"):
        return FileParagraphElement(
            text_path=str(
                raw.get("text_path") or raw.get("para_text_file")
                or raw.get("file_path") or raw.get("path") or ""
            ),
        )

    if kind in ("paragraph", "para", "para_element"):
        cot_raw = raw.get("cot_examples") or []
        if not isinstance(cot_raw, list):
            cot_raw = []
        return ParagraphElement(
            prompt=str(raw.get("para_prompt") or raw.get("prompt") or ""),
            json_key=str(raw.get("para_input_from_json") or raw.get("json_key") or ""),
            json_path=str(raw.get("para_input_from_json_path") or raw.get("json_path") or ""),
            mode=str(raw.get("mode") or "finetuned").strip().lower(),
            cot_examples=[dict(ex) for ex in cot_raw if isinstance(ex, dict)],
        )

    if kind in ("multi_table", "tables", "table_group"):
        tables_raw = raw.get("tables") or []
        if not isinstance(tables_raw, list):
            tables_raw = []
        return MultiTableElement(
            tables=[_parse_table_entry(t) for t in tables_raw if isinstance(t, dict)]
        )

    if kind in ("table", "table_element"):
        return _parse_table_entry(raw)

    if kind in ("image", "img", "img_element"):
        return ImageElement(
            img_path=str(raw.get("img_path") or raw.get("path") or ""),
            caption=str(raw.get("img_name") or raw.get("caption") or "Figure"),
            json_path=str(
                raw.get("para_input_from_json_path") or raw.get("json_path") or ""
            ),
        )

    if kind in ("pattern_repeat", "pattern_match"):
        return PatternRepeatElement(
            img_pattern=str(raw.get("img_pattern") or ""),
            csv_pattern=str(raw.get("csv_pattern") or ""),
            img_prefix=str(raw.get("img_prefix") or raw.get("image_prefix") or ""),
            csv_prefix=str(raw.get("csv_prefix") or raw.get("table_prefix") or ""),
            caption=str(raw.get("caption") or ""),
            caption_parts=list(raw.get("caption_parts") or []),
            caption_template=str(raw.get("caption_template") or ""),
        )

    if kind in ("math", "formula", "equation", "derivation"):
        docx_path = str(
            raw.get("docx_path") or raw.get("formula_docx") or raw.get("math_docx") or ""
        )
        deriv_raw = (
            raw.get("derivation_docx") or raw.get("derivation_docx_paths")
            or raw.get("derivations")
        )
        deriv_paths: list[str] = []
        if isinstance(deriv_raw, list):
            deriv_paths = [str(x).strip() for x in deriv_raw if str(x).strip()]
        elif isinstance(deriv_raw, str) and deriv_raw.strip():
            deriv_paths = [deriv_raw.strip()]
        return MathBlockElement(
            docx_path=docx_path,
            derivation_docx_paths=deriv_paths,
            caption=str(raw.get("caption") or raw.get("math_name") or ""),
        )

    raise ValueError(f"Unknown element kind: {raw!r}")


def _collect_elements(block: dict[str, Any], outer_vars: dict[str, str] | None = None) -> list[Any]:
    out: list[Any] = []
    for key, val in block.items():
        lk = key.lower()
        if lk in ("elements", "blocks", "content"):
            if isinstance(val, list):
                for item in val:
                    if isinstance(item, dict):
                        out.append(_parse_element(item, outer_vars=outer_vars))
            continue
        if isinstance(val, dict) and ("kind" in val or "type" in val):
            out.append(_parse_element(val))
        elif isinstance(val, dict) and ("para_prompt" in val or lk == "para_element"):
            out.append(ParagraphElement(
                prompt=str(val.get("para_prompt") or val.get("prompt") or ""),
                json_key=str(val.get("para_input_from_json") or val.get("json_key") or ""),
            ))
        elif isinstance(val, dict) and ("tables" in val or lk == "multi_table"):
            out.append(_parse_element({"kind": "multi_table", **val}))
        elif isinstance(val, dict) and ("csv_path" in val or lk == "table_element"):
            out.append(TableElement(
                csv_path=str(val.get("csv_path") or val.get("csv") or ""),
                caption=str(val.get("table_name") or val.get("tbale_name") or val.get("caption") or "Table"),
            ))
        elif isinstance(val, dict) and ("img_path" in val or lk == "img_element"):
            out.append(ImageElement(
                img_path=str(val.get("img_path") or val.get("path") or ""),
                caption=str(val.get("img_name") or val.get("caption") or "Figure"),
                json_path=str(
                    val.get("para_input_from_json_path") or val.get("json_path") or ""
                ),
            ))
        elif isinstance(val, dict) and (
            val.get("text_path") or val.get("para_text_file") or val.get("text_file")
        ):
            out.append(FileParagraphElement(
                text_path=str(
                    val.get("text_path") or val.get("para_text_file")
                    or val.get("text_file") or val.get("file_path") or ""
                ),
            ))
    return out


# ─────────────────────────────────────────────────────────────────────────────
# Repeat instance builders
# ─────────────────────────────────────────────────────────────────────────────

def _instances_from_keys(
    bundle_data: dict[str, Any],
    path: str,
    number_start: int = 1,
    extra_vars: dict[str, str] | None = None,
) -> list[dict]:
    """Build instances from the *keys* of a dict at ``path`` in bundle.json.

    Each key becomes one instance::

        name           = key string  (e.g. "Static Structural 2")
        instance_name  = safe-id version (e.g. "Static_Structural_2")
        number         = str(number_start + index)
        vars           = extra_vars merged with name/instance_name
    """
    target = _resolve_json_path(bundle_data, path, extra_vars)
    if not isinstance(target, dict):
        raise ValueError(
            f"instances_keys_from_json: path {path!r} must point to a dict in bundle.json, "
            f"got {type(target).__name__}"
        )
    instances = []
    for i, key in enumerate(target.keys()):
        safe = _safe_id(key)
        vars_ = dict(extra_vars or {})
        vars_.update({"instance_name": safe, "instance_key": key})
        instances.append({
            "name": key,
            "number": str(number_start + i),
            "vars": vars_,
        })
    return instances


def _instances_from_list(
    bundle_data: dict[str, Any],
    path: str,
    outer_vars: dict[str, str] | None = None,
) -> list[dict]:
    """Build instances from a *list* at ``path`` (which may contain placeholders).

    Each list item becomes one instance::

        name   = str(index + 1)
        index  = str(index)   (0-based)
        vars   = outer_vars + all string fields from the item dict (if dict)
                 + raw_value (str of item) if item is not a dict

    This is used for inner repeats where the list length is not known in advance.
    """
    target = _resolve_json_path(bundle_data, path, outer_vars)
    if not isinstance(target, list):
        raise ValueError(
            f"instances_list_from_json: path {path!r} must point to a list in bundle.json, "
            f"got {type(target).__name__}"
        )
    instances = []
    for i, item in enumerate(target):
        vars_ = dict(outer_vars or {})
        vars_["index"] = str(i)
        vars_["index_1"] = str(i + 1)  # 1-based for display
        if isinstance(item, dict):
            # Flatten all scalar fields of the item as vars
            for k, v in item.items():
                if isinstance(v, (str, int, float, bool)):
                    vars_[str(k)] = str(v)
            item_name = str(item.get("name") or item.get("label") or str(i + 1))
        else:
            item_name = str(i + 1)
            vars_["raw_value"] = str(item)
        instances.append({
            "name": item_name,
            "number": str(i + 1),
            "vars": vars_,
        })
    return instances


# ─────────────────────────────────────────────────────────────────────────────
# Repeat expander
# ─────────────────────────────────────────────────────────────────────────────

def _expand_repeat(
    repeat_block: dict[str, Any],
    parent_section_id: str,
    bundle_data: dict[str, Any] | None = None,
    outer_vars: dict[str, str] | None = None,
) -> list[SectionNode]:
    """Expand a ``kind: repeat`` block into a list of concrete SectionNodes.

    Instance sources (all merged in order):
      instances                   – inline list in YAML
      instances_from_json         – list of {name,number,vars} dicts in bundle.json
      instances_keys_from_json    – keys of a dict at a dot-path in bundle.json
      instances_list_from_json    – items of a list at a dot-path in bundle.json
                                    (path may contain {instance_name} etc. from outer repeat)
    """
    outer_vars = outer_vars or {}
    instances: list[dict] = list(repeat_block.get("instances") or [])

    if bundle_data:
        # ── instances_from_json ──
        key1 = (repeat_block.get("instances_from_json") or "").strip()
        if key1:
            raw = bundle_data.get(key1)
            if isinstance(raw, list):
                instances += [i for i in raw if isinstance(i, dict)]
            elif raw is not None:
                raise ValueError(
                    f"instances_from_json={key1!r} must be a list, got {type(raw).__name__}"
                )

        # ── instances_keys_from_json ──
        key2 = (repeat_block.get("instances_keys_from_json") or "").strip()
        if key2:
            key2_resolved = _sub(key2, outer_vars)
            n_start = int(repeat_block.get("number_start") or 1)
            instances += _instances_from_keys(bundle_data, key2_resolved, n_start, outer_vars)

        # ── instances_list_from_json ──
        key3 = (repeat_block.get("instances_list_from_json") or "").strip()
        if key3:
            instances += _instances_from_list(bundle_data, key3, outer_vars)

    template = repeat_block.get("template") or {}
    if not instances or not template:
        return []

    out: list[SectionNode] = []
    for inst in instances:
        if not isinstance(inst, dict):
            continue

        inst_name   = str(inst.get("name") or "")
        inst_number = str(inst.get("number") or "")
        inst_vars   = dict(inst.get("vars") or {})

        # Full section id
        if parent_section_id and inst_number:
            section_id = f"{parent_section_id}.{inst_number}"
        elif inst_number:
            section_id = inst_number
        else:
            section_id = parent_section_id

        # Merged variable map (outer vars overridden by instance vars)
        vars_ = {**outer_vars, **inst_vars,
                 "name": inst_name,
                 "number": inst_number,
                 "section_id": section_id,
                 "instance_name": _safe_id(inst_name),
                 "instance_key": inst_name}

        # {s_same} = the OUTERMOST repeat's own {name} in this branch, frozen the
        # first time a repeat sets it and inherited unchanged by every deeper
        # nested repeat (whose own {name} keeps changing at each level).
        # Lets an inner repeat's json path reach back to an ancestor repeat's
        # instance key, e.g. "Solution_Combination.{s_same}.loads.{name}"
        # where {s_same}="Combined_Load_Inlet_Flange" and {name}="Combination 1".
        # {s_instance_name} is the safe-id counterpart of {s_same}, for use in
        # file paths (csv_path/img_path) the same way {instance_name} is used
        # for the current level's own name.
        vars_.setdefault("s_same", inst_name)
        vars_.setdefault("s_instance_name", _safe_id(inst_name))

        expanded = _sub(copy.deepcopy(template), vars_)

        if "Section_name" not in expanded and inst_name:
            expanded["Section_name"] = inst_name
        expanded["number"] = section_id

        node = _parse_section_tree(
            expanded, [section_id],
            bundle_data=bundle_data,
            outer_vars=vars_,
        )
        out.append(node)

    return out


# ─────────────────────────────────────────────────────────────────────────────
# Section tree parser
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_section_name(
    name: str,
    bundle_data: dict[str, Any] | None,
    outer_vars: dict[str, str] | None,
) -> str:
    """Resolve ``{placeholders}`` in a Section_name string.

    Resolution order for each ``{token}``:
    1. ``outer_vars``  (instance_name, name, index_1 … from repeat)
    2. dot-path into bundle_data  (e.g. ``{fem_model.component_name}``)
    3. top-level key in bundle_data  (e.g. ``{component_name}``)
    4. left as-is if not found
    """
    import re
    if "{" not in name:
        return name

    # Build a combined var dict: outer_vars first, then bundle top-level scalars
    vars_: dict[str, str] = {}
    if bundle_data:
        for k, v in bundle_data.items():
            if isinstance(v, (str, int, float, bool)):
                vars_[k] = str(v)
    if outer_vars:
        vars_.update(outer_vars)   # outer_vars win

    def replace_token(m: re.Match) -> str:
        token = m.group(1)
        if token in vars_:
            return vars_[token]
        # try dot-path
        if bundle_data and "." in token:
            try:
                val = _resolve_json_path(bundle_data, token, vars_)
                if not isinstance(val, (dict, list)):
                    return str(val)
            except (KeyError, ValueError):
                pass
        # try dot-path even without dot (e.g. nested key)
        if bundle_data:
            try:
                val = _resolve_json_path(bundle_data, token, vars_)
                if not isinstance(val, (dict, list)):
                    return str(val)
            except (KeyError, ValueError):
                pass
        return m.group(0)   # leave unchanged

    return re.sub(r"\{([^}]+)\}", replace_token, name)


def _parse_section_tree(
    raw: dict[str, Any],
    path_ids: list[str],
    bundle_data: dict[str, Any] | None = None,
    outer_vars: dict[str, str] | None = None,
) -> SectionNode:
    # ── Resolve json_vars: map var_name → JSON dot-path → string value ──────
    json_vars_raw: dict[str, str] = {}
    raw_json_vars = raw.get("json_vars") or {}
    if isinstance(raw_json_vars, dict) and bundle_data:
        for var_name, dot_path in raw_json_vars.items():
            dot_path_str = str(dot_path)
            # substitute any outer repeat vars in the path itself
            if outer_vars:
                dot_path_str = _sub(dot_path_str, outer_vars)
            try:
                val = _resolve_json_path(bundle_data, dot_path_str)
                if not isinstance(val, (dict, list)):
                    json_vars_raw[var_name] = str(val)
            except (KeyError, ValueError):
                pass   # silently skip unresolved paths

    # Merge: json_vars < outer_vars (repeat vars always win)
    merged_vars: dict[str, str] = {**json_vars_raw, **(outer_vars or {})}

    name = _resolve_section_name(
        str(
            raw.get("Section_name") or raw.get("name")
            or raw.get("section_name") or "Section"
        ),
        bundle_data,
        merged_vars,
    )

    # ── BUG FIX 1: section_id resolution ────────────────────────────────────
    # path_ids already contains the full ancestry (e.g. ["3", "1"] for 3.1).
    # explicit number values like "1", "2" in templates are RELATIVE — they
    # must be joined with path_ids, not used bare.
    # Only use explicit_id directly when it is already a full dotted path
    # (e.g. the repeat expander writes the fully-qualified id into "number").
    # ── section_id for THIS node ────────────────────────────────────────────
    # path_ids is the fully-qualified path passed from the parent.
    # e.g. for section 3.1, parent passes path_ids=["3.1"].
    # The node's own "number" field in the YAML is a RELATIVE counter ("1","2")
    # for template children, or already fully-qualified when written by the
    # repeat expander (e.g. "3.1").
    # Rule: if the caller already put the full id in path_ids (len==1 and
    # contains a dot, OR len==1 matching explicit_id), use path_ids directly.
    # Otherwise join path_ids to build the id.
    explicit_id = raw.get("number") or raw.get("id") or raw.get("section_id")
    if path_ids and len(path_ids) == 1 and "." in path_ids[0]:
        # Caller passed a fully-qualified id (e.g. from repeat expander)
        section_id = path_ids[0]
    elif explicit_id and "." in str(explicit_id):
        # Explicit dotted id in the YAML — use as-is
        section_id = str(explicit_id)
    elif path_ids:
        section_id = ".".join(path_ids)
    else:
        section_id = str(explicit_id) if explicit_id else "1"

    elements: list[Any] = []
    if "elements" in raw and isinstance(raw["elements"], list):
        for item in raw["elements"]:
            if isinstance(item, dict):
                elements.append(_parse_element(item, outer_vars=merged_vars))
    else:
        elements.extend(_collect_elements(raw, outer_vars=merged_vars))

    children: list[SectionNode] = []
    subs = raw.get("sections") or raw.get("children") or []

    if isinstance(subs, list):
        child_counter = 1
        for child in subs:
            if not isinstance(child, dict):
                continue
            child_kind = str(child.get("kind") or "").lower()
            if child_kind == "repeat":
                # Pass fully-qualified section_id so inner repeat builds
                # e.g. "3.1.4.1", "3.1.4.2" not bare "1", "2"
                expanded = _expand_repeat(
                    child, section_id,
                    bundle_data=bundle_data,
                    outer_vars=outer_vars,
                )
                children.extend(expanded)
                child_counter += len(expanded)
                continue

            # Child path: always prefix with current section_id so that
            # a child with number="1" inside section "3.1" gets "3.1.1"
            raw_cid = str(child.get("number") or child.get("id") or str(child_counter))
            if "." in raw_cid:
                child_path = [raw_cid]          # already fully-qualified
            else:
                child_path = [f"{section_id}.{raw_cid}"]   # build full id

            children.append(_parse_section_tree(
                child, child_path,
                bundle_data=bundle_data,
                outer_vars=outer_vars,
            ))
            child_counter += 1

    elif isinstance(subs, dict):
        for i, (k, child) in enumerate(subs.items(), start=1):
            if not isinstance(child, dict):
                continue
            raw_cid = str(child.get("number") or child.get("id")
                          or k.replace("section", "").strip("_") or str(i))
            child_path = [raw_cid] if "." in raw_cid else [f"{section_id}.{raw_cid}"]
            children.append(_parse_section_tree(
                child, child_path,
                bundle_data=bundle_data,
                outer_vars=merged_vars,
            ))

    return SectionNode(section_id=section_id, name=name, elements=elements, children=children, json_vars=json_vars_raw)


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def load_document_config(
    yaml_path: Path,
    bundle_data: dict[str, Any] | None = None,
) -> DocumentConfig:
    """Parse a YAML structure file into a DocumentConfig.

    Parameters
    ----------
    yaml_path:
        Path to the YAML structure template.
    bundle_data:
        The parsed bundle.json dict.  Required when the YAML uses any
        ``instances_*_from_json`` in repeat blocks.
    """
    with open(yaml_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError("YAML root must be a mapping.")

    title = str(cfg.get("title") or cfg.get("document_title") or "Generated Document")
    roots: list[SectionNode] = []

    if "sections" in cfg:
        sec = cfg["sections"]
        if isinstance(sec, list):
            for i, block in enumerate(sec, start=1):
                if isinstance(block, dict):
                    sid = str(block.get("number") or block.get("id") or str(i))
                    roots.append(_parse_section_tree(block, [sid], bundle_data=bundle_data))
        elif isinstance(sec, dict):
            for i, (k, block) in enumerate(sec.items(), start=1):
                if not isinstance(block, dict):
                    continue
                sid = str(block.get("number") or block.get("id")
                          or k.replace("section", "").strip("_") or str(i))
                roots.append(_parse_section_tree(block, [sid], bundle_data=bundle_data))
    else:
        def _section_sort_key(x: str) -> tuple[int, str]:
            m = re.search(r"(\d+)$", str(x))
            return (int(m.group(1)) if m else 0, str(x))

        for k in sorted(cfg.keys(), key=_section_sort_key):
            if not str(k).lower().startswith("section"):
                continue
            block = cfg[k]
            if not isinstance(block, dict):
                continue
            sid = str(block.get("number") or block.get("id")
                      or "".join(filter(str.isdigit, str(k))) or "1")
            if not sid or sid == "None":
                sid = "1"
            roots.append(_parse_section_tree(block, [sid], bundle_data=bundle_data))

    if not roots:
        raise ValueError("No sections found in YAML.")

    return DocumentConfig(title=title, root_sections=roots)

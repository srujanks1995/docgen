"""docgen LLM backend — switchable between a remote vLLM host and a local model.

Backend toggle (.env)
---------------------
llm_mode=vllm_host            call a remote vLLM server (OpenAI-compatible /v1 API)
llm_mode=local_hugging_path   load model_path (+ optional adapter_path) with
                              transformers on this machine   (default if unset)

Two generation modes (per paragraph, set in the YAML)
-----------------------------------------------------
finetuned  (default)
    Direct generation.  local_hugging_path sends the legacy ``[INST] … [/INST]``
    prompt the LoRA adapter was trained on; vllm_host sends the same content as
    chat messages (system + user) because vLLM applies the model's chat template.

cot
    Chain-of-Thought: few-shot question/thought/answer examples from the YAML,
    then the live question; the model answers ``Thought: … Answer: …`` and only
    the Answer is written to the document.

Environment (.env)
------------------
llm_mode=vllm_host | local_hugging_path

# vllm_host
vllm_host=https://<host>/v1          # base URL; "/v1" is appended if missing
vllm_model_name=                      # blank = auto-detect from GET /v1/models
vllm_api_key=EMPTY
vllm_verify_ssl=true                  # false for self-signed / internal certs
vllm_timeout=300                      # seconds per request
vllm_max_retries=2
vllm_max_tokens=2048                  # reasoning models spend tokens "thinking"
vllm_reasoning_effort=                # optional: low | medium | high (gpt-oss)

# local_hugging_path
model_path=<HF model dir>
adapter_path=<LoRA adapter dir>       # optional
cuda_device=cuda:0

# shared sampling
DOCGEN_MAX_NEW_TOKENS / DOCGEN_TEMPERATURE / DOCGEN_TOP_P
"""
from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


# ─────────────────────────────────────────────────────────────────────────────
# Backend selection / env helpers
# ─────────────────────────────────────────────────────────────────────────────

BACKEND_VLLM = "vllm_host"
BACKEND_LOCAL = "local_hugging_path"

_BACKEND_ALIASES: dict[str, str] = {
    "vllm_host": BACKEND_VLLM,
    "vllm": BACKEND_VLLM,
    "host": BACKEND_VLLM,
    "remote": BACKEND_VLLM,
    "local_hugging_path": BACKEND_LOCAL,
    "local_huggingface_path": BACKEND_LOCAL,
    "local": BACKEND_LOCAL,
    "huggingface": BACKEND_LOCAL,
    "hf": BACKEND_LOCAL,
}

_TRUE = {"1", "true", "yes", "on", "y"}
_FALSE = {"0", "false", "no", "off", "n"}


class LLMConfigError(RuntimeError):
    """Raised when the .env LLM configuration is invalid or unusable."""


def _env(name: str, default: str = "") -> str:
    """Read an env var; tries ``name`` then ``NAME`` (Linux is case-sensitive)."""
    val = os.environ.get(name)
    if val is None:
        val = os.environ.get(name.upper())
    return (val if val is not None else default).strip()


def _env_bool(name: str, default: bool) -> bool:
    raw = _env(name).lower()
    if raw in _TRUE:
        return True
    if raw in _FALSE:
        return False
    return default


def get_backend() -> str:
    """Resolve ``llm_mode`` to BACKEND_VLLM or BACKEND_LOCAL (default: local)."""
    raw = _env("llm_mode").lower()
    if not raw:
        return BACKEND_LOCAL
    backend = _BACKEND_ALIASES.get(raw)
    if backend is None:
        raise LLMConfigError(
            f"Invalid llm_mode={raw!r}. Use 'vllm_host' or 'local_hugging_path'."
        )
    return backend


def _normalize_base_url(host: str) -> str:
    """Validate the vLLM URL and append ``/v1`` when no path was given."""
    host = host.strip().strip("\"'").rstrip("/")
    parsed = urlparse(host)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise LLMConfigError(
            f"vllm_host must be a full URL such as https://host/v1 (got {host!r})."
        )
    if parsed.path in ("", "/"):
        host += "/v1"
    return host


def _vllm_max_tokens() -> int:
    return int(_env("vllm_max_tokens") or 2048)


def validate_config() -> list[str]:
    """Return a list of configuration problems (empty list == OK)."""
    try:
        backend = get_backend()
    except LLMConfigError as exc:
        return [str(exc)]

    problems: list[str] = []
    if backend == BACKEND_VLLM:
        host = _env("vllm_host")
        if not host:
            problems.append("llm_mode=vllm_host but vllm_host is not set.")
        else:
            try:
                _normalize_base_url(host)
            except LLMConfigError as exc:
                problems.append(str(exc))
        for key, cast in (
            ("vllm_timeout", float),
            ("vllm_max_retries", int),
            ("vllm_max_tokens", int),
        ):
            raw = _env(key)
            if raw:
                try:
                    cast(raw)
                except ValueError:
                    problems.append(f"{key}={raw!r} is not a valid {cast.__name__}.")
        effort = _env("vllm_reasoning_effort").lower()
        if effort and effort not in ("low", "medium", "high"):
            problems.append("vllm_reasoning_effort must be low, medium or high.")
    return problems


def describe_config() -> list[tuple[str, str]]:
    """Key/value pairs for the startup banner and the trace file (no secrets)."""
    try:
        backend = get_backend()
    except LLMConfigError:
        return [("llm_mode", f"{_env('llm_mode')!r}  (INVALID)")]

    rows: list[tuple[str, str]] = [("llm_mode", backend)]
    if backend == BACKEND_VLLM:
        rows += [
            ("vllm_host", _env("vllm_host") or "(not set)"),
            ("vllm_model_name", _env("vllm_model_name") or "(auto-detect)"),
            ("vllm_verify_ssl", str(_env_bool("vllm_verify_ssl", True)).lower()),
            ("vllm_max_tokens", str(_vllm_max_tokens())),
            ("vllm_reasoning_effort", _env("vllm_reasoning_effort") or "(server default)"),
        ]
    else:
        rows += [
            ("model_path", _env("model_path") or "(not set)"),
            ("adapter_path", _env("adapter_path") or "(none)"),
            ("cuda_device", _env("cuda_device") or "cuda:0"),
        ]
    return rows


# ─────────────────────────────────────────────────────────────────────────────
# Log context
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LLMLogContext:
    """Append-only log of all LLM calls for one document build."""

    path: Path
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _seq: int = 0

    def reset(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")
        self._seq = 0

    def next_seq(self) -> int:
        self._seq += 1
        return self._seq

    def append(self, text: str) -> None:
        with self._lock:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(text)


# ─────────────────────────────────────────────────────────────────────────────
# Model singleton  (loaded once per process)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _ModelSingleton:
    tokenizer: Any = None
    model: Any = None
    loaded: bool = False
    load_error: str | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)


_MODEL = _ModelSingleton()


def _load_model_once() -> tuple[Any, Any] | None:
    """Load the HuggingFace model + optional LoRA adapter.

    Returns (tokenizer, model) on success, or None if unavailable.
    The result is cached — subsequent calls return immediately.
    """
    with _MODEL._lock:
        if _MODEL.loaded:
            return (_MODEL.tokenizer, _MODEL.model) if _MODEL.tokenizer else None

        model_path = os.environ.get("model_path", "").strip()
        adapter_path = os.environ.get("adapter_path", "").strip()
        cuda_device = os.environ.get("cuda_device", "cuda:0").strip() or "cuda:0"

        if not model_path:
            _MODEL.load_error = (
                "model_path is not set in .env — set model_path=/path/to/model"
            )
            _MODEL.loaded = True
            print(f"  [docgen] {_MODEL.load_error}", flush=True)
            return None

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer

            print(f"  [docgen] Loading tokenizer from: {model_path}", flush=True)
            tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=True,
                use_fast=True,
            )
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token

            dtype = torch.float16 if torch.cuda.is_available() else torch.float32
            print(f"  [docgen] Loading model ({dtype}) on {cuda_device} ...", flush=True)
            model = AutoModelForCausalLM.from_pretrained(
                model_path,
                torch_dtype=dtype,
                device_map=cuda_device,
                trust_remote_code=True,
            )

            if adapter_path:
                print(f"  [docgen] Merging LoRA adapter: {adapter_path}", flush=True)
                from peft import PeftModel
                model = PeftModel.from_pretrained(model, adapter_path)
                model = model.merge_and_unload()

            model.eval()
            _MODEL.tokenizer = tokenizer
            _MODEL.model = model
            _MODEL.loaded = True
            print(f"  [docgen] Model ready on {cuda_device}", flush=True)
            return tokenizer, model

        except Exception as exc:  # noqa: BLE001
            _MODEL.load_error = str(exc)
            _MODEL.loaded = True
            print(f"  [docgen] Model load error: {exc}", flush=True)
            return None


# ─────────────────────────────────────────────────────────────────────────────
# Low-level inference
# ─────────────────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = (
    "You are a technical writer for formal engineering reports. "
    "Write concise, precise prose using only the facts provided. "
    "Do not invent specifications, measurements, or names. "
    "Use exact figure and table labels as given (e.g. 'Figure 1', 'Table 2')."
)


def _run_inference(prompt: str) -> str:
    """Pass a fully-built prompt string to the model and return new tokens only."""
    pair = _load_model_once()
    if pair is None:
        return f"[Model unavailable: {_MODEL.load_error or 'unknown'}]"

    tokenizer, model = pair
    import torch

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=2048,
    )
    input_ids = inputs["input_ids"].to(model.device)

    max_new = int(os.environ.get("DOCGEN_MAX_NEW_TOKENS", 512))
    temperature = float(os.environ.get("DOCGEN_TEMPERATURE", 0.3))
    top_p = float(os.environ.get("DOCGEN_TOP_P", 0.9))

    with torch.no_grad():
        output_ids = model.generate(
            input_ids,
            max_new_tokens=max_new,
            temperature=temperature,
            top_p=top_p,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output_ids[0][input_ids.shape[-1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


# ─────────────────────────────────────────────────────────────────────────────
# Backend: vLLM host  (OpenAI-compatible chat completions)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _VLLMState:
    client: Any = None
    model_name: str = ""
    base_url: str = ""
    _lock: threading.Lock = field(default_factory=threading.Lock)


_VLLM = _VLLMState()


def _root_cause(exc: BaseException) -> str:
    """Innermost error text — the openai SDK wraps e.g. SSL errors as 'Connection error.'"""
    seen: set[int] = set()
    while exc.__cause__ is not None and id(exc.__cause__) not in seen:
        seen.add(id(exc))
        exc = exc.__cause__
    return f"{type(exc).__name__}: {exc}"


def _get_vllm_client() -> tuple[Any, str]:
    """Create (once) and return ``(OpenAI client, model_name)``.

    Raises LLMConfigError / connection errors with an actionable message.
    Failures are not cached, so a later call can succeed once the host is up.
    """
    with _VLLM._lock:
        if _VLLM.client is not None:
            return _VLLM.client, _VLLM.model_name

        host = _env("vllm_host")
        if not host:
            raise LLMConfigError("llm_mode=vllm_host but vllm_host is not set.")
        base_url = _normalize_base_url(host)

        try:
            import httpx
            from openai import OpenAI
        except ImportError as exc:
            raise LLMConfigError(
                "vllm_host mode needs the 'openai' and 'httpx' packages: "
                "pip install openai httpx"
            ) from exc

        verify = _env_bool("vllm_verify_ssl", True)
        timeout = float(_env("vllm_timeout") or 300)
        max_retries = int(_env("vllm_max_retries") or 2)
        api_key = _env("vllm_api_key") or "EMPTY"

        client = OpenAI(
            base_url=base_url,
            api_key=api_key,
            http_client=httpx.Client(verify=verify),
            timeout=timeout,
            max_retries=max_retries,
        )

        configured = _env("vllm_model_name").strip("\"'")
        served: list[str] = []
        try:
            served = [m.id for m in client.models.list().data]
        except Exception as exc:  # noqa: BLE001
            if not configured:
                raise LLMConfigError(
                    f"Cannot reach vLLM host {base_url} (GET /models failed: {_root_cause(exc)}). "
                    "Check vllm_host / network / vllm_verify_ssl, or set "
                    "vllm_model_name to skip auto-detection."
                ) from exc
            print(
                f"  [docgen] Warning: GET {base_url}/models failed ({_root_cause(exc)}); "
                f"continuing with vllm_model_name={configured!r}",
                flush=True,
            )

        if configured:
            model_name = configured
            if served and configured not in served:
                print(
                    f"  [docgen] Warning: vllm_model_name={configured!r} is not in the "
                    f"server's model list {served}",
                    flush=True,
                )
        else:
            if not served:
                raise LLMConfigError(
                    f"vLLM host {base_url} reports no models; set vllm_model_name."
                )
            model_name = served[0]
            if len(served) > 1:
                print(
                    f"  [docgen] Server serves {len(served)} models; using {model_name!r}. "
                    "Set vllm_model_name to choose another.",
                    flush=True,
                )

        _VLLM.client = client
        _VLLM.model_name = model_name
        _VLLM.base_url = base_url
        print(f"  [docgen] vLLM ready: {base_url}  model={model_name}", flush=True)
        return client, model_name


def preflight() -> str:
    """Fail-fast check run once before a build. Returns a one-line summary.

    vllm_host: connects and resolves the model name now (not at paragraph #1).
    local_hugging_path: no work here — the model loads lazily, as before.
    """
    backend = get_backend()
    if backend == BACKEND_VLLM:
        _, model_name = _get_vllm_client()
        return f"LLM backend: vllm_host  ({_VLLM.base_url}, model={model_name})"
    return f"LLM backend: local_hugging_path  (model_path={_env('model_path') or '(not set)'})"


def _run_inference_vllm(messages: list[dict[str, str]]) -> str:
    """Send chat messages to the vLLM host and return the assistant text."""
    client, model_name = _get_vllm_client()

    kwargs: dict[str, Any] = {
        "model": model_name,
        "messages": messages,
        "max_tokens": _vllm_max_tokens(),
        "temperature": float(_env("DOCGEN_TEMPERATURE") or 0.3),
        "top_p": float(_env("DOCGEN_TOP_P") or 0.9),
    }
    effort = _env("vllm_reasoning_effort").lower()
    if effort:
        kwargs["extra_body"] = {"reasoning_effort": effort}

    response = client.chat.completions.create(**kwargs)
    if not response.choices:
        raise RuntimeError("vLLM returned no choices.")

    choice = response.choices[0]
    text = (choice.message.content or "").strip()
    finish = getattr(choice, "finish_reason", None)

    if not text:
        hint = (
            " The token budget was probably used up by reasoning — raise "
            "vllm_max_tokens or set vllm_reasoning_effort=low."
            if finish == "length"
            else ""
        )
        raise RuntimeError(f"vLLM returned empty content (finish_reason={finish}).{hint}")

    if finish == "length":
        print(
            "  [docgen] Warning: output hit the token limit and may be truncated "
            "(raise vllm_max_tokens).",
            flush=True,
        )
    return text


def _render_messages(messages: list[dict[str, str]]) -> str:
    """Human-readable form of chat messages for the trace file."""
    return "\n\n".join(f"[{m['role'].upper()}]\n{m['content']}" for m in messages)


# ─────────────────────────────────────────────────────────────────────────────
# Prompt builders — finetuned mode
# ─────────────────────────────────────────────────────────────────────────────

def _facts_str(json_context: dict[str, Any]) -> str:
    return json.dumps(json_context, ensure_ascii=False, indent=2)


def _finetuned_user_text(prompt: str, json_context: dict[str, Any]) -> str:
    domain = json_context.get("domain", "Structures")
    return (
        f"You are working in the domain of {domain}. "
        f"{prompt}\n\n"
        f"Input:\n{_facts_str(json_context)}"
    )


def _build_finetuned_prompt(prompt: str, json_context: dict[str, Any]) -> str:
    """[INST] prompt matching the fine-tuning data format (local backend)."""
    return f"<s>[INST]\n{_finetuned_user_text(prompt, json_context)}\n[/INST]"


def _build_finetuned_messages(
    prompt: str, json_context: dict[str, Any]
) -> list[dict[str, str]]:
    """Chat messages for vLLM (the server applies the model's chat template)."""
    return [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": _finetuned_user_text(prompt, json_context)},
    ]


# ─────────────────────────────────────────────────────────────────────────────
# Prompt builders — cot mode
# ─────────────────────────────────────────────────────────────────────────────

_COT_INSTRUCTIONS = (
    "You will reason step-by-step before writing (Chain-of-Thought).\n"
    "Always output exactly two sections: 'Thought:' then 'Answer:'."
)


def _cot_examples_and_question(
    prompt: str,
    json_context: dict[str, Any],
    cot_examples: list[dict[str, str]],
) -> str:
    """Few-shot examples followed by the live question (shared by both backends).

    Each example dict must have: question, thought, answer.
    """
    lines: list[str] = []
    for i, ex in enumerate(cot_examples, start=1):
        q = str(ex.get("question", "")).strip()
        t = str(ex.get("thought", "")).strip()
        a = str(ex.get("answer", "")).strip()
        lines += [
            f"### Example {i}",
            f"Question: {q}",
            f"Thought: {t}",
            f"Answer: {a}",
            "",
        ]
    lines += [
        "### Now write the following:",
        f"Question: {prompt}",
        f"Input facts:\n{_facts_str(json_context)}",
    ]
    return "\n".join(lines)


def _build_cot_prompt(
    prompt: str,
    json_context: dict[str, Any],
    cot_examples: list[dict[str, str]],
) -> str:
    """CoT prompt for the local backend (primed with a trailing 'Thought:')."""
    return "\n".join(
        [
            "<s>[INST]",
            _SYSTEM_PROMPT,
            "",
            _COT_INSTRUCTIONS,
            "",
            _cot_examples_and_question(prompt, json_context, cot_examples),
            "[/INST]",
            "Thought:",  # prime the model to start with Thought:
        ]
    )


def _build_cot_messages(
    prompt: str,
    json_context: dict[str, Any],
    cot_examples: list[dict[str, str]],
) -> list[dict[str, str]]:
    """CoT chat messages for vLLM."""
    user = (
        f"{_COT_INSTRUCTIONS}\n\n"
        f"{_cot_examples_and_question(prompt, json_context, cot_examples)}"
    )
    return [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


def _extract_cot_answer(raw: str) -> str:
    """Pull the final paragraph out of a ``Thought: … Answer: …`` completion."""
    if "Answer:" in raw:
        answer = raw.split("Answer:", 1)[-1].strip()
        # Trim any bleed-back into another Thought block
        if "Thought:" in answer:
            answer = answer.split("Thought:")[0].strip()
        return answer
    # Model didn't follow format — return whole output as answer
    return raw.strip()


# ─────────────────────────────────────────────────────────────────────────────
# Stub (--no-llm / runtime failure)
# ─────────────────────────────────────────────────────────────────────────────

def _stub_paragraph(json_context: dict[str, Any], prompt: str) -> str:
    bits = ", ".join(
        f"{k}={v}" for k, v in list(json_context.items())[:6] if v is not None
    )
    return (
        f"[STUB — LLM disabled] Context: {bits}. "
        f"Instruction: {prompt[:200]}{'…' if len(prompt) > 200 else ''}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Log writer
# ─────────────────────────────────────────────────────────────────────────────

def _write_log_block(
    ctx: LLMLogContext,
    *,
    seq: int,
    mode: str,
    prompt_sent: str,
    facts_json: dict[str, Any],
    raw_output: str,
    final_text: str,
    error: str | None = None,
) -> None:
    lines = [
        "=" * 80,
        f"CALL #{seq}  {datetime.now(timezone.utc).isoformat()}",
        f"MODE: {mode}",
    ]
    lines += [f"{k:<22}{v}" for k, v in describe_config()]
    lines += [
        "",
        "--- Prompt sent to model ---",
        prompt_sent,
        "",
        "--- Facts JSON ---",
        json.dumps(facts_json, ensure_ascii=False, indent=2),
        "",
    ]
    if error:
        lines += ["--- Error ---", error, ""]
    lines += [
        "--- Raw model output ---",
        raw_output or "(empty)",
        "",
        "--- Final text written to Word document ---",
        final_text or "(empty)",
        "",
    ]
    ctx.append("\n".join(lines))


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def log_paragraph_disabled(
    ctx: LLMLogContext,
    *,
    instruction_prompt: str,
    facts_json: dict[str, Any],
    body: str,
) -> None:
    """Log a stub entry when --no-llm is active."""
    seq = ctx.next_seq()
    _write_log_block(
        ctx,
        seq=seq,
        mode="llm_disabled (--no-llm)",
        prompt_sent="(no request sent)",
        facts_json=facts_json,
        raw_output="",
        final_text=body,
        error="--no-llm flag set; no inference performed.",
    )


def generate_paragraph_sync(
    prompt: str,
    json_context: dict[str, Any],
    *,
    mode: str = "finetuned",
    cot_examples: list[dict[str, str]] | None = None,
    log_ctx: LLMLogContext | None = None,
    # Legacy keyword args kept for call-site compatibility (ignored)
    model: str | None = None,
    base_url: str | None = None,
) -> str:
    """Generate a paragraph with the backend selected by ``llm_mode`` in .env.

    Parameters
    ----------
    prompt:
        Instruction string — what to write.
    json_context:
        Facts dict from bundle.json used as grounding input.
    mode:
        ``"finetuned"`` — direct generation (default).
        ``"cot"``       — Chain-of-Thought using cot_examples from YAML.
    cot_examples:
        List of {question, thought, answer} dicts. Required when mode="cot".
    log_ctx:
        Append-only log context; pass None to skip logging.
    """
    seq = log_ctx.next_seq() if log_ctx else 0
    mode = (mode or "finetuned").strip().lower()
    cot_examples = cot_examples or []

    error: str | None = None
    raw_output = ""
    final_text = ""
    prompt_sent = ""

    try:
        backend = get_backend()

        if mode == "cot" and not cot_examples:
            error = "mode=cot but cot_examples is empty — falling back to finetuned."
            mode = "finetuned"

        if backend == BACKEND_VLLM:
            if mode == "cot":
                messages = _build_cot_messages(prompt, json_context, cot_examples)
            else:
                messages = _build_finetuned_messages(prompt, json_context)
            prompt_sent = _render_messages(messages)
            raw_output = _run_inference_vllm(messages)
        else:
            if mode == "cot":
                prompt_sent = _build_cot_prompt(prompt, json_context, cot_examples)
                # Prepend "Thought:" because the prompt was primed with it
                raw_output = "Thought: " + _run_inference(prompt_sent)
            else:
                prompt_sent = _build_finetuned_prompt(prompt, json_context)
                raw_output = _run_inference(prompt_sent)

        final_text = _extract_cot_answer(raw_output) if mode == "cot" else raw_output

    except Exception as exc:  # noqa: BLE001
        error = (error + " " if error else "") + f"Runtime error: {exc}"
        final_text = _stub_paragraph(json_context, prompt)
        raw_output = ""
        prompt_sent = prompt_sent or prompt

    if log_ctx:
        _write_log_block(
            log_ctx,
            seq=seq,
            mode=mode,
            prompt_sent=prompt_sent,
            facts_json=json_context,
            raw_output=raw_output,
            final_text=final_text,
            error=error,
        )

    return final_text

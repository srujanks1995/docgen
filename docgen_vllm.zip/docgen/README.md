# docgen

Generate a Word report (`.docx`) from:
- a **ZIP bundle** containing `bundle.json` + `tables/` + `images/` (+ optional `content/` and `.docx` math snippets)
- a **YAML template** describing the document structure

The generator also writes **`llm_out.txt`** (prompt + inputs + responses) next to the output document by default.

## Word template (header/footer + pre-existing pages)

If the ZIP bundle contains **exactly one `.docx` file**, `docgen` uses it as the **base template** (so the report keeps the template's **header and footer**). Any body content inside the template is cleared before writing the generated report content.

### Template with title page and index page

If your template already has a **title page (page 1)** and an **index/TOC page (page 2)**, pass `--template-pages 2` (which is the **default**). `docgen` will insert two page-breaks at the start so all generated content — List of Tables, List of Figures, and body sections — begins on **page 3**.

```powershell
# default (template has title on page 1, index on page 2 → content starts page 3)
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx

# template has only a title page (content starts page 2)
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --template-pages 1

# no pre-existing template pages
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --template-pages 0
```

## List of Figures / List of Tables (with page numbers)

`docgen` automatically generates a **List of Tables** and **List of Figures** with:
- Clickable hyperlinks to each figure/table in the document body
- Dot-leader (`........`) separating the caption from the page number
- **PAGEREF** page numbers — these update automatically when you open the document in Word and press `Ctrl+A → F9` (or print/save as PDF)

These lists are placed at the start of the generated content (page 3 when using the default `--template-pages 2`).

## How to run (example report ~10 pages)

From the repo root:

```powershell
python -m pip install -e ".[dev]"
python tools\build_example.py
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx
```

Outputs:
- `example\report.docx`
- `example\llm_out.txt`

## LLM configuration (`.env`)

Create/update `.env` (or `env`) in the repo root (it is gitignored). One setting picks the backend:

| `llm_mode` | Backend |
|------------|---------|
| `vllm_host` | Remote vLLM server via its OpenAI-compatible `/v1` API |
| `local_hugging_path` | Local HuggingFace model (+ optional LoRA adapter) loaded with `transformers` *(default if unset)* |

### Option A: vLLM host

```ini
llm_mode=vllm_host
vllm_host=https://<your-vllm-host>/v1
vllm_model_name=            # blank = auto-detect from GET /v1/models
vllm_api_key=EMPTY
vllm_verify_ssl=false       # false for self-signed / internal certs
```

| Variable | Default | Notes |
|----------|---------|-------|
| `vllm_host` | *(required)* | Base URL; `/v1` is appended if missing |
| `vllm_model_name` | auto-detect | Exact served model id (the snapshot path for HF-cache deployments) |
| `vllm_api_key` | `EMPTY` | |
| `vllm_verify_ssl` | `true` | `false` disables TLS verification |
| `vllm_timeout` | `300` | Seconds per request |
| `vllm_max_retries` | `2` | |
| `vllm_max_tokens` | `2048` | Reasoning models (gpt-oss) use tokens for thinking before the answer |
| `vllm_reasoning_effort` | server default | `low` / `medium` / `high` |

Notes:
- `adapter_path` / `cuda_device` are **ignored** in this mode — the adapter lives on the server. If you serve a LoRA with `--lora-modules`, set `vllm_model_name` to that module name.
- The host is checked once at startup; an unreachable host or bad config exits with code 2 before any document work.
- `docgen` sends chat messages (system + user); the server applies the model's chat template.

### Option B: local HuggingFace model

```ini
llm_mode=local_hugging_path
model_path=/path/to/hf-model-dir
adapter_path=/path/to/lora-adapter   # optional
cuda_device=cuda:0
```

Requires `torch`, `transformers`, `peft`, `accelerate` (see `pip install -e ".[inference]"`).

Sampling (both backends): `DOCGEN_TEMPERATURE` (0.3), `DOCGEN_TOP_P` (0.9); `DOCGEN_MAX_NEW_TOKENS` (512) applies to the local backend only.

### No LLM (stub text)

```powershell
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --no-llm
```

## LLM trace file (`llm_out.txt`)

By default, `docgen` writes `llm_out.txt` next to `--out`.

You can override or disable it:

```powershell
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --llm-log example\my_trace.txt
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --no-llm-log
```

## CLI reference

| Flag | Default | Description |
|------|---------|-------------|
| `--zip` | *(required)* | Path to the ZIP bundle |
| `--yaml` | *(required)* | Path to the YAML structure template |
| `--out` | *(required)* | Output `.docx` path |
| `--template-pages` | `2` | Pages already in the template to skip (title=1, index=2) |
| `--no-llm` | off | Disable LLM calls; use stub text |
| `--llm-log` | `llm_out.txt` | Custom path for LLM trace file |
| `--no-llm-log` | off | Disable LLM trace file |

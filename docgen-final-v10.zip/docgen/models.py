from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class ParagraphElement:
    kind: Literal["paragraph"] = "paragraph"
    prompt: str = ""
    json_key: str = ""          # top-level key in bundle.json
    json_path: str = ""         # dot-path e.g. "Static.Static_loads.Static_Structural"
    mode: str = "finetuned"     # "finetuned" | "cot"
    cot_examples: list[dict] = field(default_factory=list)


@dataclass
class FileParagraphElement:
    """Body text loaded verbatim from a UTF-8 file inside the ZIP (no LLM)."""
    kind: Literal["paragraph_file"] = "paragraph_file"
    text_path: str = ""


@dataclass
class TableElement:
    kind: Literal["table"] = "table"
    csv_path: str = ""
    caption: str = ""


@dataclass
class MultiTableElement:
    """Multiple CSV tables rendered sequentially, each with its own caption.

    YAML example::

        - kind: multi_table
          tables:
            - csv_path: tables/stress_x.csv
              caption: Stress Results — X Direction
            - csv_path: tables/stress_y.csv
              caption: Stress Results — Y Direction
    """
    kind: Literal["multi_table"] = "multi_table"
    tables: list[TableElement] = field(default_factory=list)


@dataclass
class ImageElement:
    kind: Literal["image"] = "image"
    img_path: str = ""
    caption: str = ""


@dataclass
class MathBlockElement:
    """Formula authored in Word, supplied as .docx snippet files in the ZIP."""
    kind: Literal["math"] = "math"
    docx_path: str = ""
    derivation_docx_paths: list[str] = field(default_factory=list)
    caption: str = ""


DocElement = (
    ParagraphElement
    | FileParagraphElement
    | TableElement
    | MultiTableElement
    | ImageElement
    | MathBlockElement
)


@dataclass
class SectionNode:
    """Hierarchical section node (supports arbitrary depth via section_id dotted path)."""
    section_id: str          # e.g. "3.6.1"
    name: str
    elements: list[DocElement] = field(default_factory=list)
    children: list["SectionNode"] = field(default_factory=list)


@dataclass
class DocumentConfig:
    title: str
    root_sections: list[SectionNode]

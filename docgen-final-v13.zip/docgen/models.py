from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal  # noqa: F401


@dataclass
class ParagraphElement:
    kind: Literal["paragraph"] = "paragraph"
    prompt: str = ""
    json_key: str = ""          # top-level key in bundle.json
    json_path: str = ""         # dot-path e.g. "Static.Static_loads.Static_Structural"
    mode: str = "finetuned"     # "finetuned" | "cot"
    cot_examples: list[dict] = field(default_factory=list)


@dataclass
class FileParagraphElement:
    """Body text loaded verbatim from a UTF-8 file inside the ZIP (no LLM)."""
    kind: Literal["paragraph_file"] = "paragraph_file"
    text_path: str = ""


@dataclass
class TableElement:
    kind: Literal["table"] = "table"
    csv_path: str = ""
    caption: str = ""


@dataclass
class MultiTableElement:
    """Multiple CSV tables rendered sequentially, each with its own caption.

    YAML example::

        - kind: multi_table
          tables:
            - csv_path: tables/stress_x.csv
              caption: Stress Results — X Direction
            - csv_path: tables/stress_y.csv
              caption: Stress Results — Y Direction
    """
    kind: Literal["multi_table"] = "multi_table"
    tables: list[TableElement] = field(default_factory=list)


@dataclass
class ImageElement:
    kind: Literal["image"] = "image"
    img_path: str = ""
    caption: str = ""


@dataclass
class MathBlockElement:
    """Formula authored in Word, supplied as .docx snippet files in the ZIP."""
    kind: Literal["math"] = "math"
    docx_path: str = ""
    derivation_docx_paths: list[str] = field(default_factory=list)
    caption: str = ""


@dataclass
class PatternRepeatElement:
    """Repeat an image and/or table block for every file in the ZIP whose path
    starts with ``img_prefix`` / ``csv_prefix``.

    **{instance_name} substitution** — all ``{var}`` placeholders in
    ``img_prefix``, ``csv_prefix``, ``img_caption_prefix``, and
    ``table_caption_prefix`` are substituted with the outer ``repeat``
    instance variables (``{instance_name}``, ``{name}``, ``{index_1}``, …)
    *before* the ZIP is scanned.  This means one ``pattern_repeat`` element
    inside a ``kind: repeat`` block will match a different file set per
    instance automatically.

    YAML examples::

        # Stand-alone — no vars needed
        - kind: pattern_repeat
          img_prefix: images/appendix_
          csv_prefix: tables/appendix_
          img_caption_prefix: "Appendix Result"
          table_caption_prefix: "Appendix Data"

        # Inside a repeat block — prefix scoped to each instance
        - kind: pattern_repeat
          img_prefix: "images/s_detail_{instance_name}_"
          csv_prefix: "tables/s_detail_{instance_name}_"
          img_caption_prefix: "Static Detail — {name}"
          table_caption_prefix: "Static Data — {name}"

    Files are paired by stem:
      ``images/s_detail_lc1_01.png``  ↔  ``tables/s_detail_lc1_01.csv``
    """
    kind: Literal["pattern_repeat"] = "pattern_repeat"
    img_prefix: str = ""
    csv_prefix: str = ""
    img_caption_prefix: str = "Figure"
    table_caption_prefix: str = "Table"


DocElement = (
    ParagraphElement
    | FileParagraphElement
    | TableElement
    | MultiTableElement
    | ImageElement
    | MathBlockElement
    | PatternRepeatElement
)


@dataclass
class SectionNode:
    """Hierarchical section node (supports arbitrary depth via section_id dotted path)."""
    section_id: str          # e.g. "3.6.1"
    name: str
    elements: list[DocElement] = field(default_factory=list)
    children: list["SectionNode"] = field(default_factory=list)


@dataclass
class DocumentConfig:
    title: str
    root_sections: list[SectionNode]

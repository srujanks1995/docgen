#!/usr/bin/env python3
"""
build_exe.py — install PyInstaller (if needed) and build docgen_gui.exe

Usage:
    python build_exe.py

Output:
    dist/docgen_gui.exe        (Windows)
    dist/docgen_gui            (Linux / macOS)
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent


def run(cmd: list[str]) -> None:
    print(f"\n>>> {' '.join(cmd)}\n")
    subprocess.run(cmd, check=True)


def main() -> None:
    # 1. Ensure PyInstaller is installed
    try:
        import PyInstaller  # noqa: F401
        print("[build] PyInstaller already installed.")
    except ImportError:
        print("[build] Installing PyInstaller …")
        run([sys.executable, "-m", "pip", "install", "pyinstaller", "--quiet"])

    # 2. Clean previous build
    for d in ["build", "dist"]:
        target = HERE / d
        if target.exists():
            print(f"[build] Removing old {d}/ …")
            shutil.rmtree(target)

    # 3. Build
    print("[build] Running PyInstaller …")
    run([
        sys.executable, "-m", "PyInstaller",
        "--clean",
        str(HERE / "docgen_gui.spec"),
    ])

    # 4. Copy logo and env to dist/
    dist = HERE / "dist"
    for asset in ["logo.png", "env"]:
        src = HERE / asset
        if src.exists():
            dst = dist / asset
            shutil.copy2(src, dst)
            print(f"[build] Copied {asset} → dist/")

    # 5. Report
    exe = dist / "docgen_gui.exe"
    if not exe.exists():
        exe = dist / "docgen_gui"          # Linux / macOS
    if exe.exists():
        size_mb = exe.stat().st_size / 1_048_576
        print(f"\n[build] ✓ Built: {exe}  ({size_mb:.1f} MB)")
    else:
        print("\n[build] Build finished — check dist/ folder.")

    print("""
[build] To run:
    dist/docgen_gui.exe         (Windows)
    ./dist/docgen_gui           (Linux / macOS)

[build] Make sure logo.png and env are in the same folder as the exe.
""")


if __name__ == "__main__":
    main()

"""
docgen_gui.py — Tkinter-based launcher for docgen.
Build to .exe with:
    pyinstaller --onefile --windowed --icon=logo.png --add-data "logo.png;." docgen_gui.py
"""
from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, font, scrolledtext, ttk

# ── Resolve logo path (works both from source and from PyInstaller bundle) ───
def _resource(name: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    return base / name


# ─────────────────────────────────────────────────────────────────────────────
# Colours / design tokens
# ─────────────────────────────────────────────────────────────────────────────
BG        = "#1E1E2E"   # main background
BG2       = "#2A2A3E"   # card / input background
ACCENT    = "#7F77DD"   # primary purple
ACCENT2   = "#5A52B8"   # darker purple (hover)
SUCCESS   = "#1D9E75"   # green
ERROR     = "#E05A5A"   # red
TEXT      = "#E8E8F0"   # primary text
TEXT2     = "#9898B0"   # secondary text
BORDER    = "#3A3A5A"   # border colour
LOG_BG    = "#13131F"   # log panel background
LOG_FG    = "#C8C8E0"   # log text


# ─────────────────────────────────────────────────────────────────────────────
# Main window
# ─────────────────────────────────────────────────────────────────────────────
class DocgenApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()

        self.title("docgen")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(700, 600)

        self._zip_path:  tk.StringVar = tk.StringVar()
        self._yaml_path: tk.StringVar = tk.StringVar()
        self._env_path:  tk.StringVar = tk.StringVar()
        self._out_path:  tk.StringVar = tk.StringVar()
        self._no_llm:    tk.BooleanVar = tk.BooleanVar(value=False)
        self._running    = False
        self._log_queue: queue.Queue[str] = queue.Queue()

        self._setup_fonts()
        self._build_ui()
        self._auto_detect_env()
        self.after(100, self._drain_log_queue)

    # ── fonts ──────────────────────────────────────────────────────────────
    def _setup_fonts(self) -> None:
        self._font_title  = font.Font(family="Segoe UI", size=13, weight="bold")
        self._font_label  = font.Font(family="Segoe UI", size=9)
        self._font_btn    = font.Font(family="Segoe UI", size=9, weight="bold")
        self._font_mono   = font.Font(family="Consolas", size=9)
        self._font_status = font.Font(family="Segoe UI", size=9, slant="italic")

    # ── UI construction ─────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        root = self

        # ── Header: logo + title ──────────────────────────────────────────
        hdr = tk.Frame(root, bg=BG, pady=14)
        hdr.pack(fill="x", padx=24)

        logo_path = _resource("logo.png")
        if logo_path.exists():
            try:
                from PIL import Image, ImageTk   # type: ignore
                img = Image.open(logo_path)
                img.thumbnail((120, 48), Image.LANCZOS)
                self._logo_img = ImageTk.PhotoImage(img)
                tk.Label(hdr, image=self._logo_img, bg=BG).pack(side="left", padx=(0, 14))
            except Exception:
                # Pillow not available — try plain PhotoImage (PNG only)
                try:
                    self._logo_img = tk.PhotoImage(file=str(logo_path))
                    # scale down if too big
                    w, h = self._logo_img.width(), self._logo_img.height()
                    sx = max(1, w // 120)
                    sy = max(1, h // 48)
                    s = max(sx, sy)
                    if s > 1:
                        self._logo_img = self._logo_img.subsample(s, s)
                    tk.Label(hdr, image=self._logo_img, bg=BG).pack(side="left", padx=(0, 14))
                except Exception:
                    pass

        title_frame = tk.Frame(hdr, bg=BG)
        title_frame.pack(side="left")
        tk.Label(title_frame, text="docgen", font=self._font_title,
                 bg=BG, fg=TEXT).pack(anchor="w")
        tk.Label(title_frame, text="Document generation engine",
                 font=self._font_label, bg=BG, fg=TEXT2).pack(anchor="w")

        # ── Separator ────────────────────────────────────────────────────
        ttk.Separator(root, orient="horizontal").pack(fill="x", padx=0)

        # ── Form card ────────────────────────────────────────────────────
        card = tk.Frame(root, bg=BG2, bd=0, highlightthickness=1,
                        highlightbackground=BORDER)
        card.pack(fill="x", padx=24, pady=14)

        rows = [
            ("ZIP Bundle",      self._zip_path,  "Select ZIP…",  self._browse_zip),
            ("YAML Structure",  self._yaml_path, "Select YAML…", self._browse_yaml),
            ("Env File (.env)", self._env_path,  "Select env…",  self._browse_env),
            ("Output (.docx)",  self._out_path,  "Save as…",     self._browse_out),
        ]

        for i, (label, var, placeholder, cmd) in enumerate(rows):
            row = tk.Frame(card, bg=BG2)
            row.pack(fill="x", padx=16, pady=(10 if i == 0 else 4, 4 if i < len(rows) - 1 else 10))

            tk.Label(row, text=label, font=self._font_label,
                     bg=BG2, fg=TEXT2, width=16, anchor="w").pack(side="left")

            entry = tk.Entry(row, textvariable=var, font=self._font_mono,
                             bg=BG, fg=TEXT, insertbackground=TEXT,
                             relief="flat", bd=0,
                             highlightthickness=1, highlightbackground=BORDER,
                             highlightcolor=ACCENT)
            entry.pack(side="left", fill="x", expand=True, ipady=5, padx=(0, 8))

            btn = _FlatButton(row, text=placeholder, command=cmd,
                              bg=BG, fg=ACCENT, hover_bg=BG2,
                              font=self._font_label, border_color=BORDER)
            btn.pack(side="right")

        # ── Options row ──────────────────────────────────────────────────
        opt_row = tk.Frame(card, bg=BG2)
        opt_row.pack(fill="x", padx=16, pady=(0, 10))
        cb = tk.Checkbutton(opt_row, text="--no-llm  (skip model, stub text)",
                            variable=self._no_llm,
                            font=self._font_label,
                            bg=BG2, fg=TEXT2, selectcolor=BG,
                            activebackground=BG2, activeforeground=TEXT,
                            relief="flat", bd=0)
        cb.pack(side="left")

        # ── Action buttons ───────────────────────────────────────────────
        btn_row = tk.Frame(root, bg=BG)
        btn_row.pack(fill="x", padx=24, pady=(0, 10))

        self._gen_btn = _FlatButton(
            btn_row, text="▶  Start Generation",
            command=self._start_generation,
            bg=ACCENT, fg="#FFFFFF", hover_bg=ACCENT2,
            font=self._font_btn, padx=20, pady=8,
        )
        self._gen_btn.pack(side="right", padx=(8, 0))

        _FlatButton(
            btn_row, text="✕  Clear Log",
            command=self._clear_log,
            bg=BG2, fg=TEXT2, hover_bg=BORDER,
            font=self._font_btn, padx=14, pady=8,
        ).pack(side="right")

        # ── Status bar ───────────────────────────────────────────────────
        self._status_var = tk.StringVar(value="Ready")
        tk.Label(btn_row, textvariable=self._status_var,
                 font=self._font_status, bg=BG, fg=TEXT2).pack(side="left")

        # ── Log panel ────────────────────────────────────────────────────
        log_frame = tk.Frame(root, bg=BG)
        log_frame.pack(fill="both", expand=True, padx=24, pady=(0, 16))

        tk.Label(log_frame, text="Output Log", font=self._font_label,
                 bg=BG, fg=TEXT2).pack(anchor="w", pady=(0, 4))

        self._log = scrolledtext.ScrolledText(
            log_frame,
            font=self._font_mono,
            bg=LOG_BG, fg=LOG_FG,
            insertbackground=TEXT,
            relief="flat", bd=0,
            highlightthickness=1,
            highlightbackground=BORDER,
            state="disabled",
            wrap="word",
        )
        self._log.pack(fill="both", expand=True)

        # colour tags
        self._log.tag_config("ok",    foreground=SUCCESS)
        self._log.tag_config("err",   foreground=ERROR)
        self._log.tag_config("warn",  foreground="#E0A030")
        self._log.tag_config("dim",   foreground=TEXT2)
        self._log.tag_config("head",  foreground=ACCENT)

    # ── Auto-detect env ────────────────────────────────────────────────────
    def _auto_detect_env(self) -> None:
        for candidate in [Path(".env"), Path("env"),
                          Path(__file__).parent / ".env",
                          Path(__file__).parent / "env"]:
            if candidate.is_file():
                self._env_path.set(str(candidate.resolve()))
                break

    # ── Browse helpers ─────────────────────────────────────────────────────
    def _browse_zip(self) -> None:
        p = filedialog.askopenfilename(
            title="Select ZIP Bundle",
            filetypes=[("ZIP archive", "*.zip"), ("All files", "*.*")],
        )
        if p:
            self._zip_path.set(p)
            # auto-suggest output path next to zip
            if not self._out_path.get():
                self._out_path.set(str(Path(p).with_suffix(".docx")))

    def _browse_yaml(self) -> None:
        p = filedialog.askopenfilename(
            title="Select YAML Structure",
            filetypes=[("YAML files", "*.yaml *.yml"), ("All files", "*.*")],
        )
        if p:
            self._yaml_path.set(p)

    def _browse_env(self) -> None:
        p = filedialog.askopenfilename(
            title="Select env / .env file",
            filetypes=[("Env files", "*.env env .env"), ("All files", "*.*")],
        )
        if p:
            self._env_path.set(p)

    def _browse_out(self) -> None:
        p = filedialog.asksaveasfilename(
            title="Save Output Document",
            defaultextension=".docx",
            filetypes=[("Word Document", "*.docx"), ("All files", "*.*")],
        )
        if p:
            self._out_path.set(p)

    # ── Log helpers ────────────────────────────────────────────────────────
    def _log_write(self, text: str, tag: str = "") -> None:
        self._log.configure(state="normal")
        if tag:
            self._log.insert("end", text, tag)
        else:
            self._log.insert("end", text)
        self._log.configure(state="disabled")
        self._log.see("end")

    def _clear_log(self) -> None:
        self._log.configure(state="normal")
        self._log.delete("1.0", "end")
        self._log.configure(state="disabled")

    def _drain_log_queue(self) -> None:
        try:
            while True:
                line = self._log_queue.get_nowait()
                # Colour by content
                low = line.lower()
                if "error" in low or "traceback" in low or "exception" in low:
                    tag = "err"
                elif "warning" in low or "warn" in low:
                    tag = "warn"
                elif "✓" in line or "done" in low or "wrote" in low:
                    tag = "ok"
                elif line.startswith("[docgen]  ") or line.startswith("  "):
                    tag = "dim"
                elif line.startswith("[docgen] Document") or line.startswith("[docgen] Sections"):
                    tag = "head"
                else:
                    tag = ""
                self._log_write(line + "\n", tag)
        except queue.Empty:
            pass
        self.after(80, self._drain_log_queue)

    # ── Generation ────────────────────────────────────────────────────────
    def _start_generation(self) -> None:
        if self._running:
            return

        zip_p  = self._zip_path.get().strip()
        yaml_p = self._yaml_path.get().strip()
        out_p  = self._out_path.get().strip()
        env_p  = self._env_path.get().strip()

        errors = []
        if not zip_p:
            errors.append("ZIP bundle path is required.")
        elif not Path(zip_p).is_file():
            errors.append(f"ZIP not found: {zip_p}")
        if not yaml_p:
            errors.append("YAML structure path is required.")
        elif not Path(yaml_p).is_file():
            errors.append(f"YAML not found: {yaml_p}")
        if not out_p:
            errors.append("Output .docx path is required.")

        if errors:
            for e in errors:
                self._log_queue.put(f"✗  {e}")
            return

        self._running = True
        self._gen_btn.configure(state="disabled")
        self._status_var.set("Generating…")
        self._log_queue.put("─" * 60)
        self._log_queue.put(f"ZIP  : {zip_p}")
        self._log_queue.put(f"YAML : {yaml_p}")
        self._log_queue.put(f"OUT  : {out_p}")
        if env_p:
            self._log_queue.put(f"ENV  : {env_p}")
        self._log_queue.put("─" * 60)

        threading.Thread(
            target=self._run_docgen,
            args=(zip_p, yaml_p, out_p, env_p),
            daemon=True,
        ).start()

    def _run_docgen(self, zip_p: str, yaml_p: str, out_p: str, env_p: str) -> None:
        """Run docgen in a subprocess so the GUI stays responsive."""
        # Build command
        cmd = [
            sys.executable, "-m", "docgen.cli",
            "--zip",  zip_p,
            "--yaml", yaml_p,
            "--out",  out_p,
        ]
        if self._no_llm.get():
            cmd.append("--no-llm")

        # Environment — inherit current, then overlay with chosen env file
        env = os.environ.copy()
        if env_p and Path(env_p).is_file():
            # Parse the env file manually (dotenv may not be available)
            for line in Path(env_p).read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                env[k.strip()] = v.strip()

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
                cwd=str(Path(__file__).parent),
            )
            for line in iter(proc.stdout.readline, ""):
                self._log_queue.put(line.rstrip())
            proc.stdout.close()
            rc = proc.wait()

            if rc == 0:
                self._log_queue.put("")
                self._log_queue.put(f"✓  Generation complete → {out_p}")
                self.after(0, lambda: self._status_var.set("✓ Done"))
            else:
                self._log_queue.put(f"✗  Process exited with code {rc}")
                self.after(0, lambda: self._status_var.set(f"✗ Error (exit {rc})"))

        except Exception as exc:
            self._log_queue.put(f"✗  Failed to launch docgen: {exc}")
            self.after(0, lambda: self._status_var.set("✗ Launch error"))

        finally:
            self._running = False
            self.after(0, lambda: self._gen_btn.configure(state="normal"))


# ─────────────────────────────────────────────────────────────────────────────
# Flat button widget (no tk.Button ugliness)
# ─────────────────────────────────────────────────────────────────────────────
class _FlatButton(tk.Label):
    def __init__(self, parent, text: str, command,
                 bg: str, fg: str, hover_bg: str,
                 font=None, padx: int = 12, pady: int = 5,
                 border_color: str = "", **kw):
        super().__init__(
            parent, text=text, bg=bg, fg=fg,
            font=font, padx=padx, pady=pady,
            cursor="hand2",
            relief="flat",
            highlightthickness=1 if border_color else 0,
            highlightbackground=border_color,
            **kw,
        )
        self._bg = bg
        self._hover_bg = hover_bg
        self._command = command
        self.bind("<Enter>",    lambda _: self.configure(bg=hover_bg))
        self.bind("<Leave>",    lambda _: self.configure(bg=bg))
        self.bind("<Button-1>", lambda _: command())

    def configure(self, **kw):  # type: ignore[override]
        # Update stored bg when externally changed (e.g. disabled state)
        if "bg" in kw:
            self._bg = kw["bg"]
        super().configure(**kw)


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = DocgenApp()
    app.mainloop()

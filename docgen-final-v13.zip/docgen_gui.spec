# docgen_gui.spec
# Run:  pyinstaller docgen_gui.spec
# Output: dist/docgen_gui.exe  (Windows) or dist/docgen_gui (Linux/macOS)

import sys
from pathlib import Path

HERE = Path(SPECPATH)

block_cipher = None

a = Analysis(
    [str(HERE / "docgen_gui.py")],
    pathex=[str(HERE)],
    binaries=[],
    datas=[
        # Bundle logo next to the exe
        (str(HERE / "logo.png"), ".") if (HERE / "logo.png").exists() else ("", ""),

        # Bundle the entire docgen package
        (str(HERE / "docgen"), "docgen"),
    ],
    hiddenimports=[
        "docgen",
        "docgen.cli",
        "docgen.docx_builder",
        "docgen.yaml_config",
        "docgen.zip_bundle",
        "docgen.models",
        "docgen.llm",
        "docgen.word_utils",
        "docgen.docx_merge",
        # common deps
        "docx",
        "docx.oxml",
        "dotenv",
        "yaml",
        "PIL",
        "PIL.Image",
        "PIL.ImageTk",
        "transformers",
        "torch",
        "tkinter",
        "tkinter.scrolledtext",
        "tkinter.filedialog",
        "tkinter.font",
        "tkinter.ttk",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="docgen_gui",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # no console window (windowed app)
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon="logo.ico",      # uncomment and convert logo.png → logo.ico for taskbar icon
)

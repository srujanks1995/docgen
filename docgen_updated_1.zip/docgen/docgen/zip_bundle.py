from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path
from typing import Any


class ZipBundle:
    """Extracted upload: JSON dict, resolved paths for CSVs and images."""

    def __init__(self, root: Path, data: dict[str, Any]) -> None:
        self.root = root
        self.data = data

    @classmethod
    def from_zip(cls, zip_path: Path) -> ZipBundle:
        tmp = Path(tempfile.mkdtemp(prefix="docgen_zip_"))
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(tmp)

        json_files = list(tmp.rglob("*.json"))
        if not json_files:
            raise ValueError("ZIP must contain exactly one JSON file (none found).")
        if len(json_files) > 1:
            raise ValueError(
                "ZIP must contain exactly one JSON file "
                f"(found {len(json_files)}: {[str(p) for p in json_files]})."
            )
        with open(json_files[0], encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("Root JSON must be an object (dictionary).")
        return cls(tmp, data)

    def find_template_docx(self) -> Path | None:
        """Return the Word template .docx from the ZIP, if one can be identified.

        Detection order (first match wins):
        1. A file named exactly ``template.docx`` anywhere in the ZIP.
        2. A file whose name contains ``template`` (case-insensitive).
        3. Any single .docx when the ZIP contains exactly one .docx.

        Files inside a ``formulas/`` or ``math/`` subdirectory are excluded so
        that formula snippets do not interfere with template detection.
        """
        all_docxs = list(self.root.rglob("*.docx"))
        # Exclude formula/math snippet subdirectories
        candidates = [
            p for p in all_docxs
            if not any(part.lower() in ("formulas", "math", "equations")
                       for part in p.relative_to(self.root).parts[:-1])
        ]
        # 1. Exact name match
        for p in candidates:
            if p.name.lower() == "template.docx":
                return p
        # 2. Name contains "template"
        for p in candidates:
            if "template" in p.name.lower():
                return p
        # 3. Single non-formula .docx
        if len(candidates) == 1:
            return candidates[0]
        return None

    def match_prefix_indexed(self, prefix: str) -> list[Path]:
        """Match files by a prefix that may contain ``{index}`` as a numeric placeholder.

        If ``{index}`` is present in *prefix*, it is replaced by a regex that
        captures one or more digits.  Matched files are sorted **numerically**
        by the captured index value, so ``_1_``, ``_2_``, ``_10_`` sort as
        1 → 2 → 10 rather than lexicographically.

        If ``{index}`` is absent the method falls back to a plain starts-with
        match sorted alphabetically (same as a normal prefix scan).

        ``prefix`` is matched against the *relative path* inside the ZIP root
        (forward-slash separators).
        """
        import re
        prefix_norm = prefix.replace("\\", "/").lstrip("/")

        if "{index}" not in prefix_norm:
            # Plain starts-with, alphabetical sort
            results = []
            for p in sorted(self.root.rglob("*")):
                if p.is_file():
                    rel = p.relative_to(self.root).as_posix()
                    if rel.startswith(prefix_norm):
                        results.append(p)
            return results

        # Build a regex: escape everything except {index}
        parts = prefix_norm.split("{index}")
        pattern = re.compile(r"^" + re.escape(parts[0]) + r"(\d+)" + re.escape(parts[1]))

        matches: list[tuple[int, Path]] = []
        for p in self.root.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(self.root).as_posix()
            m = pattern.match(rel)
            if m:
                matches.append((int(m.group(1)), p))

        matches.sort(key=lambda t: t[0])
        return [p for _, p in matches]

    def match_pattern(self, pattern: str) -> list[Path]:
        """Return all files in the ZIP whose stem **contains** *pattern*.

        Uses a substring (``in``) check so the pattern can appear at the
        start, middle, or end of the stem.

        ``_loads_{instance_name}`` (substituted to e.g.
        ``_loads_Static_Structural_2``) therefore matches ALL of:

            s_loads_Static_Structural_2.csv        (single file)
            s_loads_Static_Structural_2_1.csv      (sub-table 1)
            s_loads_Static_Structural_2_2.csv      (sub-table 2)
            s_loads_Static_Structural_2_10.csv     (sub-table 10)

        Results are sorted **numerically** by any trailing digits in the
        stem so ``_1``, ``_2``, ``_10`` sort 1 → 2 → 10, not 1 → 10 → 2.
        """
        import re
        pattern_norm = pattern.replace("\\", "/")
        results: list[Path] = [
            p for p in self.root.rglob("*")
            if p.is_file() and pattern_norm in p.stem
        ]
        def _sort_key(p: Path) -> tuple:
            m = re.search(r"(\d+)$", p.stem)
            return (str(p.parent), re.sub(r"\d+$", "", p.stem), int(m.group(1)) if m else -1)
        return sorted(results, key=_sort_key)

    def resolve(self, rel: str) -> Path:
        """Resolve a path relative to ZIP root (POSIX or OS separators)."""
        rel_norm = rel.replace("\\", "/").lstrip("/")
        # try exact relative to root
        p = (self.root / rel_norm).resolve()
        if p.is_file():
            return p
        # basename match anywhere (helps messy zips)
        name = Path(rel_norm).name
        matches = list(self.root.rglob(name))
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ValueError(f"Ambiguous path {rel!r}: multiple files named {name!r}.")
        raise FileNotFoundError(f"Not found in ZIP: {rel!r}")

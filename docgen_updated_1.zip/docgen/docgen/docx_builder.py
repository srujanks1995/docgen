from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

from docgen.llm import LLMLogContext, generate_paragraph_sync, log_paragraph_disabled
from docgen.docx_merge import append_body_from_external_docx
from docgen.models import (
    DocumentConfig,
    FileParagraphElement,
    ImageElement,
    MathBlockElement,
    MultiTableElement,
    ParagraphElement,
    PatternRepeatElement,
    SectionNode,
    TableElement,
)
from docgen.word_utils import (
    BookmarkCounter,
    add_bookmark,
    add_hyperlink_to_bookmark,
    append_toc_entry_with_pageref,
)
from docgen.zip_bundle import ZipBundle


@dataclass
class RefTarget:
    bookmark: str
    label: str
    caption: str


def _json_slice(bundle: ZipBundle, key: str, path: str = "", vars_: dict | None = None) -> dict[str, Any]:
    """Fetch a context dict from bundle.json by top-level key or dot-path.

    ``path`` (dot-notation) takes priority over ``key``.
    ``key`` itself is also treated as dot-notation when it contains a dot,
    so ``para_input_from_json: fem_model.fem_analysis`` works directly.
    Both support ``{var}`` substitution via ``vars_``.
    """
    from docgen.yaml_config import _resolve_json_path
    # substitute vars in both key and path
    if vars_:
        from docgen.yaml_config import _sub
        if key:
            key = _sub(key, vars_)
        if path:
            path = _sub(path, vars_)

    target_path = path or (key if "." in key else "")
    if target_path:
        try:
            raw = _resolve_json_path(bundle.data, target_path)
        except (KeyError, ValueError):
            raw = None
    elif key:
        raw = bundle.data.get(key)
    else:
        return {}
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return dict(raw)
    return {"value": raw}


def _basename_key(val: Any) -> str | None:
    if val is None:
        return None
    s = str(val).strip()
    if not s:
        return None
    return Path(s.replace("\\", "/")).name.lower()


def _section_bookmark_name(section_id: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_]", "_", str(section_id).strip())
    if not s:
        s = "section"
    if s[0].isdigit():
        s = "s_" + s
    return "sec_" + s[:200]


def _stem_caption(stem: str, el: "PatternRepeatElement", extra_vars: dict | None = None) -> str:
    """Build a caption string from a file stem and a PatternRepeatElement.

    Priority:
    1. ``caption_parts`` — pick 1-based indices from stem split by ``_``,
       then apply ``caption_template`` (supports {part}, {instance_name},
       {name}, {stem}). If no template, return joined parts.
    2. ``caption``       — free template; supports {instance_name}, {name}, {stem}.
    3. fallback          — full stem with ``_`` → space.
    """
    parts = stem.split("_")
    stem_label = stem.replace("_", " ")
    vars_: dict[str, str] = {"stem": stem_label}
    if extra_vars:
        vars_.update(extra_vars)

    if el.caption_parts:
        selected = []
        for i in el.caption_parts:
            try:
                selected.append(parts[int(i) - 1])   # 1-based
            except (IndexError, ValueError):
                pass
        part_str = " ".join(selected)

        if el.caption_template:
            text = el.caption_template.replace("{part}", part_str)
            for k, v in vars_.items():
                text = text.replace(f"{{{k}}}", v)
            return text

        return part_str

    if el.caption:
        text = el.caption
        for k, v in vars_.items():
            text = text.replace(f"{{{k}}}", v)
        return text

    return stem_label


def _norm_fig_num(val: Any) -> str:
    """Normalize a figure-number-like value to a plain integer string when possible.

    Handles both JSON's ``"34"`` and CSV's occasional ``"34.0"``/float forms
    so the two sides of the lookup match reliably.
    """
    s = str(val).strip()
    if not s or s.lower() == "null":
        return ""
    try:
        return str(int(float(s)))
    except (TypeError, ValueError):
        return s


def _load_figure_lookup(bundle: "ZipBundle") -> dict[str, dict[str, str]]:
    """Load ``tables/figure_name.csv`` into ``{updated_figure_number: {"name", "caption"}}``.

    Column names are matched case-insensitively so ``Updated Figure Number``,
    ``Name``, and ``Caption`` (in any casing/spacing) are all recognized.
    Returns ``{}`` if the file is missing so callers can degrade gracefully.
    """
    try:
        path = bundle.resolve("tables/figure_name.csv")
    except (FileNotFoundError, ValueError):
        return {}

    try:
        df = pd.read_csv(path, dtype=str)
    except Exception:
        return {}

    cols = {str(c).strip().lower(): c for c in df.columns}
    num_col = cols.get("updated figure number") or cols.get("updated_figure_number")
    name_col = cols.get("name")
    cap_col = cols.get("caption")
    if num_col is None or name_col is None:
        return {}

    lookup: dict[str, dict[str, str]] = {}
    for _, row in df.iterrows():
        key = _norm_fig_num(row.get(num_col))
        if not key:
            continue
        name_val = row.get(name_col)
        cap_val = row.get(cap_col) if cap_col is not None else None
        lookup[key] = {
            "name": "" if pd.isna(name_val) else str(name_val).strip(),
            "caption": "" if cap_val is None or pd.isna(cap_val) else str(cap_val).strip(),
        }
    return lookup


def _load_table_lookup(bundle: "ZipBundle") -> dict[str, dict[str, str]]:
    """Load ``tables/table_name.csv`` into ``{table_no: {"name", "caption"}}``.

    Mirrors ``_load_figure_lookup``. Column names are matched
    case-insensitively; accepts ``Table No`` / ``Table Number`` /
    ``Updated Table Number`` for the id column and ``CSV File Name`` /
    ``Name`` for the file column, so both header styles work. Returns
    ``{}`` if the file is missing so callers can degrade gracefully.
    """
    try:
        path = bundle.resolve("tables/table_name.csv")
    except (FileNotFoundError, ValueError):
        return {}

    try:
        df = pd.read_csv(path, dtype=str)
    except Exception:
        return {}

    cols = {str(c).strip().lower(): c for c in df.columns}
    num_col = (
        cols.get("table no") or cols.get("table_no")
        or cols.get("table number") or cols.get("table_number")
        or cols.get("updated table number") or cols.get("updated_table_number")
    )
    name_col = cols.get("csv file name") or cols.get("csv_file_name") or cols.get("name")
    cap_col = cols.get("caption")
    if num_col is None or name_col is None:
        return {}

    lookup: dict[str, dict[str, str]] = {}
    for _, row in df.iterrows():
        key = _norm_fig_num(row.get(num_col))
        if not key:
            continue
        name_val = row.get(name_col)
        cap_val = row.get(cap_col) if cap_col is not None else None
        lookup[key] = {
            "name": "" if pd.isna(name_val) else str(name_val).strip(),
            "caption": "" if cap_val is None or pd.isna(cap_val) else str(cap_val).strip(),
        }
    return lookup


def _norm_caption(s: str) -> str:
    """Normalize a caption for case/whitespace-insensitive matching."""
    return re.sub(r"\s+", " ", str(s).strip()).lower()


def _table_name_by_caption(table_lookup: dict[str, dict[str, str]], caption: str) -> str | None:
    """Find the CSV file name in ``table_lookup`` whose Caption matches ``caption``.

    Case/whitespace-insensitive exact match against the ``caption`` field of
    each entry loaded by ``_load_table_lookup``. Returns ``None`` if no
    entry's caption matches (or if more than one does — ambiguous).
    """
    target = _norm_caption(caption)
    if not target:
        return None
    matches = [
        entry["name"]
        for entry in table_lookup.values()
        if entry.get("name") and _norm_caption(entry.get("caption", "")) == target
    ]
    if len(matches) == 1:
        return matches[0]
    return None


_FIGURE_KEY_RE = re.compile(r"(^|_)figures?(_|$)")
_TABLE_KEY_RE = re.compile(r"(^|_)tables?(_|$)")


def _find_table_ids(node: Any) -> list[str]:
    """Recursively collect table-id values from any table-related key.

    Mirrors ``_find_figure_ids`` but matches keys containing ``table``/
    ``tables`` as a whole underscore-delimited word (e.g. ``table_id``,
    ``stress_table_id``, but not ``turntable_id``... actually it does
    match any key with a standalone ``table``/``tables`` segment).
    """
    found: list[str] = []

    def add(v: Any) -> None:
        if v is None:
            return
        s = str(v).strip()
        if s and s.lower() != "null":
            found.append(s)

    def walk(n: Any) -> None:
        if isinstance(n, dict):
            for k, v in n.items():
                is_tbl_key = bool(_TABLE_KEY_RE.search(str(k).lower()))
                if isinstance(v, list):
                    if is_tbl_key:
                        for item in v:
                            if not isinstance(item, (dict, list)):
                                add(item)
                    walk(v)
                elif isinstance(v, dict):
                    walk(v)
                elif is_tbl_key:
                    add(v)
        elif isinstance(n, list):
            for item in n:
                walk(item)

    walk(node)

    seen: set[str] = set()
    ordered: list[str] = []
    for f in found:
        if f not in seen:
            seen.add(f)
            ordered.append(f)
    return ordered


def _resolve_json_tables(
    bundle: "ZipBundle",
    json_path: str,
    table_lookup: dict[str, dict[str, str]],
) -> list[tuple[Path, str]]:
    """Resolve a ``json_path`` into a list of ``(csv_path, caption)`` pairs.

    Mirrors ``_resolve_json_images``: navigates ``bundle.data`` to
    ``json_path``, finds every ``*table_id*`` value nested underneath,
    looks each up in ``table_lookup`` (keyed by ``Updated Table Number``),
    and resolves the resulting file name to an actual path in the ZIP.
    Entries with no CSV match, or whose file can't be found, are skipped.
    """
    from docgen.yaml_config import _resolve_json_path

    if not json_path:
        return []
    try:
        node = _resolve_json_path(bundle.data, json_path)
    except (KeyError, ValueError):
        return []

    out: list[tuple[Path, str]] = []
    for tid in _find_table_ids(node):
        entry = table_lookup.get(_norm_fig_num(tid))
        if not entry or not entry.get("name"):
            continue
        try:
            csv_path = bundle.resolve(entry["name"])
        except (FileNotFoundError, ValueError):
            continue
        out.append((csv_path, entry.get("caption") or ""))
    return out


def _resolve_table_element(
    el: "TableElement",
    bundle: "ZipBundle",
    table_lookup: dict[str, dict[str, str]] | None = None,
) -> list[tuple[Path, str]]:
    """Return ``[(csv_path, caption), ...]`` for a TableElement.

    Three sourcing modes, checked in this order:

    1. ``el.json_path`` set: JSON-driven — resolves via ``table_id`` keys
       found under that JSON path, looked up against ``table_name.csv``'s
       ``Table No`` column (may yield zero, one, or several tables).
    2. ``el.csv_path`` set: direct — fixed CSV, ``el.caption`` used as-is.
    3. ``el.caption`` only (no json_path, no csv_path): caption-lookup —
       matches ``el.caption`` against the ``Caption`` column of
       ``table_name.csv`` to find the CSV file. No match → no table.
    """
    if el.json_path:
        return _resolve_json_tables(bundle, el.json_path, table_lookup or {})
    if el.csv_path:
        return [(bundle.resolve(el.csv_path), el.caption)]
    if el.caption:
        name = _table_name_by_caption(table_lookup or {}, el.caption)
        if name:
            try:
                return [(bundle.resolve(name), el.caption)]
            except (FileNotFoundError, ValueError):
                return []
    return []


def _find_figure_ids(node: Any) -> list[str]:
    """Recursively collect figure-id values from any figure-related key.

    Covers two shapes, both nested arbitrarily deep in dicts/lists:

    1. A scalar id under a key like ``figure_id``, ``stress_figure_id``,
       ``response_figure_id`` (any key containing ``figure``/``figures`` as
       a whole underscore-delimited word, e.g. matches ``stress_figure_id``
       but not ``configure``).
    2. A **list** of bare ids under a key like ``mode_shape_figures_list``
       (same key-name rule) — every scalar entry in that list is collected.

    Dicts and lists are always recursed into regardless of key name, so
    nested structures (e.g. a list of components each with their own
    ``*_figure_id`` keys) are still fully covered. Null/empty values are
    skipped. Order of first appearance is preserved and duplicate ids are
    collapsed.
    """
    found: list[str] = []

    def add(v: Any) -> None:
        if v is None:
            return
        s = str(v).strip()
        if s and s.lower() != "null":
            found.append(s)

    def walk(n: Any) -> None:
        if isinstance(n, dict):
            for k, v in n.items():
                is_fig_key = bool(_FIGURE_KEY_RE.search(str(k).lower()))
                if isinstance(v, list):
                    if is_fig_key:
                        # Bare scalar ids directly in the list (e.g. mode_shape_figures_list)
                        for item in v:
                            if not isinstance(item, (dict, list)):
                                add(item)
                    # Always recurse too, in case the list holds dicts with
                    # their own nested figure-id keys.
                    walk(v)
                elif isinstance(v, dict):
                    walk(v)
                elif is_fig_key:
                    add(v)
        elif isinstance(n, list):
            for item in n:
                walk(item)

    walk(node)

    seen: set[str] = set()
    ordered: list[str] = []
    for f in found:
        if f not in seen:
            seen.add(f)
            ordered.append(f)
    return ordered


def _resolve_json_images(
    bundle: "ZipBundle",
    json_path: str,
    figure_lookup: dict[str, dict[str, str]],
) -> list[tuple[Path, str]]:
    """Resolve a ``json_path`` into a list of ``(image_path, caption)`` pairs.

    Navigates ``bundle.data`` to ``json_path``, finds every ``*figure_id*``
    value nested underneath (possibly several, possibly inside a list),
    looks each up in ``figure_lookup`` (keyed by ``Updated Figure Number``),
    and resolves the resulting file name to an actual path in the ZIP.
    Entries with no CSV match, or whose file can't be found, are skipped.
    """
    from docgen.yaml_config import _resolve_json_path

    if not json_path:
        return []
    try:
        node = _resolve_json_path(bundle.data, json_path)
    except (KeyError, ValueError):
        return []

    out: list[tuple[Path, str]] = []
    for fid in _find_figure_ids(node):
        entry = figure_lookup.get(_norm_fig_num(fid))
        if not entry or not entry.get("name"):
            continue
        try:
            img_path = bundle.resolve(entry["name"])
        except (FileNotFoundError, ValueError):
            continue
        out.append((img_path, entry.get("caption") or ""))
    return out


def _resolve_image_element(
    el: "ImageElement",
    bundle: "ZipBundle",
    figure_lookup: dict[str, dict[str, str]] | None = None,
) -> list[tuple[Path, str]]:
    """Return ``[(image_path, caption), ...]`` for an ImageElement.

    If ``el.json_path`` is set, resolves via the JSON + figure_name.csv
    lookup (may yield zero, one, or several images). Otherwise falls back
    to the legacy direct ``el.img_path`` / ``el.caption`` (single image).
    """
    if el.json_path:
        return _resolve_json_images(bundle, el.json_path, figure_lookup or {})
    if el.img_path:
        return [(bundle.resolve(el.img_path), el.caption)]
    return []


def _resolve_pattern_files(
    el: "PatternRepeatElement",
    bundle: "ZipBundle",
    img_exts: tuple[str, ...] = (".png", ".jpg", ".jpeg", ".gif", ".bmp"),
) -> tuple[list[Path], list[Path]]:
    """Return (img_paths, csv_paths) for a PatternRepeatElement.

    Handles both matching modes and merges results deduped, preserving order:
    - ``img_prefix`` / ``csv_prefix``: starts-with + ``{index}`` numeric sort
    - ``img_pattern`` / ``csv_pattern``: ends-with, alphabetical sort
    """
    seen: set[Path] = set()

    def _collect(paths: list[Path]) -> list[Path]:
        out = []
        for p in paths:
            if p not in seen:
                seen.add(p)
                out.append(p)
        return out

    img_paths: list[Path] = []
    csv_paths: list[Path] = []

    if el.img_prefix:
        img_paths += _collect([
            p for p in bundle.match_prefix_indexed(el.img_prefix)
            if p.suffix.lower() in img_exts
        ])
    if el.img_pattern:
        img_paths += _collect([
            p for p in bundle.match_pattern(el.img_pattern)
            if p.suffix.lower() in img_exts
        ])
    if el.csv_prefix:
        csv_paths += _collect([
            p for p in bundle.match_prefix_indexed(el.csv_prefix)
            if p.suffix.lower() == ".csv"
        ])
    if el.csv_pattern:
        csv_paths += _collect([
            p for p in bundle.match_pattern(el.csv_pattern)
            if p.suffix.lower() == ".csv"
        ])

    return img_paths, csv_paths


def _collect_paths_in_order(
    config: DocumentConfig,
    bundle: ZipBundle,
    figure_lookup: dict[str, dict[str, str]] | None = None,
    table_lookup: dict[str, dict[str, str]] | None = None,
) -> tuple[list[Path], list[Path]]:
    fig_paths: list[Path] = []
    tbl_paths: list[Path] = []

    def walk(node: SectionNode) -> None:
        for el in node.elements:
            if isinstance(el, TableElement):
                tbl_paths.extend(p for p, _ in _resolve_table_element(el, bundle, table_lookup))
            elif isinstance(el, MultiTableElement):
                for sub in el.tables:
                    tbl_paths.extend(p for p, _ in _resolve_table_element(sub, bundle, table_lookup))
            elif isinstance(el, ImageElement):
                fig_paths.extend(p for p, _ in _resolve_image_element(el, bundle, figure_lookup))
            elif isinstance(el, PatternRepeatElement):
                imgs, csvs = _resolve_pattern_files(el, bundle)
                fig_paths.extend(imgs)
                tbl_paths.extend(csvs)
        for ch in node.children:
            walk(ch)

    for root in config.root_sections:
        walk(root)
    return fig_paths, tbl_paths


def _plan_refs(
    config: DocumentConfig,
    bundle: ZipBundle,
    figure_lookup: dict[str, dict[str, str]] | None = None,
    table_lookup: dict[str, dict[str, str]] | None = None,
) -> tuple[list[RefTarget], list[RefTarget]]:
    fig_paths, tbl_paths = _collect_paths_in_order(config, bundle, figure_lookup, table_lookup)
    figures = [
        RefTarget(bookmark=f"fig_{i + 1}", label=f"Figure {i + 1}", caption="")
        for i in range(len(fig_paths))
    ]
    tables = [
        RefTarget(bookmark=f"tbl_{i + 1}", label=f"Table {i + 1}", caption="")
        for i in range(len(tbl_paths))
    ]

    fi = 0
    ti = 0

    def fill_captions(node: SectionNode) -> None:
        nonlocal fi, ti
        for el in node.elements:
            if isinstance(el, TableElement):
                for _, cap in _resolve_table_element(el, bundle, table_lookup):
                    raw_cap = cap or el.caption or tables[ti].label
                    tables[ti].caption = raw_cap.replace("_", " ")
                    ti += 1
            elif isinstance(el, MultiTableElement):
                for sub in el.tables:
                    for _, cap in _resolve_table_element(sub, bundle, table_lookup):
                        raw_cap = cap or sub.caption or tables[ti].label
                        tables[ti].caption = raw_cap.replace("_", " ")
                        ti += 1
            elif isinstance(el, ImageElement):
                for _, cap in _resolve_image_element(el, bundle, figure_lookup):
                    raw_cap = cap or el.caption or figures[fi].label
                    figures[fi].caption = raw_cap.replace("_", " ")
                    fi += 1
            elif isinstance(el, PatternRepeatElement):
                img_ps, csv_ps = _resolve_pattern_files(el, bundle)
                csv_stems = {p.stem for p in csv_ps}
                for p in img_ps:
                    figures[fi].caption = _stem_caption(p.stem, el)
                    fi += 1
                    if p.stem in csv_stems:
                        tables[ti].caption = _stem_caption(p.stem, el)
                        ti += 1
                        csv_stems.discard(p.stem)
                for stem in sorted(csv_stems):
                    tables[ti].caption = _stem_caption(stem, el)
                    ti += 1
        for ch in node.children:
            fill_captions(ch)

    for root in config.root_sections:
        fill_captions(root)

    return figures, tables


def _ref_hints_from_json(
    ctx: dict[str, Any],
    fig_paths: list[Path],
    tbl_paths: list[Path],
    figures: list[RefTarget],
    tables: list[RefTarget],
) -> str:
    fk = _basename_key(ctx.get("figure") or ctx.get("image") or ctx.get("img"))
    tk = _basename_key(ctx.get("table") or ctx.get("csv"))
    lines: list[str] = []
    if fk:
        for i, p in enumerate(fig_paths):
            if p.name.lower() == fk:
                lines.append(f"Cite the image file {p.name} exactly as '{figures[i].label}' when needed.")
                break
    if tk:
        for i, p in enumerate(tbl_paths):
            if p.name.lower() == tk:
                lines.append(f"Cite the CSV {p.name} exactly as '{tables[i].label}' when needed.")
                break
    return "\n".join(lines)


def _split_figure_table_tokens(text: str) -> list[tuple[str, str | None]]:
    """Split text into (display_text, canonical_label_or_None). Canonical labels match fig_bm/tbl_bm keys."""
    pattern = re.compile(r"(?i)\b(figure\s+(\d+)|table\s+(\d+))\b")
    parts: list[tuple[str, str | None]] = []
    pos = 0
    for m in pattern.finditer(text):
        if m.start() > pos:
            parts.append((text[pos:m.start()], None))
        if m.group(2) is not None:
            canon = f"Figure {m.group(2)}"
        else:
            canon = f"Table {m.group(3)}"
        parts.append((m.group(0), canon))
        pos = m.end()
    if pos < len(text):
        parts.append((text[pos:], None))
    return parts


def _render_text_with_refs(
    paragraph,
    text: str,
    fig_map: dict[str, str],
    tbl_map: dict[str, str],
    doc_part,
) -> None:
    label_to_bm = {**fig_map, **tbl_map}
    segments = _split_figure_table_tokens(text)
    if len(segments) == 1 and segments[0][1] is None:
        paragraph.add_run(text)
        return
    for seg, label in segments:
        if not seg:
            continue
        if label and label in label_to_bm:
            add_hyperlink_to_bookmark(paragraph, seg, label_to_bm[label], doc_part)
        else:
            paragraph.add_run(seg)


def _strip_heading_autonumber(doc: Document) -> None:
    """Remove automatic list-numbering from Heading styles in the loaded document.

    Some custom templates attach a <w:numPr> to Heading 1/2/3 so that Word
    auto-prefixes "1", "2", "1.1" etc.  When docgen already writes the section
    number as part of the heading text (e.g. "1  Introduction") this produces
    "1 1  Introduction".  Stripping numPr from the style definition fixes the
    double-number without affecting any other heading formatting, and without
    touching the template file on disk.

    Heading styles must still use their Word style names so the Navigation Pane,
    Outline view, and TOC field all work correctly.
    """
    for level in range(1, 7):
        style_name = f"Heading {level}"
        try:
            style = doc.styles[style_name]
        except KeyError:
            continue
        pPr = style.element.find(qn("w:pPr"))
        if pPr is None:
            continue
        num_pr = pPr.find(qn("w:numPr"))
        if num_pr is not None:
            pPr.remove(num_pr)


def _ensure_table_grid_style(doc: Document) -> None:
    """Inject a minimal TableGrid style definition if the template lacks it.

    Custom templates only contain styles that were actually used while authoring,
    so Table Grid is frequently absent. Word falls back to Normal Table (no borders)
    when the style is missing, producing unstyled tables. This function grafts the
    style definition straight into styles.xml so it is always available.
    """
    try:
        doc.styles["Table Grid"]
        return  # already present
    except KeyError:
        pass

    styles_elem = doc.styles.element
    style_xml = (
        '<w:style w:type="table" w:styleId="TableGrid"'        ' xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'        '<w:name w:val="Table Grid"/>'        '<w:basedOn w:val="TableNormal"/>'        '<w:tblPr>'        '<w:tblBorders>'        '<w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '<w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '<w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '<w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/>'        '</w:tblBorders>'        '</w:tblPr>'        '</w:style>'
    )
    from lxml import etree
    style_elem = etree.fromstring(style_xml)
    styles_elem.append(style_elem)


def _apply_table_borders(table) -> None:
    """Stamp all-sides single-line borders directly on the tblPr element.

    This is belt-and-suspenders: even if the style lookup fails at render time
    (e.g. the template overrides TableGrid or the style is corrupted), the borders
    are baked into the table's own XML and Word will always display them.
    """
    tbl = table._tbl
    tbl_pr = tbl.find(qn("w:tblPr"))
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        tbl.insert(0, tbl_pr)

    # Remove any existing tblBorders to avoid duplicates
    existing = tbl_pr.find(qn("w:tblBorders"))
    if existing is not None:
        tbl_pr.remove(existing)

    tbl_borders = OxmlElement("w:tblBorders")
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border = OxmlElement(f"w:{side}")
        border.set(qn("w:val"), "single")
        border.set(qn("w:sz"), "4")        # ½ pt
        border.set(qn("w:space"), "0")
        border.set(qn("w:color"), "000000")
        tbl_borders.append(border)
    tbl_pr.append(tbl_borders)


def _style_header_row(table) -> None:
    """Bold + light-grey fill on the first (header) row."""
    hdr_row = table.rows[0]
    for cell in hdr_row.cells:
        # Bold text
        for para in cell.paragraphs:
            for run in para.runs:
                run.bold = True
            if not para.runs:
                run = para.add_run()
                run.bold = True
        # Grey shading on the cell
        tc_pr = cell._tc.get_or_add_tcPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), "D9D9D9")   # 15% grey
        tc_pr.append(shd)


def _add_data_table(doc: Document, path: Path) -> None:
    _ensure_table_grid_style(doc)
    df = pd.read_csv(path)
    table = doc.add_table(rows=1, cols=len(df.columns))
    # Apply style by name (works when present; our injected style handles missing case)
    try:
        table.style = "Table Grid"
    except KeyError:
        pass  # _apply_table_borders below will still produce borders
    hdr = table.rows[0].cells
    for j, col in enumerate(df.columns):
        hdr[j].text = str(col)
    for _, row in df.iterrows():
        cells = table.add_row().cells
        for j, val in enumerate(row.tolist()):
            cells[j].text = "" if pd.isna(val) else str(val)
    # Belt-and-suspenders: stamp borders + style header regardless of template
    _apply_table_borders(table)
    _style_header_row(table)
    # Center the table on the page
    tbl_pr = table._tbl.find(qn("w:tblPr"))
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        table._tbl.insert(0, tbl_pr)
    jc = OxmlElement("w:jc")
    jc.set(qn("w:val"), "center")
    tbl_pr.append(jc)


def _add_picture(doc: Document, path: Path, width_inches: float = 5.2) -> None:
    pic = doc.add_picture(str(path), width=Inches(width_inches))
    # Walk up from w:inline → w:drawing → w:r → w:p and set jc=center directly.
    # Structure: pic._inline (w:inline) → w:drawing (getparent())
    #            → w:r (getparent()) → w:p (getparent())
    p_elem = pic._inline.getparent().getparent().getparent()
    # Insert or update w:pPr/w:jc
    pPr = p_elem.find(qn("w:pPr"))
    if pPr is None:
        pPr = OxmlElement("w:pPr")
        p_elem.insert(0, pPr)
    jc = pPr.find(qn("w:jc"))
    if jc is None:
        jc = OxmlElement("w:jc")
        pPr.append(jc)
    jc.set(qn("w:val"), "center")


def _add_text_blocks_from_file_body(
    doc: Document,
    text: str,
    fig_map: dict[str, str],
    tbl_map: dict[str, str],
    doc_part,
) -> None:
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    if not blocks and text.strip():
        blocks = [text.strip()]
    for b in blocks:
        joined = " ".join(line.strip() for line in b.splitlines() if line.strip())
        if not joined:
            continue
        p = doc.add_paragraph()
        _render_text_with_refs(p, joined, fig_map, tbl_map, doc_part)


def _add_unnumbered_heading(doc: Document, title: str) -> None:
    """Add a bold heading paragraph that is NOT styled as Heading 1/2/etc.

    Using doc.add_heading() inherits any automatic list-numbering defined on the
    Heading 1 style in the template, which causes "1 List of Tables",
    "2 List of Figures", "3 1 Introduction" etc.  Instead we write a plain
    paragraph with explicit bold + font-size so the numbering counter is never
    incremented for these front-matter titles.
    """
    p = doc.add_paragraph()
    run = p.add_run(title)
    run.bold = True
    run.font.size = Pt(14)
    # Match the spacing Word uses above/below Heading 1 (12 pt before, 0 pt after)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)


def _add_front_matter(
    doc: Document,
    figures: list[RefTarget],
    tables: list[RefTarget],
    doc_part,
) -> None:
    """Render List of Tables and List of Figures with dot-leader + PAGEREF page numbers."""
    if tables:
        _add_unnumbered_heading(doc, "List of Tables")
        for t in tables:
            p = doc.add_paragraph()
            append_toc_entry_with_pageref(p, doc_part, f"{t.label} — {t.caption}", t.bookmark)

    if figures:
        _add_unnumbered_heading(doc, "List of Figures")
        for f in figures:
            p = doc.add_paragraph()
            append_toc_entry_with_pageref(p, doc_part, f"{f.label} — {f.caption}", f.bookmark)


def build_docx(
    bundle: ZipBundle,
    config: DocumentConfig,
    out_path: Path,
    *,
    use_llm: bool = True,
    llm_log_ctx: LLMLogContext | None = None,
) -> None:
    """Build the output .docx.

    All body content from the template (title page, index page, header, footer) is
    preserved intact. Generated content (List of Tables, List of Figures, sections)
    is appended after the existing template pages.
    """
    figure_lookup = _load_figure_lookup(bundle)
    table_lookup = _load_table_lookup(bundle)
    figures, tables = _plan_refs(config, bundle, figure_lookup, table_lookup)
    fig_paths, tbl_paths = _collect_paths_in_order(config, bundle, figure_lookup, table_lookup)
    fig_bm = {f.label: f.bookmark for f in figures}
    tbl_bm = {t.label: t.bookmark for t in tables}

    template = bundle.find_template_docx()
    doc = Document(str(template)) if template else Document()

    # ------------------------------------------------------------------ #
    # Preserve the template body intact (title page, index page, etc.).   #
    # The header and footer defined in sectPr carry forward automatically. #
    # Generated content is appended AFTER the existing template content   #
    # with a single page-break to start on the next page.                 #
    # When no template is provided, no leading page-break is added.       #
    # ------------------------------------------------------------------ #
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(11)

    # Strip any auto-numbering baked into Heading styles by the custom template
    # so section numbers in the text don't get doubled.
    _strip_heading_autonumber(doc)

    if template:
        # Bridge from last template page → generated content
        doc.add_page_break()

    # List of Figures / List of Tables (with PAGEREF page numbers)
    _add_front_matter(doc, figures, tables, doc.part)
    doc.add_page_break()

    bm_counter = BookmarkCounter()
    fig_i = 0
    tbl_i = 0

    para_counter = [0]   # mutable int for nonlocal access inside nested fn

    def render_section(node: SectionNode, depth: int) -> None:
        nonlocal fig_i, tbl_i
        indent = "  " * depth
        print(f"[docgen] {indent}► Section {node.section_id}  {node.name}", flush=True)

        # Use proper Heading styles so Word Navigation Pane, Outline view,
        # and TOC fields all work. Auto-numbering has already been stripped
        # from these styles by _strip_heading_autonumber() above.
        heading = doc.add_heading(f"{node.section_id}  {node.name}", level=min(depth + 1, 6))
        add_bookmark(heading, _section_bookmark_name(node.section_id), bm_counter.next_id())

        for el in node.elements:
            if isinstance(el, ParagraphElement):
                para_counter[0] += 1
                ctx = _json_slice(bundle, el.json_key, el.json_path)
                hints = _ref_hints_from_json(ctx, fig_paths, tbl_paths, figures, tables)
                full_prompt = el.prompt.strip()
                if hints:
                    full_prompt = f"{full_prompt}\n\nCross-reference hints:\n{hints}"
                if use_llm:
                    print(
                        f"[docgen] {indent}  Paragraph #{para_counter[0]} "
                        f"[mode={el.mode}] generating ...",
                        flush=True,
                    )
                    body = generate_paragraph_sync(
                        full_prompt,
                        ctx,
                        mode=el.mode,
                        cot_examples=el.cot_examples,
                        log_ctx=llm_log_ctx,
                    )
                    preview = body[:120].replace("\n", " ")
                    print(f"[docgen] {indent}  → {preview}{'…' if len(body)>120 else ''}", flush=True)
                else:
                    print(
                        f"[docgen] {indent}  Paragraph #{para_counter[0]} [stub — no-llm]",
                        flush=True,
                    )
                    body = (
                        f"(LLM disabled) Facts: {ctx}. Original prompt: {el.prompt[:300]}"
                        + ("…" if len(el.prompt) > 300 else "")
                    )
                    if llm_log_ctx:
                        log_paragraph_disabled(
                            llm_log_ctx,
                            instruction_prompt=full_prompt,
                            facts_json=ctx,
                            body=body,
                        )
                p = doc.add_paragraph()
                _render_text_with_refs(p, body, fig_bm, tbl_bm, doc.part)

            elif isinstance(el, FileParagraphElement):
                fpath = bundle.resolve(el.text_path)
                raw_text = fpath.read_text(encoding="utf-8")
                _add_text_blocks_from_file_body(doc, raw_text, fig_bm, tbl_bm, doc.part)

            elif isinstance(el, TableElement):
                for path, _ in _resolve_table_element(el, bundle, table_lookup):
                    cap = doc.add_paragraph()
                    cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                    run = cap.add_run(f"{tables[tbl_i].label}: {tables[tbl_i].caption}")
                    run.italic = True
                    add_bookmark(cap, tables[tbl_i].bookmark, bm_counter.next_id())
                    _add_data_table(doc, path)
                    doc.add_paragraph()
                    tbl_i += 1

            elif isinstance(el, MultiTableElement):
                # Each sub-table gets its own sequential Table N label + caption
                for sub_tbl in el.tables:
                    for path, _ in _resolve_table_element(sub_tbl, bundle, table_lookup):
                        cap = doc.add_paragraph()
                        cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        run = cap.add_run(f"{tables[tbl_i].label}: {tables[tbl_i].caption}")
                        run.italic = True
                        add_bookmark(cap, tables[tbl_i].bookmark, bm_counter.next_id())
                        _add_data_table(doc, path)
                        doc.add_paragraph()
                        tbl_i += 1

            elif isinstance(el, ImageElement):
                for path, _ in _resolve_image_element(el, bundle, figure_lookup):
                    # Anchor bookmark on a paragraph before the picture so PAGEREF resolves correctly
                    anchor_p = doc.add_paragraph()
                    add_bookmark(anchor_p, figures[fig_i].bookmark, bm_counter.next_id())
                    _add_picture(doc, path)
                    # Caption BELOW the image
                    cap = doc.add_paragraph()
                    cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                    run = cap.add_run(f"{figures[fig_i].label}: {figures[fig_i].caption}")
                    run.italic = True
                    doc.add_paragraph()
                    fig_i += 1

            elif isinstance(el, PatternRepeatElement):
                img_paths, csv_paths = _resolve_pattern_files(el, bundle)
                # Build stem→csv lookup for paired rendering
                csv_by_stem = {p.stem: p for p in csv_paths}

                if img_paths:
                    for img_path in img_paths:
                        stem = img_path.stem
                        caption_text = _stem_caption(stem, el)
                        anchor_p = doc.add_paragraph()
                        add_bookmark(anchor_p, figures[fig_i].bookmark, bm_counter.next_id())
                        _add_picture(doc, img_path)
                        cap = doc.add_paragraph()
                        cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                        run = cap.add_run(f"{figures[fig_i].label}: {caption_text}")
                        run.italic = True
                        doc.add_paragraph()
                        fig_i += 1
                        if stem in csv_by_stem:
                            csv_path = csv_by_stem.pop(stem)
                            tbl_caption = _stem_caption(stem, el)
                            cap2 = doc.add_paragraph()
                            cap2.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                            run2 = cap2.add_run(f"{tables[tbl_i].label}: {tbl_caption}")
                            run2.italic = True
                            add_bookmark(cap2, tables[tbl_i].bookmark, bm_counter.next_id())
                            _add_data_table(doc, csv_path)
                            doc.add_paragraph()
                            tbl_i += 1
                for stem, csv_path in csv_by_stem.items():
                    tbl_caption = _stem_caption(stem, el)
                    cap = doc.add_paragraph()
                    cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                    run = cap.add_run(f"{tables[tbl_i].label}: {tbl_caption}")
                    run.italic = True
                    add_bookmark(cap, tables[tbl_i].bookmark, bm_counter.next_id())
                    _add_data_table(doc, csv_path)
                    doc.add_paragraph()
                    tbl_i += 1

            elif isinstance(el, MathBlockElement):
                paths: list[Path] = []
                if el.docx_path.strip():
                    paths.append(bundle.resolve(el.docx_path.strip()))
                for rel in el.derivation_docx_paths:
                    rel = str(rel).strip()
                    if rel:
                        paths.append(bundle.resolve(rel))
                if not paths:
                    doc.add_paragraph("(math block: set docx_path / formula_docx and/or derivation_docx)")
                    continue
                if el.caption.strip():
                    cap = doc.add_paragraph()
                    cap.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
                    cap.add_run(el.caption.strip().replace("_", " ")).italic = True
                    doc.add_paragraph()
                for path in paths:
                    try:
                        append_body_from_external_docx(doc, path)
                    except (OSError, ValueError) as err:
                        err_p = doc.add_paragraph()
                        err_p.add_run(f"(could not merge math .docx {path.name}: {err})")

        for ch in node.children:
            render_section(ch, depth + 1)

    for root in config.root_sections:
        render_section(root, 0)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))

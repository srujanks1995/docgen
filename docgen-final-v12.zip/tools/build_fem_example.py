"""
Build FEM (Structures domain) sample assets and example/fem_report.zip.

Produces:
  example/fem_bundle/          ← extracted assets (inspect/edit freely)
  example/fem_report.zip       ← bundle fed to docgen
  example/fem_report.yaml      ← YAML structure template

Usage:
  python tools/build_fem_example.py
  python -m docgen --zip example/fem_report.zip --yaml example/fem_report.yaml \
                   --out example/fem_report.docx --no-llm

The generated template.docx already contains:
  Page 1 – Title page  (company logo placeholder + report title)
  Page 2 – Index / Table of Contents placeholder
Run docgen with the default --template-pages 2 so body content starts on page 3.

Requires: python-docx, pillow, pandas
  pip install -e ".[dev]"
"""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "example" / "fem_bundle"
ZIP_PATH = ROOT / "example" / "fem_report.zip"
YAML_PATH = ROOT / "example" / "fem_report.yaml"

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

def _font(size: int = 20) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _add_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    br = OxmlElement("w:br")
    br.set(qn("w:type"), "page")
    run._r.append(br)


def _add_field(paragraph, field_code: str) -> None:
    """Insert a Word field (e.g. PAGE, NUMPAGES) into a paragraph run."""
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {field_code} "
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)


# ──────────────────────────────────────────────
# Template.docx  (title page + index page)
# ──────────────────────────────────────────────

def _build_template(path: Path) -> None:
    doc = Document()

    # ── global Normal style ──
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    sec = doc.sections[0]
    sec.top_margin = Inches(1.0)
    sec.bottom_margin = Inches(1.0)
    sec.left_margin = Inches(1.25)
    sec.right_margin = Inches(1.25)

    # ── Header (company + report tag) ──
    hdr = sec.header
    hdr_p = hdr.paragraphs[0]
    hdr_p.clear()
    hdr_p.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
    run = hdr_p.add_run("ACME Aerospace  |  FEM Structural Analysis Report")
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    # ── Footer (page number) ──
    ftr = sec.footer
    ftr_p = ftr.paragraphs[0]
    ftr_p.clear()
    ftr_p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    ftr_p.add_run("Page ").font.size = Pt(9)
    _add_field(ftr_p, "PAGE")
    ftr_p.add_run(" of ").font.size = Pt(9)
    _add_field(ftr_p, "NUMPAGES")

    # ════════════════════════════════
    # PAGE 1 – Title page
    # ════════════════════════════════
    for _ in range(6):
        doc.add_paragraph()   # top whitespace

    title_p = doc.add_paragraph()
    title_p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    r = title_p.add_run("Finite Element Analysis Report")
    r.bold = True
    r.font.size = Pt(26)
    r.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6C)

    sub_p = doc.add_paragraph()
    sub_p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    rs = sub_p.add_run("Structural Static & Modal Analysis — Valve Assembly Rev B")
    rs.font.size = Pt(14)
    rs.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    doc.add_paragraph()

    meta_lines = [
        ("Assembly",     "Valve Rev B"),
        ("Analysis Tool","Ansys 2022R1"),
        ("Document No.", "FEA-2026-0042"),
        ("Revision",     "A"),
        ("Date",         "11 May 2026"),
        ("Prepared by",  "Srujan K S"),
        ("Approved by",  "— (pending)"),
        ("Classification", "CONFIDENTIAL"),
    ]
    tbl = doc.add_table(rows=len(meta_lines), cols=2)
    tbl.style = "Table Grid"
    for i, (k, v) in enumerate(meta_lines):
        cells = tbl.rows[i].cells
        cells[0].text = k
        cells[0].paragraphs[0].runs[0].bold = True
        cells[1].text = v
        for cell in cells:
            cell.paragraphs[0].runs[0].font.size = Pt(11)

    _add_page_break(doc)

    # ════════════════════════════════
    # PAGE 2 – Index / TOC placeholder
    # ════════════════════════════════
    toc_heading = doc.add_heading("Table of Contents", level=1)
    toc_heading.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT

    toc_entries = [
        ("1",   "Introduction"),
        ("1.1", "Objectives and Scope"),
        ("2",   "Finite Element Model Description"),
        ("2.1", "Geometry and Mesh"),
        ("2.2", "Element Types and Quality"),
        ("3",   "Material Properties"),
        ("4",   "Boundary Conditions and Loads"),
        ("5",   "Static Analysis"),
        ("5.1", "Stress Results"),
        ("5.2", "Displacement Results"),
        ("6",   "Modal Analysis"),
        ("6.1", "Natural Frequencies"),
        ("7",   "Mass Validation"),
        ("8",   "Conclusion"),
        ("",    "List of Tables"),
        ("",    "List of Figures"),
    ]
    for num, name in toc_entries:
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(
            Inches(5.5), WD_PARAGRAPH_ALIGNMENT.RIGHT  # type: ignore[arg-type]
        )
        label = f"{num}  {name}".strip() if num else name
        run_label = p.add_run(label)
        run_label.font.size = Pt(11)
        if not num:
            run_label.italic = True
        p.add_run("\t")
        run_pg = p.add_run()
        run_pg.font.size = Pt(11)
        # Insert a PAGE field placeholder (will show real page numbers when updated in Word)
        _add_field(p, "PAGE")

    note = doc.add_paragraph()
    note.add_run(
        "\n[Update this TOC in Word: select all (Ctrl+A) → Update Fields (F9)]"
    ).font.color.rgb = RGBColor(0x88, 0x88, 0x88)

    # Do NOT add a page-break here — docgen will insert template_pages=2 breaks itself
    doc.save(str(path))
    print(f"  template.docx written → {path}")


# ──────────────────────────────────────────────
# Math formula .docx snippets
# ──────────────────────────────────────────────

def _math_para(doc: Document, omml_xml: str) -> None:
    """Insert an OMML equation paragraph into doc."""
    p = doc.add_paragraph()
    p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    # Wrap bare oMath in oMathPara if needed
    if "<m:oMathPara" not in omml_xml:
        omml_xml = (
            '<m:oMathPara xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">'
            f"{omml_xml}"
            "</m:oMathPara>"
        )
    from lxml import etree
    elem = etree.fromstring(omml_xml)
    p._element.append(elem)


def _label_para(doc: Document, text: str) -> None:
    p = doc.add_paragraph(text)
    p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    p.runs[0].italic = True
    p.runs[0].font.size = Pt(10)


def _build_stiffness_docx(path: Path) -> None:
    """Global stiffness equation:  [K]{u} = {F}"""
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    intro = doc.add_paragraph(
        "The global static equilibrium equation assembled from all element stiffness "
        "contributions is:"
    )
    intro.runs[0].font.size = Pt(11)

    # OMML for  [K]{u} = {F}
    omml = """
<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
          xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <m:r><m:t>[K]</m:t></m:r>
  <m:r><m:t xml:space="preserve"> </m:t></m:r>
  <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>{u}</m:t></m:r>
  <m:r><m:t xml:space="preserve"> = </m:t></m:r>
  <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>{F}</m:t></m:r>
</m:oMath>
"""
    _math_para(doc, omml)
    _label_para(doc, "Equation (1): Global stiffness equation")

    desc = doc.add_paragraph(
        "where [K] is the global stiffness matrix (N/mm), {u} is the nodal displacement "
        "vector (mm), and {F} is the applied external force vector (N). The stiffness "
        "matrix is assembled by summing element stiffness matrices over all elements in "
        "the mesh."
    )
    desc.runs[0].font.size = Pt(11)
    doc.save(str(path))
    print(f"  stiffness_eq.docx written → {path}")


def _build_element_stiffness_docx(path: Path) -> None:
    """Element stiffness matrix integral:  [k]^e = ∫[B]^T[D][B] dV"""
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    intro = doc.add_paragraph(
        "The element stiffness matrix for each solid element is computed as the volume "
        "integral of the strain-displacement product:"
    )
    intro.runs[0].font.size = Pt(11)

    # OMML for  [k]^e = integral [B]^T [D] [B] dV
    omml = """
<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
          xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <m:sSup>
    <m:sSupPr><m:ctrlPr/></m:sSupPr>
    <m:e><m:r><m:t>[k]</m:t></m:r></m:e>
    <m:sup><m:r><m:t>e</m:t></m:r></m:sup>
  </m:sSup>
  <m:r><m:t xml:space="preserve"> = </m:t></m:r>
  <m:nary>
    <m:naryPr>
      <m:chr m:val="&#x222B;"/>
      <m:limLoc m:val="subSup"/>
      <m:subHide m:val="1"/>
      <m:supHide m:val="1"/>
    </m:naryPr>
    <m:sub><m:r><m:t/></m:r></m:sub>
    <m:sup><m:r><m:t/></m:r></m:sup>
    <m:e>
      <m:sSup>
        <m:sSupPr><m:ctrlPr/></m:sSupPr>
        <m:e><m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>[B]</m:t></m:r></m:e>
        <m:sup><m:r><m:t>T</m:t></m:r></m:sup>
      </m:sSup>
      <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>[D]</m:t></m:r>
      <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>[B]</m:t></m:r>
      <m:r><m:t xml:space="preserve"> dV</m:t></m:r>
    </m:e>
  </m:nary>
</m:oMath>
"""
    _math_para(doc, omml)
    _label_para(doc, "Equation (2): Element stiffness matrix")

    desc = doc.add_paragraph(
        "where [B] is the strain-displacement matrix, [D] is the material constitutive "
        "matrix (elasticity tensor), and dV is the differential element volume. "
        "Integration is performed numerically using Gauss quadrature at the integration "
        "points defined for each element type."
    )
    desc.runs[0].font.size = Pt(11)
    doc.save(str(path))
    print(f"  element_stiffness_eq.docx written → {path}")


def _build_modal_docx(path: Path) -> None:
    """Modal eigenvalue equation:  ([K] - ω²[M]){φ} = {0}"""
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    intro = doc.add_paragraph(
        "The undamped free-vibration eigenvalue problem solved during modal extraction is:"
    )
    intro.runs[0].font.size = Pt(11)

    # OMML for  ([K] - ω²[M]){φ} = {0}
    omml = """
<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
          xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <m:d>
    <m:dPr>
      <m:begChr m:val="("/>
      <m:endChr m:val=")"/>
    </m:dPr>
    <m:e>
      <m:r><m:t>[K]</m:t></m:r>
      <m:r><m:t xml:space="preserve"> &#x2212; </m:t></m:r>
      <m:sSup>
        <m:sSupPr><m:ctrlPr/></m:sSupPr>
        <m:e><m:r><m:t>&#x03C9;</m:t></m:r></m:e>
        <m:sup><m:r><m:t>2</m:t></m:r></m:sup>
      </m:sSup>
      <m:r><m:t>[M]</m:t></m:r>
    </m:e>
  </m:d>
  <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>{&#x03C6;}</m:t></m:r>
  <m:r><m:t xml:space="preserve"> = </m:t></m:r>
  <m:r><m:rPr><m:sty m:val="b"/></m:rPr><m:t>{0}</m:t></m:r>
</m:oMath>
"""
    _math_para(doc, omml)
    _label_para(doc, "Equation (3): Eigenvalue equation for modal analysis")

    desc = doc.add_paragraph(
        "where [K] is the global stiffness matrix, [M] is the global mass matrix, "
        "ω is the circular natural frequency (rad/s), and {φ} is the corresponding "
        "mode shape vector. The Block Lanczos solver is used to extract the first "
        "10 natural frequencies and their associated mode shapes."
    )
    desc.runs[0].font.size = Pt(11)
    doc.save(str(path))
    print(f"  modal_eq.docx written → {path}")


def _build_mass_validation_docx(path: Path) -> None:
    """Mass relative difference formula:  δ = (m_model - m_physical) / m_physical"""
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    intro = doc.add_paragraph(
        "The relative mass difference between the FE model and the physical part is "
        "used as a mesh and density quality check:"
    )
    intro.runs[0].font.size = Pt(11)

    # OMML for  δ = (m_model − m_physical) / m_physical
    omml = """
<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
          xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <m:r><m:t>&#x03B4;</m:t></m:r>
  <m:r><m:t xml:space="preserve"> = </m:t></m:r>
  <m:f>
    <m:fPr><m:ctrlPr/></m:fPr>
    <m:num>
      <m:r><m:t>m</m:t></m:r>
      <m:r><m:rPr><m:vertAlign m:val="subscript"/></m:rPr><m:t>model</m:t></m:r>
      <m:r><m:t xml:space="preserve"> &#x2212; m</m:t></m:r>
      <m:r><m:rPr><m:vertAlign m:val="subscript"/></m:rPr><m:t>physical</m:t></m:r>
    </m:num>
    <m:den>
      <m:r><m:t>m</m:t></m:r>
      <m:r><m:rPr><m:vertAlign m:val="subscript"/></m:rPr><m:t>physical</m:t></m:r>
    </m:den>
  </m:f>
</m:oMath>
"""
    _math_para(doc, omml)
    _label_para(doc, "Equation (4): Relative mass difference")

    desc = doc.add_paragraph(
        "A relative mass difference within ±5% is considered acceptable for structural "
        "FE analysis. Values outside this range may indicate mesh defects, incorrect "
        "density assignment, or geometry simplification errors and must be investigated "
        "before results are accepted."
    )
    desc.runs[0].font.size = Pt(11)
    doc.save(str(path))
    print(f"  mass_validation_eq.docx written → {path}")


# ──────────────────────────────────────────────
# Figures (PNG)
# ──────────────────────────────────────────────

_FIG_PALETTE = {
    "mesh":     ((26,  58, 108), (173, 216, 230)),
    "bc":       ((139,  0,   0), (255, 200, 200)),
    "stress":   ((180, 60,   0), (255, 220, 180)),
    "modal":    ((22, 100,  60), (180, 240, 210)),
    "mass":     ((80,  30, 140), (220, 190, 255)),
}


def _fig(path: Path, title: str, subtitle: str, palette_key: str) -> None:
    fg, bg = _FIG_PALETTE[palette_key]
    im = Image.new("RGB", (1024, 600), (248, 250, 252))
    dr = ImageDraw.Draw(im)
    # Background band
    dr.rectangle((0, 0, 1024, 80), fill=fg)
    # Title bar text
    dr.text((20, 22), title, fill=(255, 255, 255), font=_font(24))
    # Inner box
    dr.rectangle((20, 100, 1004, 560), fill=bg, outline=fg, width=3)
    # Subtitle
    dr.text((40, 130), subtitle, fill=fg, font=_font(18))
    # Decorative grid lines (simulate FEM mesh / chart)
    for x in range(40, 1004, 80):
        dr.line([(x, 180), (x, 540)], fill=(*fg, 60), width=1)
    for y in range(200, 560, 60):
        dr.line([(40, y), (1000, y)], fill=(*fg, 60), width=1)
    dr.text((40, 555), f"docgen FEM sample — {path.stem}", fill=(120, 120, 120), font=_font(13))
    im.save(path)


# ──────────────────────────────────────────────
# CSVs
# ──────────────────────────────────────────────

def _write_element_quality_csv(path: Path) -> None:
    rows = []
    types = ["Hex20", "Tet10", "kHex8"]
    counts = [980000, 112000, 20425]
    for i, (et, cnt) in enumerate(zip(types, counts)):
        rows.append({
            "element_type": et,
            "count": cnt,
            "avg_aspect_ratio": round(1.8 + i * 0.4, 2),
            "max_aspect_ratio": round(4.2 + i * 1.1, 2),
            "avg_jacobian": round(0.92 - i * 0.04, 3),
            "min_jacobian": round(0.71 - i * 0.05, 3),
            "skewness_avg": round(0.12 + i * 0.05, 3),
            "pass_threshold": "Yes" if i < 2 else "Review",
        })
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_material_csv(path: Path) -> None:
    rows = [
        {"material": "Steel (AISI 4340)", "part": "Valve body",     "density_kg_m3": 7850,  "E_GPa": 205,  "nu": 0.29, "Sy_MPa": 470},
        {"material": "Steel (AISI 4340)", "part": "Stem",           "density_kg_m3": 7850,  "E_GPa": 205,  "nu": 0.29, "Sy_MPa": 470},
        {"material": "Inconel 718",       "part": "Spring retainer","density_kg_m3": 8190,  "E_GPa": 200,  "nu": 0.29, "Sy_MPa": 1035},
        {"material": "PTFE",              "part": "Seat ring",      "density_kg_m3":  2200, "E_GPa":   0.5,"nu": 0.46, "Sy_MPa":  14},
        {"material": "Stainless 316L",    "part": "Bolting",        "density_kg_m3": 7990,  "E_GPa": 193,  "nu": 0.27, "Sy_MPa": 170},
    ]
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_bc_csv(path: Path) -> None:
    rows = [
        {"load_case": "LC-01 Design Pressure", "type": "Pressure", "value": "250 bar",   "surface": "Inlet bore",       "note": "Static"},
        {"load_case": "LC-01 Design Pressure", "type": "Pressure", "value": "250 bar",   "surface": "Bonnet face",       "note": "Static"},
        {"load_case": "LC-01 Design Pressure", "type": "Fixed BC", "value": "UX=UY=UZ=0","surface": "Flange bolt holes", "note": "Fixed support"},
        {"load_case": "LC-02 Thermal",         "type": "Temp",     "value": "180 °C",    "surface": "All bodies",        "note": "Uniform"},
        {"load_case": "LC-02 Thermal",         "type": "Fixed BC", "value": "UX=UY=UZ=0","surface": "Flange bolt holes", "note": "Fixed support"},
        {"load_case": "LC-03 Modal",           "type": "Fixed BC", "value": "UX=UY=UZ=0","surface": "Flange bolt holes", "note": "Free vibration"},
    ]
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_stress_csv(path: Path) -> None:
    rows = [
        {"load_case": "LC-01", "component": "Valve body",     "max_vonMises_MPa": 312.4, "location": "Bore–body fillet", "allowable_MPa": 376, "util_pct": 83.1, "pass": "Yes"},
        {"load_case": "LC-01", "component": "Stem",           "max_vonMises_MPa": 198.7, "location": "Thread root",      "allowable_MPa": 376, "util_pct": 52.8, "pass": "Yes"},
        {"load_case": "LC-01", "component": "Spring retainer","max_vonMises_MPa": 540.2, "location": "Locking groove",   "allowable_MPa": 828, "util_pct": 65.2, "pass": "Yes"},
        {"load_case": "LC-02", "component": "Valve body",     "max_vonMises_MPa": 274.1, "location": "Body–bonnet face", "allowable_MPa": 376, "util_pct": 72.9, "pass": "Yes"},
        {"load_case": "LC-02", "component": "Seat ring",      "max_vonMises_MPa":   8.9, "location": "Contact face",     "allowable_MPa":  11, "util_pct": 80.9, "pass": "Yes"},
    ]
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_displacement_csv(path: Path) -> None:
    rows = [
        {"load_case": "LC-01", "component": "Valve body",     "max_disp_mm": 0.142, "direction": "Radial",   "limit_mm": 0.5,  "pass": "Yes"},
        {"load_case": "LC-01", "component": "Stem",           "max_disp_mm": 0.037, "direction": "Axial",    "limit_mm": 0.25, "pass": "Yes"},
        {"load_case": "LC-01", "component": "Seat ring",      "max_disp_mm": 0.091, "direction": "Axial",    "limit_mm": 0.2,  "pass": "Yes"},
        {"load_case": "LC-02", "component": "Valve body",     "max_disp_mm": 0.318, "direction": "Radial",   "limit_mm": 0.5,  "pass": "Yes"},
        {"load_case": "LC-02", "component": "Stem",           "max_disp_mm": 0.054, "direction": "Axial",    "limit_mm": 0.25, "pass": "Yes"},
    ]
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_modal_csv(path: Path) -> None:
    rows = []
    freqs_hz = [412.3, 487.6, 521.0, 689.4, 742.1, 818.5, 903.2, 961.7, 1024.8, 1187.3]
    modes    = ["1st bending X", "1st bending Y", "Torsion Z", "2nd bending X",
                "2nd bending Y", "Axial", "3rd bending X", "3rd bending Y",
                "Combined", "4th bending X"]
    for i, (f, m) in enumerate(zip(freqs_hz, modes), start=1):
        rows.append({
            "mode": i,
            "frequency_Hz": f,
            "omega_rad_s": round(f * 6.2832, 1),
            "mode_description": m,
            "participation_factor": round(0.95 - i * 0.04, 3),
            "cumulative_mass_pct": round(min(100, 40 + i * 6.5), 1),
        })
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_mass_csv(path: Path) -> None:
    rows = [
        {"component": "Valve body",      "model_mass_kg": 2.3141, "physical_mass_kg": 2.35, "rel_diff_pct": -1.53, "density_adj": None,    "status": "Pass"},
        {"component": "Stem",            "model_mass_kg": 0.4812, "physical_mass_kg": 0.49, "rel_diff_pct": -1.80, "density_adj": None,    "status": "Pass"},
        {"component": "Spring retainer", "model_mass_kg": 0.1043, "physical_mass_kg": 0.10, "rel_diff_pct":  4.30, "density_adj": None,    "status": "Pass"},
        {"component": "Seat ring",       "model_mass_kg": 0.0612, "physical_mass_kg": 0.06, "rel_diff_pct":  2.00, "density_adj": None,    "status": "Pass"},
        {"component": "Bolting (total)", "model_mass_kg": 1.2148, "physical_mass_kg": 1.50, "rel_diff_pct":-19.01, "density_adj": 1.235,   "status": "Adjusted"},
        {"component": "TOTAL ASSEMBLY",  "model_mass_kg": 4.1796, "physical_mass_kg": 5.00, "rel_diff_pct":-16.41, "density_adj": "—",     "status": "See note"},
    ]
    pd.DataFrame(rows).to_csv(path, index=False)


# ──────────────────────────────────────────────
# bundle.json
# ──────────────────────────────────────────────

def _build_json() -> dict:
    return {
        # Section 1 – Intro
        "intro_llm": {
            "assembly_name": "Valve Rev B",
            "analysis_tool": "Ansys",
            "version": "2022R1",
            "number_of_elements": 1112425,
            "number_of_nodes": 1760037,
            "element_types": ["20 noded Hexahedral Element", "10 noded Tetrahedral Element", "kHex8"],
            "mass_unit": "kg",
            "model_mass": 4.179616176792575,
            "physical_mass": 5.0,
            "relative_difference": -0.16407676464148507,
            "density_adjustment": None,
            "figure": "fig_mesh.png",
            "table": "element_quality.csv",
        },
        # Section 2 – FEM Model
        "mesh_llm": {
            "total_elements": 1112425,
            "total_nodes": 1760037,
            "hex20_count": 980000,
            "tet10_count": 112000,
            "khex8_count": 20425,
            "avg_aspect_ratio": 1.8,
            "min_jacobian_overall": 0.61,
            "mesh_quality_verdict": "Acceptable — all metrics within Ansys defaults",
            "figure": "fig_mesh.png",
            "table": "element_quality.csv",
        },
        # Section 3 – Materials
        "materials_llm": {
            "primary_material": "AISI 4340 Steel",
            "E_GPa": 205,
            "nu": 0.29,
            "density_kg_m3": 7850,
            "Sy_MPa": 470,
            "special_materials": ["Inconel 718 (spring retainer)", "PTFE (seat ring)"],
            "table": "material_properties.csv",
        },
        # Section 4 – Boundary Conditions
        "bc_llm": {
            "load_cases": ["LC-01 Design Pressure (250 bar)", "LC-02 Thermal (180°C)", "LC-03 Modal"],
            "fixed_support": "Flange bolt holes — all DOF fixed",
            "pressure_surfaces": ["Inlet bore", "Bonnet face"],
            "table": "boundary_conditions.csv",
            "figure": "fig_bc.png",
        },
        # Section 5 – Static Results
        "static_stress_llm": {
            "max_vonMises_MPa": 540.2,
            "max_vonMises_component": "Spring retainer — locking groove",
            "allowable_MPa": 828,
            "utilisation_pct": 65.2,
            "overall_verdict": "All components within allowable stress limits",
            "figure": "fig_stress.png",
            "table": "stress_results.csv",
        },
        "static_disp_llm": {
            "max_displacement_mm": 0.318,
            "max_disp_component": "Valve body — radial, LC-02 Thermal",
            "disp_limit_mm": 0.5,
            "verdict": "All displacements within functional limits",
            "table": "displacement_results.csv",
        },
        # Section 6 – Modal
        "modal_llm": {
            "solver": "Block Lanczos",
            "modes_extracted": 10,
            "first_natural_freq_Hz": 412.3,
            "first_mode_description": "1st bending X",
            "cumulative_mass_pct_10modes": 97.5,
            "excitation_frequency_Hz": 50.0,
            "margin_to_excitation_pct": round((412.3 - 50.0) / 50.0 * 100, 1),
            "figure": "fig_modal.png",
            "table": "modal_frequencies.csv",
        },
        # Section 7 – Mass
        "mass_llm": {
            "model_mass_total_kg": 4.179616176792575,
            "physical_mass_total_kg": 5.0,
            "relative_difference_pct": -16.41,
            "bolting_density_adjustment_factor": 1.235,
            "mass_check_criterion_pct": 5.0,
            "note": "Bolting simplified as solid rods; density adjusted to match physical mass.",
            "table": "mass_validation.csv",
            "figure": "fig_mass.png",
        },
        # Section 8 – Conclusion
        "conclusion_llm": {
            "overall_verdict": "Pass",
            "stress_status": "All within allowable — max utilisation 65.2% (spring retainer)",
            "displacement_status": "All within functional limits",
            "modal_status": "1st mode at 412.3 Hz — adequate margin over 50 Hz excitation",
            "mass_status": "Density adjustment applied to bolting; total model mass acceptable",
            "next_steps": "Issue report for design review; update model if geometry Rev C is released",
            "figure": "fig_stress.png",
        },
    }


# ──────────────────────────────────────────────
# YAML structure template
# ──────────────────────────────────────────────

YAML_CONTENT = """\
title: "Finite Element Analysis Report — Valve Rev B"

sections:
  - number: "1"
    Section_name: Introduction
    elements:
      - kind: paragraph
        para_prompt: >-
          Write seven to ten sentences providing an executive introduction to this FEM
          structural analysis. State the assembly name, analysis tool, version, element
          count, and node count. Reference Figure 1 (mesh overview) and Table 1
          (element quality). Ground every claim in the JSON facts only.
        para_input_from_json: intro_llm

  - number: "2"
    Section_name: Finite Element Model Description
    elements:
      - kind: paragraph
        para_prompt: >-
          Write six to nine sentences describing the FE model: total elements, total nodes,
          element types used (Hex20, Tet10, kHex8), and overall mesh quality verdict.
          Cite Figure 1 and Table 1. Use only JSON facts.
        para_input_from_json: mesh_llm
      - kind: image
        img_path: images/fig_mesh.png
        img_name: FE Mesh Overview — Valve Rev B
      - kind: table
        csv_path: tables/element_quality.csv
        table_name: Element Type and Mesh Quality Summary
      - kind: math
        docx_path: formulas/stiffness_eq.docx
        derivation_docx_paths:
          - formulas/element_stiffness_eq.docx
        caption: "Global and Element Stiffness Equations"
    sections:
      - number: "2.1"
        Section_name: Geometry and Mesh
        elements:
          - kind: paragraph_file
            text_path: content/mesh_detail.txt
      - number: "2.2"
        Section_name: Element Types and Quality
        elements:
          - kind: paragraph_file
            text_path: content/element_types.txt

  - number: "3"
    Section_name: Material Properties
    elements:
      - kind: paragraph
        para_prompt: >-
          Write five to eight sentences describing the materials assigned in the model.
          Cover the primary material (AISI 4340 Steel), its elastic modulus, Poisson ratio,
          density, and yield strength. Mention special materials for specific components.
          Cite Table 2. Use only JSON facts.
        para_input_from_json: materials_llm
      - kind: table
        csv_path: tables/material_properties.csv
        table_name: Material Properties by Component

  - number: "4"
    Section_name: Boundary Conditions and Loads
    elements:
      - kind: paragraph
        para_prompt: >-
          Write five to eight sentences describing the load cases, supports, and applied
          pressures and thermal loads. Cite Figure 2 and Table 3. Use only JSON facts.
        para_input_from_json: bc_llm
      - kind: image
        img_path: images/fig_bc.png
        img_name: Boundary Conditions and Applied Loads
      - kind: table
        csv_path: tables/boundary_conditions.csv
        table_name: Boundary Conditions and Load Cases

  - number: "5"
    Section_name: Static Analysis Results
    elements:
      - kind: paragraph_file
        text_path: content/static_intro.txt
    sections:
      - number: "5.1"
        Section_name: Stress Results
        elements:
          - kind: paragraph
            para_prompt: >-
              Write six to nine sentences summarising von Mises stress results across all
              components and load cases. State the maximum stress, its location, the
              allowable stress, and utilisation percentage. Cite Figure 3 and Table 4.
              Use only JSON facts.
            para_input_from_json: static_stress_llm
          - kind: image
            img_path: images/fig_stress.png
            img_name: Von Mises Stress Distribution — LC-01 Design Pressure
          - kind: table
            csv_path: tables/stress_results.csv
            table_name: Stress Results Summary by Component and Load Case
      - number: "5.2"
        Section_name: Displacement Results
        elements:
          - kind: paragraph
            para_prompt: >-
              Write four to seven sentences summarising displacement results. State the
              maximum displacement, its component and direction, and the functional limit.
              Cite Table 5. Use only JSON facts.
            para_input_from_json: static_disp_llm
          - kind: table
            csv_path: tables/displacement_results.csv
            table_name: Displacement Results Summary

  - number: "6"
    Section_name: Modal Analysis
    elements:
      - kind: paragraph
        para_prompt: >-
          Write six to nine sentences describing the modal analysis setup and results.
          State the solver, number of modes extracted, first natural frequency, first mode
          description, cumulative effective mass, and margin over the 50 Hz excitation
          frequency. Cite Figure 4 and Table 6. Use only JSON facts.
        para_input_from_json: modal_llm
      - kind: math
        docx_path: formulas/modal_eq.docx
        caption: "Eigenvalue Equation — Modal Analysis"
      - kind: image
        img_path: images/fig_modal.png
        img_name: Mode Shapes — First Four Natural Frequencies
      - kind: table
        csv_path: tables/modal_frequencies.csv
        table_name: Extracted Natural Frequencies and Mode Descriptions

  - number: "7"
    Section_name: Mass Validation
    elements:
      - kind: paragraph
        para_prompt: >-
          Write five to eight sentences on model mass validation. State the model mass,
          physical mass, relative difference percentage, and the ±5% acceptance criterion.
          Explain the density adjustment applied to bolting and its justification.
          Cite Table 7. Use only JSON facts.
        para_input_from_json: mass_llm
      - kind: math
        docx_path: formulas/mass_validation_eq.docx
        caption: "Relative Mass Difference Formula"
      - kind: image
        img_path: images/fig_mass.png
        img_name: Model vs Physical Mass — Component Breakdown
      - kind: table
        csv_path: tables/mass_validation.csv
        table_name: Mass Validation by Component

  - number: "8"
    Section_name: Conclusion
    elements:
      - kind: paragraph
        para_prompt: >-
          Write six to nine sentences summarising the overall analysis conclusions.
          Confirm pass/fail for stress, displacement, modal margin, and mass validation.
          State next steps. Reference Figure 3 (stress) where appropriate.
          Use only JSON facts.
        para_input_from_json: conclusion_llm
"""


# ──────────────────────────────────────────────
# Content text files
# ──────────────────────────────────────────────

def _mesh_detail_txt() -> str:
    return (
        "The Valve Rev B assembly geometry was imported from the CAD system as a STEP file and "
        "prepared for meshing in Ansys Mechanical 2022R1. All small features below 0.5 mm radius "
        "were suppressed in agreement with the project mesh specification document. Contact "
        "interfaces between the valve body, seat ring, and bolting were defined as bonded to "
        "represent the fully assembled and torqued condition.\n\n"
        "Mesh controls were applied at critical stress concentration regions including the "
        "bore–body fillet, the stem thread root, and the spring retainer locking groove. "
        "A global element size of 3 mm was used for low-gradient regions, reducing to 0.8 mm "
        "at high-gradient regions. Mesh convergence was confirmed by comparing von Mises peak "
        "stress between the coarse and fine meshes; variation was within 2.1%, confirming "
        "mesh-independent results."
    )


def _element_types_txt() -> str:
    return (
        "The mesh comprises three element types. Twenty-noded hexahedral elements (Hex20 / "
        "SOLID186) form the bulk of the mesh and provide superior accuracy for bending-dominated "
        "regions. Ten-noded tetrahedral elements (Tet10 / SOLID187) are used in transitional "
        "zones and complex curvatures where structured hexahedral meshing is not feasible. "
        "The kHex8 elements appear at the bolt shank cross-sections due to geometric constraints.\n\n"
        "All element quality metrics — aspect ratio, Jacobian ratio, and skewness — were "
        "evaluated against the Ansys default thresholds. The minimum Jacobian ratio across the "
        "assembly is 0.61, which is within the acceptable range of >0.5. No negative Jacobian "
        "elements were present. The mesh quality is therefore considered acceptable for the "
        "intended stress and modal analyses."
    )


def _static_intro_txt() -> str:
    return (
        "Static structural analyses were performed for two load cases: LC-01 (Design Pressure "
        "250 bar) and LC-02 (Operating Thermal 180 °C). In each case the analysis was run as a "
        "linear elastic simulation. Material non-linearity and large displacement effects were "
        "not considered, consistent with the design-stage assessment objectives and the applied "
        "safety factors in the allowable stress limits.\n\n"
        "Results are reported as von Mises equivalent stress and total directional displacement "
        "for each component. Allowable stress values are taken as 80% of the material yield "
        "strength at operating temperature, per the applicable design code. Components with "
        "utilisation above 80% of the allowable are flagged for further review."
    )


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────

def main() -> None:
    print("Building FEM sample assets …")

    # Directory layout
    content  = BUNDLE_DIR / "content"
    tables   = BUNDLE_DIR / "tables"
    images   = BUNDLE_DIR / "images"
    formulas = BUNDLE_DIR / "formulas"
    for d in (content, tables, images, formulas):
        d.mkdir(parents=True, exist_ok=True)

    # ── Template (title page + index page) ──
    _build_template(BUNDLE_DIR / "template.docx")

    # ── Math formula snippets ──
    _build_stiffness_docx(formulas / "stiffness_eq.docx")
    _build_element_stiffness_docx(formulas / "element_stiffness_eq.docx")
    _build_modal_docx(formulas / "modal_eq.docx")
    _build_mass_validation_docx(formulas / "mass_validation_eq.docx")

    # ── Content text files ──
    (content / "mesh_detail.txt").write_text(_mesh_detail_txt(), encoding="utf-8")
    (content / "element_types.txt").write_text(_element_types_txt(), encoding="utf-8")
    (content / "static_intro.txt").write_text(_static_intro_txt(), encoding="utf-8")

    # ── CSVs ──
    _write_element_quality_csv(tables / "element_quality.csv")
    _write_material_csv(tables / "material_properties.csv")
    _write_bc_csv(tables / "boundary_conditions.csv")
    _write_stress_csv(tables / "stress_results.csv")
    _write_displacement_csv(tables / "displacement_results.csv")
    _write_modal_csv(tables / "modal_frequencies.csv")
    _write_mass_csv(tables / "mass_validation.csv")

    # ── Figures ──
    _fig(images / "fig_mesh.png",   "FE Mesh Overview",              "Valve Rev B — Ansys 2022R1",            "mesh")
    _fig(images / "fig_bc.png",     "Boundary Conditions & Loads",   "LC-01 Design Pressure 250 bar",          "bc")
    _fig(images / "fig_stress.png", "Von Mises Stress Distribution", "LC-01 — Max 540.2 MPa (Spring Retainer)","stress")
    _fig(images / "fig_modal.png",  "Mode Shapes Overview",          "Modes 1–4 | 1st: 412.3 Hz",             "modal")
    _fig(images / "fig_mass.png",   "Mass Validation",               "Model vs Physical (kg)",                  "mass")

    # ── bundle.json ──
    (BUNDLE_DIR / "bundle.json").write_text(
        json.dumps(_build_json(), indent=2, ensure_ascii=False), encoding="utf-8"
    )

    # ── ZIP ──
    ZIP_PATH.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in BUNDLE_DIR.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(BUNDLE_DIR).as_posix())
    print(f"  fem_report.zip written → {ZIP_PATH}")

    # ── YAML ──
    YAML_PATH.write_text(YAML_CONTENT, encoding="utf-8")
    print(f"  fem_report.yaml written → {YAML_PATH}")

    print()
    print("Done. Now run:")
    print(f"  python -m docgen --zip {ZIP_PATH} --yaml {YAML_PATH} --out example/fem_report.docx --no-llm")
    print("Or with LLM (set GEMINI_API_KEY first):")
    print(f"  python -m docgen --zip {ZIP_PATH} --yaml {YAML_PATH} --out example/fem_report.docx")


if __name__ == "__main__":
    main()

"""
Build Harmonic Analysis sample assets and example/harmonic_report.zip.

Produces:
  example/harmonic_bundle/     ← extracted assets (inspect / edit freely)
  example/harmonic_report.zip  ← bundle fed to docgen
  example/harmonic_report.yaml ← YAML using 'repeat' + 'multi_table'

Usage:
  python tools/build_harmonic_example.py
  python -m docgen --zip example/harmonic_report.zip \\
                   --yaml example/harmonic_report.yaml \\
                   --out  example/harmonic_report.docx \\
                   --no-llm

The template.docx already contains:
  Page 1 – Title page
  Page 2 – TOC placeholder
Generated content starts from page 3 (default --template-pages 2 behaviour).

Requires: python-docx, pillow, pandas
  pip install -e ".[dev]"
"""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw

ROOT        = Path(__file__).resolve().parents[1]
BUNDLE_DIR  = ROOT / "example" / "harmonic_bundle"
ZIP_PATH    = ROOT / "example" / "harmonic_report.zip"
YAML_PATH   = ROOT / "example" / "harmonic_report.yaml"

DIRECTIONS  = ["x", "y", "z"]
DIR_LABELS  = {"x": "X Direction", "y": "Y Direction", "z": "Z Direction"}

# ── colour palette per direction ──────────────────────────────────────────────
PALETTE = {
    "x": ((26, 58, 108),  (200, 220, 245)),
    "y": ((100, 40, 120), (230, 210, 245)),
    "z": ((20, 100, 60),  (200, 240, 215)),
}

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _add_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    br = OxmlElement("w:br")
    br.set(qn("w:type"), "page")
    run._r.append(br)


def _add_field(paragraph, field_code: str) -> None:
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {field_code} "
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)


def _font(size: int = 18):
    from PIL import ImageFont
    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


# ─────────────────────────────────────────────────────────────────────────────
# Template .docx  (title page + TOC page)
# ─────────────────────────────────────────────────────────────────────────────

def _build_template(path: Path) -> None:
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)

    sec = doc.sections[0]
    sec.top_margin    = Inches(1.0)
    sec.bottom_margin = Inches(1.0)
    sec.left_margin   = Inches(1.25)
    sec.right_margin  = Inches(1.25)

    # Header
    hdr_p = sec.header.paragraphs[0]
    hdr_p.clear()
    hdr_p.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
    run = hdr_p.add_run("ACME Aerospace  |  Harmonic Structural Analysis Report")
    run.font.name = "Calibri"
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    # Footer
    ftr_p = sec.footer.paragraphs[0]
    ftr_p.clear()
    ftr_p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    ftr_p.add_run("Page ").font.size = Pt(9)
    _add_field(ftr_p, "PAGE")
    ftr_p.add_run(" of ").font.size = Pt(9)
    _add_field(ftr_p, "NUMPAGES")

    # ── Page 1: Title ──
    for _ in range(5):
        doc.add_paragraph()

    tp = doc.add_paragraph()
    tp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    r = tp.add_run("Harmonic Response Analysis Report")
    r.bold = True
    r.font.size = Pt(26)
    r.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6C)

    sp = doc.add_paragraph()
    sp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    sp.add_run("X / Y / Z Direction Harmonic Excitation — Valve Assembly Rev B").font.size = Pt(13)

    doc.add_paragraph()

    meta = [
        ("Assembly",        "Valve Rev B"),
        ("Analysis Type",   "Harmonic Response"),
        ("Frequency Range", "0 – 500 Hz"),
        ("Analysis Tool",   "Ansys 2022R1"),
        ("Document No.",    "HAR-2026-0007"),
        ("Revision",        "A"),
        ("Date",            "20 May 2026"),
        ("Prepared by",     "Srujan K S"),
        ("Classification",  "CONFIDENTIAL"),
    ]
    tbl = doc.add_table(rows=len(meta), cols=2)
    tbl.style = "Table Grid"
    for i, (k, v) in enumerate(meta):
        cells = tbl.rows[i].cells
        cells[0].text = k
        cells[0].paragraphs[0].runs[0].bold = True
        cells[1].text = v
        for cell in cells:
            cell.paragraphs[0].runs[0].font.size = Pt(11)

    _add_page_break(doc)

    # ── Page 2: TOC placeholder ──
    toc_h = doc.add_heading("Table of Contents", level=1)
    toc_h.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT

    toc_entries = [
        ("1",     "Introduction"),
        ("2",     "FE Model Description"),
        ("3",     "Harmonic Analysis"),
        ("3.1",   "Modal Extraction"),
        ("3.2",   "Damping"),
        ("3.3",   "Frequency Sweep"),
        ("3.4",   "Static Pre-stress"),
        ("3.5",   "Mode Superposition Settings"),
        ("3.6",   "X Direction Harmonic Excitation"),
        ("3.6.1", "Loads"),
        ("3.6.2", "Boundary Conditions"),
        ("3.6.3", "Analysis Results"),
        ("3.6.4", "Analysis Results Details"),
        ("3.7",   "Y Direction Harmonic Excitation"),
        ("3.8",   "Z Direction Harmonic Excitation"),
        ("4",     "Conclusion"),
        ("",      "List of Tables"),
        ("",      "List of Figures"),
    ]
    for num, name in toc_entries:
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(
            Inches(5.5), WD_PARAGRAPH_ALIGNMENT.RIGHT  # type: ignore[arg-type]
        )
        label = f"{num}  {name}".strip() if num else name
        run_label = p.add_run(label)
        run_label.font.size = Pt(11)
        if not num:
            run_label.italic = True
        p.add_run("\t")
        _add_field(p, "PAGE")

    doc.save(str(path))
    print(f"  template.docx → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# PNG figures
# ─────────────────────────────────────────────────────────────────────────────

def _make_fig(path: Path, title: str, subtitle: str, direction: str) -> None:
    fg, bg = PALETTE[direction]
    im = Image.new("RGB", (1024, 580), (248, 250, 252))
    dr = ImageDraw.Draw(im)
    dr.rectangle((0, 0, 1024, 75), fill=fg)
    dr.text((18, 20), title, fill=(255, 255, 255), font=_font(22))
    dr.rectangle((18, 95, 1006, 550), fill=bg, outline=fg, width=3)
    dr.text((36, 115), subtitle, fill=fg, font=_font(17))

    # Simulated frequency response curve
    import math
    pts = []
    for i in range(0, 970, 5):
        freq = i / 2.0
        amp = 0.8 / (abs((freq - 180) ** 2 - 50 ** 2) / 10000 + 0.05)
        amp2 = 0.4 / (abs((freq - 320) ** 2 - 30 ** 2) / 10000 + 0.08)
        y = min(400, amp + amp2)
        pts.append((36 + i, 520 - int(y * 50)))
    for i in range(len(pts) - 1):
        dr.line([pts[i], pts[i + 1]], fill=fg, width=2)

    dr.text((36, 552), f"docgen harmonic sample — {path.stem}", fill=(130, 130, 130), font=_font(12))
    im.save(path)


def _make_mesh_fig(path: Path) -> None:
    fg, bg = (26, 58, 108), (200, 220, 245)
    im = Image.new("RGB", (1024, 580), (248, 250, 252))
    dr = ImageDraw.Draw(im)
    dr.rectangle((0, 0, 1024, 75), fill=fg)
    dr.text((18, 20), "FE Mesh — Valve Rev B", fill=(255, 255, 255), font=_font(22))
    dr.rectangle((18, 95, 1006, 550), fill=bg, outline=fg, width=3)
    for x in range(40, 1000, 60):
        dr.line([(x, 110), (x, 540)], fill=(100, 140, 180), width=1)
    for y in range(120, 545, 45):
        dr.line([(30, y), (1000, y)], fill=(100, 140, 180), width=1)
    dr.text((36, 552), f"docgen harmonic sample — {path.stem}", fill=(130, 130, 130), font=_font(12))
    im.save(path)


# ─────────────────────────────────────────────────────────────────────────────
# CSVs
# ─────────────────────────────────────────────────────────────────────────────

def _csv_element_quality(path: Path) -> None:
    pd.DataFrame([
        {"element_type": "Hex20",  "count": 980000, "avg_AR": 1.8, "min_Jac": 0.72, "skewness": 0.12, "status": "Pass"},
        {"element_type": "Tet10",  "count": 112000, "avg_AR": 2.2, "min_Jac": 0.68, "skewness": 0.17, "status": "Pass"},
        {"element_type": "kHex8",  "count":  20425, "avg_AR": 2.6, "min_Jac": 0.61, "skewness": 0.22, "status": "Review"},
    ]).to_csv(path, index=False)


def _csv_modal(path: Path) -> None:
    freqs = [412.3, 487.6, 521.0, 689.4, 742.1, 818.5, 903.2, 961.7, 1024.8, 1187.3]
    modes = ["1st bending X", "1st bending Y", "Torsion Z", "2nd bending X",
             "2nd bending Y", "Axial", "3rd bending X", "3rd bending Y", "Combined", "4th bending X"]
    pd.DataFrame([
        {"mode": i + 1, "freq_Hz": f, "omega_rad_s": round(f * 6.2832, 1),
         "description": m, "cumulative_mass_pct": round(min(100, 40 + (i + 1) * 6.5), 1)}
        for i, (f, m) in enumerate(zip(freqs, modes))
    ]).to_csv(path, index=False)


def _csv_damping(path: Path) -> None:
    pd.DataFrame([
        {"component": "Valve body",      "damping_ratio": 0.02, "model": "Constant"},
        {"component": "Stem",            "damping_ratio": 0.02, "model": "Constant"},
        {"component": "Spring retainer", "damping_ratio": 0.03, "model": "Constant"},
        {"component": "Seat ring",       "damping_ratio": 0.05, "model": "Rayleigh"},
        {"component": "Bolting",         "damping_ratio": 0.02, "model": "Constant"},
    ]).to_csv(path, index=False)


def _csv_freq_sweep(path: Path) -> None:
    pd.DataFrame([
        {"freq_range_Hz": "0–100",   "step_Hz": 2.0, "points": 50,  "solver": "Mode Superposition"},
        {"freq_range_Hz": "100–300", "step_Hz": 1.0, "points": 200, "solver": "Mode Superposition"},
        {"freq_range_Hz": "300–500", "step_Hz": 2.0, "points": 100, "solver": "Mode Superposition"},
    ]).to_csv(path, index=False)


def _csv_loads(path: Path, d: str) -> None:
    amp = {"x": 1.0, "y": 0.8, "z": 0.5}[d]
    pd.DataFrame([
        {"load_id": f"LD-{d.upper()}-01", "type": "Base Excitation", "direction": d.upper(),
         "amplitude_g": amp, "phase_deg": 0.0,  "surface": "Flange base"},
        {"load_id": f"LD-{d.upper()}-02", "type": "Inertia Relief",  "direction": d.upper(),
         "amplitude_g": amp, "phase_deg": 180.0, "surface": "All bodies"},
    ]).to_csv(path, index=False)


def _csv_bc(path: Path, d: str) -> None:
    pd.DataFrame([
        {"bc_id": f"BC-{d.upper()}-01", "type": "Fixed Support",      "dof": "UX=UY=UZ=0",    "surface": "Flange bolt holes"},
        {"bc_id": f"BC-{d.upper()}-02", "type": "Displacement Driver", "dof": f"U{d.upper()}≠0", "surface": "Flange base"},
    ]).to_csv(path, index=False)


def _csv_results(path: Path, d: str) -> None:
    peak_freq = {"x": 412.3, "y": 487.6, "z": 521.0}[d]
    peak_disp = {"x": 0.142, "y": 0.118, "z": 0.094}[d]
    peak_stress = {"x": 312.4, "y": 278.1, "z": 241.7}[d]
    pd.DataFrame([
        {"component": "Valve body",      "peak_freq_Hz": peak_freq, "max_disp_mm": peak_disp,
         "max_stress_MPa": peak_stress, "allowable_MPa": 376, "util_pct": round(peak_stress / 376 * 100, 1), "pass": "Yes"},
        {"component": "Stem",            "peak_freq_Hz": peak_freq, "max_disp_mm": round(peak_disp * 0.4, 3),
         "max_stress_MPa": round(peak_stress * 0.6, 1), "allowable_MPa": 376, "util_pct": round(peak_stress * 0.6 / 376 * 100, 1), "pass": "Yes"},
        {"component": "Spring retainer", "peak_freq_Hz": peak_freq, "max_disp_mm": round(peak_disp * 0.2, 3),
         "max_stress_MPa": round(peak_stress * 0.3, 1), "allowable_MPa": 828, "util_pct": round(peak_stress * 0.3 / 828 * 100, 1), "pass": "Yes"},
    ]).to_csv(path, index=False)


def _csv_stress_details(path: Path, d: str) -> None:
    peak_stress = {"x": 312.4, "y": 278.1, "z": 241.7}[d]
    pd.DataFrame([
        {"location": "Bore–body fillet",    "vonMises_MPa": round(peak_stress, 1),        "principal_1_MPa": round(peak_stress * 1.1, 1),  "shear_MPa": round(peak_stress * 0.55, 1)},
        {"location": "Stem thread root",    "vonMises_MPa": round(peak_stress * 0.6, 1),  "principal_1_MPa": round(peak_stress * 0.66, 1), "shear_MPa": round(peak_stress * 0.33, 1)},
        {"location": "Body–bonnet face",    "vonMises_MPa": round(peak_stress * 0.45, 1), "principal_1_MPa": round(peak_stress * 0.50, 1), "shear_MPa": round(peak_stress * 0.25, 1)},
        {"location": "Locking groove",      "vonMises_MPa": round(peak_stress * 0.3, 1),  "principal_1_MPa": round(peak_stress * 0.33, 1), "shear_MPa": round(peak_stress * 0.17, 1)},
    ]).to_csv(path, index=False)


def _csv_disp_details(path: Path, d: str) -> None:
    peak_disp = {"x": 0.142, "y": 0.118, "z": 0.094}[d]
    pd.DataFrame([
        {"component": "Valve body",      "UX_mm": round(peak_disp if d=="x" else peak_disp*0.1, 4), "UY_mm": round(peak_disp if d=="y" else peak_disp*0.1, 4), "UZ_mm": round(peak_disp if d=="z" else peak_disp*0.1, 4), "total_mm": round(peak_disp, 4)},
        {"component": "Stem",            "UX_mm": round(peak_disp*0.4 if d=="x" else 0.01, 4),      "UY_mm": round(peak_disp*0.4 if d=="y" else 0.01, 4),      "UZ_mm": round(peak_disp*0.4 if d=="z" else 0.01, 4),      "total_mm": round(peak_disp*0.4, 4)},
        {"component": "Spring retainer", "UX_mm": round(peak_disp*0.2 if d=="x" else 0.005, 4),     "UY_mm": round(peak_disp*0.2 if d=="y" else 0.005, 4),     "UZ_mm": round(peak_disp*0.2 if d=="z" else 0.005, 4),     "total_mm": round(peak_disp*0.2, 4)},
    ]).to_csv(path, index=False)


def _csv_freq_details(path: Path, d: str) -> None:
    peak_freq = {"x": 412.3, "y": 487.6, "z": 521.0}[d]
    excitation = 50.0
    margin = round((peak_freq - excitation) / excitation * 100, 1)
    pd.DataFrame([
        {"parameter": "1st natural frequency (Hz)",    "value": peak_freq},
        {"parameter": "Excitation frequency (Hz)",     "value": excitation},
        {"parameter": "Frequency margin (%)",          "value": margin},
        {"parameter": "Peak response frequency (Hz)",  "value": round(peak_freq * 0.98, 1)},
        {"parameter": "Amplification factor (Q)",      "value": round(1 / (2 * 0.02), 1)},
        {"parameter": "Pass / Fail",                   "value": "Pass" if margin > 20 else "Review"},
    ]).to_csv(path, index=False)


# ─────────────────────────────────────────────────────────────────────────────
# bundle.json
# ─────────────────────────────────────────────────────────────────────────────

def _build_json() -> dict:
    data: dict = {
        "intro": {
            "domain": "Structures",
            "assembly": "Valve Rev B",
            "analysis_type": "Harmonic Response",
            "tool": "Ansys 2022R1",
            "total_elements": 1112425,
            "total_nodes": 1760037,
            "frequency_range_Hz": "0–500",
            "directions": ["X", "Y", "Z"],
        },
        "fem_model": {
            "domain": "Structures",
            "total_elements": 1112425,
            "total_nodes": 1760037,
            "element_types": ["Hex20 (SOLID186)", "Tet10 (SOLID187)", "kHex8"],
            "mesh_quality_verdict": "Acceptable — all metrics within Ansys defaults",
        },
        "harmonic_overview": {
            "domain": "Structures",
            "analysis_type": "Harmonic Response (Mode Superposition)",
            "directions": ["X", "Y", "Z"],
            "frequency_range_Hz": "0–500",
            "frequency_step_Hz": 1.0,
            "modes_used": 10,
            "damping_ratio": 0.02,
        },
        "modal_extraction": {
            "domain": "Structures",
            "solver": "Block Lanczos",
            "modes_extracted": 10,
            "first_mode_Hz": 412.3,
            "first_mode_desc": "1st bending X",
            "cumulative_mass_pct": 97.5,
        },
        "damping_settings": {
            "domain": "Structures",
            "global_damping_ratio": 0.02,
            "seat_ring_damping_ratio": 0.05,
            "model": "Constant + Rayleigh for seat ring",
        },
        "freq_sweep": {
            "domain": "Structures",
            "range_Hz": "0–500",
            "total_substeps": 350,
            "solver": "Mode Superposition",
            "output_quantities": ["Displacement", "Stress", "Reaction Forces"],
        },
        "prestress": {
            "domain": "Structures",
            "pre_stress_load_case": "Static: Design Pressure 250 bar",
            "included_in_harmonic": True,
            "note": "Linear perturbation method used",
        },
        "mode_superposition": {
            "domain": "Structures",
            "method": "Mode Superposition",
            "modes_included": 10,
            "residual_vector": True,
            "cluster_option": "Distributed",
        },
        "conclusion": {
            "domain": "Structures",
            "overall_verdict": "Pass",
            "x_direction_status": "Pass — 1st mode 412.3 Hz, margin 724.6% over 50 Hz excitation",
            "y_direction_status": "Pass — 1st mode 487.6 Hz",
            "z_direction_status": "Pass — 1st mode 521.0 Hz",
            "max_stress_MPa": 312.4,
            "allowable_MPa": 376,
            "max_utilisation_pct": 83.1,
            "recommendation": "Assembly safe under harmonic loading in all three directions",
        },
    }

    # Per-direction dicts
    for d in DIRECTIONS:
        D = d.upper()
        peak_freq  = {"x": 412.3, "y": 487.6, "z": 521.0}[d]
        peak_disp  = {"x": 0.142, "y": 0.118, "z": 0.094}[d]
        peak_stress= {"x": 312.4, "y": 278.1, "z": 241.7}[d]
        amp_g      = {"x": 1.0,   "y": 0.8,   "z": 0.5  }[d]

        data[f"harmonic_loads_{d}"] = {
            "domain": "Structures",
            "direction": D,
            "base_excitation_amplitude_g": amp_g,
            "frequency_range_Hz": "0–500",
            "phase_deg": 0.0,
            "load_application": "Flange base — displacement-controlled",
        }
        data[f"harmonic_bc_{d}"] = {
            "domain": "Structures",
            "direction": D,
            "fixed_support": "Flange bolt holes (UX=UY=UZ=0)",
            "excitation_dof": f"U{D} ≠ 0 at flange base",
        }
        data[f"harmonic_results_{d}"] = {
            "domain": "Structures",
            "direction": D,
            "peak_response_freq_Hz": peak_freq,
            "max_displacement_mm": peak_disp,
            "max_vonMises_MPa": peak_stress,
            "allowable_MPa": 376,
            "utilisation_pct": round(peak_stress / 376 * 100, 1),
            "verdict": "Pass",
            "figure": f"images/results_{d}.png",
            "table": f"tables/results_{d}.csv",
        }
        data[f"harmonic_details_{d}"] = {
            "domain": "Structures",
            "direction": D,
            "peak_freq_Hz": peak_freq,
            "excitation_freq_Hz": 50.0,
            "freq_margin_pct": round((peak_freq - 50.0) / 50.0 * 100, 1),
            "amplification_Q": 25.0,
            "max_stress_location": "Bore–body fillet",
            "max_disp_component": "Valve body",
        }

    # ── Repeat instances (drives instances_from_json in YAML) ──────────────────
    # Add as many directions as the analysis covers — docgen reads this list
    # at runtime so the YAML never needs to be changed when directions vary.
    data["harmonic_repeat_instances"] = [
        {
            "name": "X Direction",
            "number": "6",
            "vars": {
                "json_key_suffix": "_x",
                "csv_suffix": "_x",
                "img_suffix": "_x",
                "dir_label": "X Direction",
            },
        },
        {
            "name": "Y Direction",
            "number": "7",
            "vars": {
                "json_key_suffix": "_y",
                "csv_suffix": "_y",
                "img_suffix": "_y",
                "dir_label": "Y Direction",
            },
        },
        {
            "name": "Z Direction",
            "number": "8",
            "vars": {
                "json_key_suffix": "_z",
                "csv_suffix": "_z",
                "img_suffix": "_z",
                "dir_label": "Z Direction",
            },
        },
    ]

    return data


# ─────────────────────────────────────────────────────────────────────────────
# YAML
# ─────────────────────────────────────────────────────────────────────────────

YAML_CONTENT = """\
title: "Harmonic Response Analysis Report — Valve Rev B"

sections:
  # ── 1. Introduction ──────────────────────────────────────────────────────
  - number: "1"
    Section_name: Introduction
    elements:
      - kind: paragraph
        mode: cot
        para_prompt: >-
          Write seven to ten sentences introducing this harmonic response analysis
          report. State the assembly name, analysis tool, frequency range, and the
          three excitation directions (X, Y, Z). Reference Table 1 (element quality)
          and Figure 1 (FE mesh). Use only JSON facts.
        para_input_from_json: intro
        cot_examples:
          - question: >-
              Write an introduction for a harmonic response analysis of a pump casing
              analysed in Abaqus over 0–800 Hz.
            thought: >-
              I need to state: assembly, tool, frequency range, directions, purpose.
              Open with purpose, describe the model, close with scope.
            answer: >-
              This report documents the harmonic response analysis of the pump casing
              assembly conducted in Abaqus 2021 over a frequency range of 0 to 800 Hz.
              The finite element model comprises 1,240,000 elements and 1,850,000 nodes.
              Base excitation was applied independently in the X, Y, and Z directions
              to evaluate the worst-case structural response. Results are assessed
              against allowable stress and displacement limits defined in the design code.

  # ── 2. FE Model Description ──────────────────────────────────────────────
  - number: "2"
    Section_name: FE Model Description
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write five to seven sentences describing the finite element model.
          Cover total elements, nodes, element types, and mesh quality verdict.
          Reference Table 1 and Figure 1. Use only JSON facts.
        para_input_from_json: fem_model
      - kind: image
        img_path: images/mesh.png
        img_name: FE Mesh Overview — Valve Rev B
      - kind: table
        csv_path: tables/element_quality.csv
        caption: Element Type and Mesh Quality Summary

  # ── 3. Harmonic Analysis ─────────────────────────────────────────────────
  - number: "3"
    Section_name: Harmonic Analysis
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write four to six sentences providing an overview of the harmonic analysis
          setup: method, directions, frequency range, step size, and modes used.
          Use only JSON facts.
        para_input_from_json: harmonic_overview

    sections:
      # ── 3.1 Modal Extraction ──
      - number: "3.1"
        Section_name: Modal Extraction
        elements:
          - kind: paragraph
            mode: finetuned
            para_prompt: >-
              Write four to six sentences on the modal extraction: solver, modes
              extracted, first natural frequency, first mode description, and
              cumulative effective mass percentage. Reference Table 2. Use only JSON facts.
            para_input_from_json: modal_extraction
          - kind: table
            csv_path: tables/modal_frequencies.csv
            caption: Extracted Natural Frequencies

      # ── 3.2 Damping ──
      - number: "3.2"
        Section_name: Damping
        elements:
          - kind: paragraph
            mode: finetuned
            para_prompt: >-
              Write three to five sentences describing the damping model used,
              global damping ratio, and any component-specific values.
              Reference Table 3. Use only JSON facts.
            para_input_from_json: damping_settings
          - kind: table
            csv_path: tables/damping.csv
            caption: Damping Assignments by Component

      # ── 3.3 Frequency Sweep ──
      - number: "3.3"
        Section_name: Frequency Sweep
        elements:
          - kind: paragraph
            mode: finetuned
            para_prompt: >-
              Write three to five sentences describing the frequency sweep setup:
              range, step size, total substeps, solver, and output quantities.
              Reference Table 4. Use only JSON facts.
            para_input_from_json: freq_sweep
          - kind: table
            csv_path: tables/freq_sweep.csv
            caption: Frequency Sweep Settings

      # ── 3.4 Static Pre-stress ──
      - number: "3.4"
        Section_name: Static Pre-stress
        elements:
          - kind: paragraph
            mode: finetuned
            para_prompt: >-
              Write three to four sentences explaining the static pre-stress load case
              used as the base state for harmonic perturbation. Use only JSON facts.
            para_input_from_json: prestress

      # ── 3.5 Mode Superposition Settings ──
      - number: "3.5"
        Section_name: Mode Superposition Settings
        elements:
          - kind: paragraph
            mode: finetuned
            para_prompt: >-
              Write three to four sentences describing the mode superposition method
              settings including residual vectors and cluster options. Use only JSON facts.
            para_input_from_json: mode_superposition

      # ── 3.6 / 3.7 / 3.8  X / Y / Z Direction — REPEAT BLOCK ─────────────
      # instances_from_json: reads the instance list from bundle.json at runtime.
      # To add or remove directions, edit bundle.json["harmonic_repeat_instances"]
      # — no YAML change needed.
      - kind: repeat
        instances_from_json: harmonic_repeat_instances

        template:
          Section_name: "{name} Harmonic Excitation"

          sections:
            # 3.x.1 Loads
            - number: "1"
              Section_name: Loads
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write four to six sentences describing the harmonic loads applied
                    for the {dir_label} excitation case. State amplitude, direction,
                    phase, and application surface. Reference Table below. Use only JSON facts.
                  para_input_from_json: "harmonic_loads{json_key_suffix}"
                - kind: multi_table
                  tables:
                    - csv_path: "tables/loads{csv_suffix}.csv"
                      caption: "Applied Loads — {name}"
                    - csv_path: "tables/bc{csv_suffix}.csv"
                      caption: "Boundary Conditions — {name}"

            # 3.x.2 Boundary Conditions
            - number: "2"
              Section_name: Boundary Conditions
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write three to five sentences describing the boundary conditions
                    for the {dir_label} harmonic case. State fixed supports and the
                    excited DOF. Use only JSON facts.
                  para_input_from_json: "harmonic_bc{json_key_suffix}"

            # 3.x.3 Analysis Results
            - number: "3"
              Section_name: Analysis Results
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write five to eight sentences summarising the harmonic analysis
                    results for {dir_label}. State peak response frequency, maximum
                    displacement, maximum von Mises stress, allowable stress, and
                    utilisation percentage. State pass/fail. Reference Figure and Table.
                    Use only JSON facts.
                  para_input_from_json: "harmonic_results{json_key_suffix}"
                - kind: image
                  img_path: "images/results{img_suffix}.png"
                  img_name: "Harmonic Frequency Response — {name}"
                - kind: table
                  csv_path: "tables/results{csv_suffix}.csv"
                  caption: "Results Summary — {name}"

            # 3.x.4 Analysis Results Details
            - number: "4"
              Section_name: Analysis Results Details
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write five to seven sentences providing detailed commentary on the
                    {dir_label} results. Cover frequency margin over excitation,
                    amplification factor, stress hotspot location, and displacement
                    component. Reference Tables below. Use only JSON facts.
                  para_input_from_json: "harmonic_details{json_key_suffix}"
                - kind: multi_table
                  tables:
                    - csv_path: "tables/stress{csv_suffix}.csv"
                      caption: "Stress Details — {name}"
                    - csv_path: "tables/disp{csv_suffix}.csv"
                      caption: "Displacement Details — {name}"
                    - csv_path: "tables/freq_details{csv_suffix}.csv"
                      caption: "Frequency Margin — {name}"

  # ── 4. Conclusion ─────────────────────────────────────────────────────────
  - number: "4"
    Section_name: Conclusion
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write six to nine sentences summarising the harmonic analysis conclusions
          for all three directions (X, Y, Z). Confirm pass/fail for each direction,
          state maximum stress utilisation, and give the recommendation.
          Use only JSON facts.
        para_input_from_json: conclusion
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    print("Building Harmonic Analysis sample assets …")

    tables   = BUNDLE_DIR / "tables"
    images   = BUNDLE_DIR / "images"
    for d in (tables, images):
        d.mkdir(parents=True, exist_ok=True)

    # Template
    _build_template(BUNDLE_DIR / "template.docx")

    # Mesh figure
    _make_mesh_fig(images / "mesh.png")
    print("  mesh.png → done")

    # Shared tables
    _csv_element_quality(tables / "element_quality.csv")
    _csv_modal(tables / "modal_frequencies.csv")
    _csv_damping(tables / "damping.csv")
    _csv_freq_sweep(tables / "freq_sweep.csv")
    print("  Shared CSVs → done")

    # Per-direction assets
    for d in DIRECTIONS:
        label = DIR_LABELS[d]
        peak_hz = {"x": 412.3, "y": 487.6, "z": 521.0}[d]
        _make_fig(images / f"results_{d}.png", f"Harmonic Response — {label}", f"Peak at {peak_hz} Hz", d)
        _csv_loads(tables / f"loads_{d}.csv", d)
        _csv_bc(tables / f"bc_{d}.csv", d)
        _csv_results(tables / f"results_{d}.csv", d)
        _csv_stress_details(tables / f"stress_{d}.csv", d)
        _csv_disp_details(tables / f"disp_{d}.csv", d)
        _csv_freq_details(tables / f"freq_details_{d}.csv", d)
        print(f"  {label} assets → done")

    # bundle.json
    (BUNDLE_DIR / "bundle.json").write_text(
        json.dumps(_build_json(), indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print("  bundle.json → done")

    # ZIP
    ZIP_PATH.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in BUNDLE_DIR.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(BUNDLE_DIR).as_posix())
    print(f"  harmonic_report.zip → {ZIP_PATH}")

    # YAML
    YAML_PATH.write_text(YAML_CONTENT, encoding="utf-8")
    print(f"  harmonic_report.yaml → {YAML_PATH}")

    print("\nDone. Run:")
    print(f"  python -m docgen --zip {ZIP_PATH} --yaml {YAML_PATH} --out example/harmonic_report.docx --no-llm")


if __name__ == "__main__":
    main()

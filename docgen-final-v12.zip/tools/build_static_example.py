"""
Build Static Structural Analysis sample matching the real bundle.json structure
seen in the screenshots.

JSON shape produced:
    {
      "Static": {
        "Static_loads": {
          "Static Structural":   { ... },
          "Static Structural 2": { ... },
          "Static Structural 3": { ... }
        },
        "Static_boundary_condition": { ... same keys ... },
        "Static_result_summary":     { ... same keys ... },
        "Static_result_details":     {
          "Static Structural":   [ {result_item}, {result_item}, ... ],
          "Static Structural 2": [ ... ],
          "Static Structural 3": [ ... ]
        }
      }
    }

YAML uses:
  - Outer repeat  → instances_keys_from_json: "Static.Static_loads"
                    (auto-expands to 3 sections — or N if you add more)
  - Inner repeat  → instances_list_from_json: "Static.Static_result_details.{instance_name}"
                    (auto-expands to M result items per load case)

Usage:
  python tools/build_static_example.py
  python -m docgen --zip example/static_report.zip \\
                   --yaml example/static_report.yaml \\
                   --out  example/static_report.docx \\
                   --no-llm
"""
from __future__ import annotations

import json
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw

ROOT       = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "example" / "static_bundle"
ZIP_PATH   = ROOT / "example" / "static_report.zip"
YAML_PATH  = ROOT / "example" / "static_report.yaml"

# Load cases — mirroring real data
LOAD_CASES = ["Static Structural", "Static Structural 2", "Static Structural 3"]

PALETTE = [
    ((26, 58, 108),  (200, 220, 245)),
    ((100, 40, 120), (230, 210, 245)),
    ((20, 100, 60),  (200, 240, 215)),
]


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _font(size: int = 18):
    from PIL import ImageFont
    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _add_page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    run = p.add_run()
    br = OxmlElement("w:br")
    br.set(qn("w:type"), "page")
    run._r.append(br)


def _add_field(para, field_code: str) -> None:
    run = para.add_run()
    fb = OxmlElement("w:fldChar"); fb.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve"); instr.text = f" {field_code} "
    fe = OxmlElement("w:fldChar"); fe.set(qn("w:fldCharType"), "end")
    run._r.extend([fb, instr, fe])


def _safe_id(s: str) -> str:
    import re
    return re.sub(r"[^A-Za-z0-9_]", "_", s).strip("_")


# ─────────────────────────────────────────────────────────────────────────────
# Template .docx
# ─────────────────────────────────────────────────────────────────────────────

def _build_template(path: Path) -> None:
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)

    sec = doc.sections[0]
    sec.top_margin = sec.bottom_margin = Inches(1.0)
    sec.left_margin = sec.right_margin = Inches(1.25)

    hdr_p = sec.header.paragraphs[0]
    hdr_p.clear(); hdr_p.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
    r = hdr_p.add_run("ACME Aerospace  |  Static Structural Analysis Report")
    r.font.name = "Calibri"; r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    ftr_p = sec.footer.paragraphs[0]
    ftr_p.clear(); ftr_p.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    ftr_p.add_run("Page ").font.size = Pt(9)
    _add_field(ftr_p, "PAGE")
    ftr_p.add_run(" of ").font.size = Pt(9)
    _add_field(ftr_p, "NUMPAGES")

    # Title page
    for _ in range(5): doc.add_paragraph()
    tp = doc.add_paragraph(); tp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    r = tp.add_run("Static Structural Analysis Report")
    r.bold = True; r.font.size = Pt(26); r.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6C)
    sp = doc.add_paragraph(); sp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    sp.add_run("Valve Assembly Rev B — 3 Load Cases").font.size = Pt(13)
    doc.add_paragraph()

    meta = [
        ("Assembly", "Valve Rev B"), ("Analysis Type", "Static Structural"),
        ("Load Cases", "Static Structural 1, 2, 3"), ("Tool", "Ansys 2022R1"),
        ("Document No.", "STA-2026-0012"), ("Revision", "A"),
        ("Date", "20 May 2026"), ("Prepared by", "Srujan K S"),
    ]
    tbl = doc.add_table(rows=len(meta), cols=2); tbl.style = "Table Grid"
    for i, (k, v) in enumerate(meta):
        c = tbl.rows[i].cells
        c[0].text = k; c[0].paragraphs[0].runs[0].bold = True; c[1].text = v

    _add_page_break(doc)

    # TOC page
    doc.add_heading("Table of Contents", level=1)
    toc = [
        ("1", "Introduction"), ("2", "FE Model Description"),
        ("3", "Static Analysis"),
        ("3.1", "Static Structural — Loads"), ("3.1.2", "Boundary Conditions"),
        ("3.1.3", "Results Summary"),  ("3.1.4", "Results Details"),
        ("3.2", "Static Structural 2 — Loads"), ("...", "..."),
        ("3.3", "Static Structural 3 — Loads"), ("...", "..."),
        ("4", "Conclusion"),
    ]
    for num, name in toc:
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(5.5), WD_PARAGRAPH_ALIGNMENT.RIGHT)  # type: ignore
        p.add_run(f"{num}  {name}".strip() if num != "..." else name).font.size = Pt(11)
        p.add_run("\t"); _add_field(p, "PAGE")

    doc.save(str(path))
    print(f"  template.docx → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# Figures
# ─────────────────────────────────────────────────────────────────────────────

def _fig(path: Path, title: str, subtitle: str, idx: int) -> None:
    fg, bg = PALETTE[idx % len(PALETTE)]
    im = Image.new("RGB", (1024, 560), (248, 250, 252))
    dr = ImageDraw.Draw(im)
    dr.rectangle((0, 0, 1024, 70), fill=fg)
    dr.text((16, 18), title, fill=(255, 255, 255), font=_font(21))
    dr.rectangle((16, 88, 1008, 535), fill=bg, outline=fg, width=3)
    dr.text((32, 108), subtitle, fill=fg, font=_font(16))
    for x in range(40, 1005, 80): dr.line([(x, 150), (x, 525)], fill=(*fg, 50), width=1)
    for y in range(170, 530, 60): dr.line([(30, y), (1000, y)], fill=(*fg, 50), width=1)
    dr.text((32, 538), f"docgen static sample — {path.stem}", fill=(130, 130, 130), font=_font(12))
    im.save(path)


# ─────────────────────────────────────────────────────────────────────────────
# bundle.json
# ─────────────────────────────────────────────────────────────────────────────

def _build_json() -> dict:
    pressures    = [250, 180, 320]       # bar per load case
    temps        = [None, 180, None]     # °C (None = ambient)
    peak_stress  = [312.4, 274.1, 358.2] # MPa
    peak_disp    = [0.142, 0.318, 0.091] # mm
    # Number of result items (stress locations) per load case
    n_details    = [3, 3, 3]

    data: dict = {
        "intro": {
            "domain": "Structures",
            "assembly": "Valve Rev B",
            "tool": "Ansys 2022R1",
            "load_cases": LOAD_CASES,
            "n_elements": 1112425,
            "n_nodes": 1760037,
        },
        "fem_model": {
            "domain": "Structures",
            "total_elements": 1112425,
            "total_nodes": 1760037,
            "element_types": ["Hex20", "Tet10", "kHex8"],
            "mesh_quality": "Acceptable",
        },
        "conclusion": {
            "domain": "Structures",
            "overall_verdict": "Pass",
            "max_stress_MPa": max(peak_stress),
            "allowable_MPa": 376,
            "max_util_pct": round(max(peak_stress) / 376 * 100, 1),
            "recommendation": "Assembly safe under all three static load cases.",
        },
        # ── Nested structure matching your real JSON ──────────────────────────
        "Static": {
            "Static_loads": {},
            "Static_boundary_condition": {},
            "Static_result_summary": {},
            "Static_result_details": {},
        },
    }

    for i, lc in enumerate(LOAD_CASES):
        safe = _safe_id(lc)
        ps = peak_stress[i]
        pd_ = peak_disp[i]
        pr = pressures[i]
        tmp = temps[i]

        # Loads
        loads_block: dict = {
            "domain": "Structures",
            "load_case": lc,
            "pressure_bar": pr,
            "pressure_surface": "Inlet bore and bonnet face",
        }
        if tmp:
            loads_block["temperature_C"] = tmp
            loads_block["thermal_surface"] = "All bodies"
        data["Static"]["Static_loads"][lc] = loads_block

        # Boundary conditions
        data["Static"]["Static_boundary_condition"][lc] = {
            "domain": "Structures",
            "load_case": lc,
            "fixed_support": "Flange bolt holes — UX=UY=UZ=0",
            "contact_type": "Bonded (all interfaces)",
        }

        # Result summary
        data["Static"]["Static_result_summary"][lc] = {
            "domain": "Structures",
            "load_case": lc,
            "max_vonMises_MPa": ps,
            "max_vonMises_component": "Valve body — bore fillet",
            "allowable_MPa": 376,
            "utilisation_pct": round(ps / 376 * 100, 1),
            "max_displacement_mm": pd_,
            "displacement_limit_mm": 0.5,
            "verdict": "Pass",
        }

        # Result details — list of stress locations (inner repeat drives this)
        locations = [
            ("Bore–body fillet",   1.00),
            ("Stem thread root",   0.60),
            ("Body–bonnet face",   0.45),
        ]
        details_list = []
        for j, (loc, factor) in enumerate(locations[: n_details[i]]):
            details_list.append({
                "domain": "Structures",
                "load_case": lc,
                "location": loc,
                "vonMises_MPa": round(ps * factor, 1),
                "allowable_MPa": 376,
                "utilisation_pct": round(ps * factor / 376 * 100, 1),
                "principal_1_MPa": round(ps * factor * 1.1, 1),
                "shear_MPa": round(ps * factor * 0.55, 1),
                "verdict": "Pass",
                "image_path": f"images/detail_{safe}_{j+1}.png",
            })
        data["Static"]["Static_result_details"][lc] = details_list

    return data


# ─────────────────────────────────────────────────────────────────────────────
# CSVs
# ─────────────────────────────────────────────────────────────────────────────

def _csv_element_quality(path: Path) -> None:
    pd.DataFrame([
        {"type": "Hex20", "count": 980000, "avg_AR": 1.8, "min_Jac": 0.72, "pass": "Yes"},
        {"type": "Tet10", "count": 112000, "avg_AR": 2.2, "min_Jac": 0.68, "pass": "Yes"},
        {"type": "kHex8", "count":  20425, "avg_AR": 2.6, "min_Jac": 0.61, "pass": "Review"},
    ]).to_csv(path, index=False)


def _csv_loads(path: Path, i: int) -> None:
    pressures = [250, 180, 320]
    temps     = [None, 180, None]
    rows = [{"load_id": f"LD-{i+1:02d}-01", "type": "Pressure",
             "value": f"{pressures[i]} bar", "surface": "Inlet bore"},
            {"load_id": f"LD-{i+1:02d}-02", "type": "Pressure",
             "value": f"{pressures[i]} bar", "surface": "Bonnet face"}]
    if temps[i]:
        rows.append({"load_id": f"LD-{i+1:02d}-03", "type": "Temperature",
                     "value": f"{temps[i]} °C", "surface": "All bodies"})
    pd.DataFrame(rows).to_csv(path, index=False)


def _csv_bc(path: Path, i: int) -> None:
    pd.DataFrame([
        {"bc_id": f"BC-{i+1:02d}-01", "type": "Fixed Support",
         "dof": "UX=UY=UZ=0", "surface": "Flange bolt holes"},
        {"bc_id": f"BC-{i+1:02d}-02", "type": "Bonded Contact",
         "dof": "All DOF coupled", "surface": "All interfaces"},
    ]).to_csv(path, index=False)


def _csv_summary(path: Path, i: int) -> None:
    ps = [312.4, 274.1, 358.2][i]
    pd_ = [0.142, 0.318, 0.091][i]
    pd.DataFrame([
        {"component": "Valve body",      "max_stress_MPa": round(ps, 1),       "allowable": 376, "util_pct": round(ps/376*100,1),       "max_disp_mm": pd_,              "pass": "Yes"},
        {"component": "Stem",            "max_stress_MPa": round(ps*0.6, 1),   "allowable": 376, "util_pct": round(ps*0.6/376*100,1),   "max_disp_mm": round(pd_*0.4,3), "pass": "Yes"},
        {"component": "Spring retainer", "max_stress_MPa": round(ps*0.3, 1),   "allowable": 828, "util_pct": round(ps*0.3/828*100,1),   "max_disp_mm": round(pd_*0.2,3), "pass": "Yes"},
        {"component": "Seat ring",       "max_stress_MPa": round(ps*0.1, 1),   "allowable":  11, "util_pct": round(ps*0.1/11*100, 1),   "max_disp_mm": round(pd_*0.6,3), "pass": "Yes"},
    ]).to_csv(path, index=False)


def _csv_detail(path: Path, lc_idx: int, det_idx: int) -> None:
    """CSV for one result-detail item (one stress location)."""
    locs = ["Bore–body fillet", "Stem thread root", "Body–bonnet face"]
    factors = [1.0, 0.60, 0.45]
    ps = [312.4, 274.1, 358.2][lc_idx]
    f = factors[det_idx]
    pd.DataFrame([
        {"metric": "Location",          "value": locs[det_idx]},
        {"metric": "Von Mises (MPa)",   "value": round(ps * f, 1)},
        {"metric": "Principal 1 (MPa)", "value": round(ps * f * 1.1, 1)},
        {"metric": "Shear (MPa)",       "value": round(ps * f * 0.55, 1)},
        {"metric": "Allowable (MPa)",   "value": 376},
        {"metric": "Utilisation (%)",   "value": round(ps * f / 376 * 100, 1)},
        {"metric": "Pass / Fail",       "value": "Pass"},
    ]).to_csv(path, index=False)


# ─────────────────────────────────────────────────────────────────────────────
# YAML
# ─────────────────────────────────────────────────────────────────────────────

YAML_CONTENT = """\
title: "Static Structural Analysis Report — Valve Rev B"

sections:
  # ─────────────────────────────────────────────────────────────────
  # 1. Introduction
  # ─────────────────────────────────────────────────────────────────
  - number: "1"
    Section_name: Introduction
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write six to eight sentences introducing this static structural
          analysis report. State the assembly, tool, number of load cases,
          element count and node count. Use only JSON facts.
        para_input_from_json: intro

  # ─────────────────────────────────────────────────────────────────
  # 2. FE Model Description
  # ─────────────────────────────────────────────────────────────────
  - number: "2"
    Section_name: FE Model Description
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write five to seven sentences describing the FE model: elements,
          nodes, types, and mesh quality. Reference Table 1 and Figure 1.
          Use only JSON facts.
        para_input_from_json: fem_model
      - kind: image
        img_path: images/mesh.png
        img_name: FE Mesh Overview
      - kind: table
        csv_path: tables/element_quality.csv
        caption: Element Quality Summary

  # ─────────────────────────────────────────────────────────────────
  # 3. Static Analysis
  #    Outer repeat → one child section per load case.
  #    Driven by the KEYS of bundle.json["Static"]["Static_loads"].
  #    Add a "Static Structural 4" key there → section 3.4 appears
  #    with no YAML change needed.
  # ─────────────────────────────────────────────────────────────────
  - number: "3"
    Section_name: Static Analysis
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write three to five sentences providing an overview of the static
          analysis approach across all load cases. Use only JSON facts.
        para_input_from_json: intro

    sections:
      - kind: repeat
        instances_keys_from_json: "Static.Static_loads"
        number_start: 1
        template:
          Section_name: "{name}"

          sections:
            # ── 3.N.1  Loads ────────────────────────────────────────
            - number: "1"
              Section_name: Loads
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write four to six sentences describing the loads applied
                    in the {name} load case. State pressure values, surfaces,
                    and any thermal loads. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_loads.{name}"
                - kind: table
                  csv_path: "tables/loads_{instance_name}.csv"
                  caption: "Applied Loads — {name}"

            # ── 3.N.2  Boundary Conditions ──────────────────────────
            - number: "2"
              Section_name: Boundary Conditions
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write three to five sentences describing the boundary
                    conditions for the {name} load case. State fixed supports
                    and contact definitions. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_boundary_condition.{name}"
                - kind: table
                  csv_path: "tables/bc_{instance_name}.csv"
                  caption: "Boundary Conditions — {name}"

            # ── 3.N.3  Results Summary ───────────────────────────────
            - number: "3"
              Section_name: Results Summary
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write five to eight sentences summarising results for
                    the {name} load case. State maximum von Mises stress,
                    location, allowable, utilisation, max displacement, and
                    pass/fail verdict. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_result_summary.{name}"
                - kind: table
                  csv_path: "tables/summary_{instance_name}.csv"
                  caption: "Results Summary — {name}"

            # ── 3.N.4  Results Details ───────────────────────────────
            #    Inner repeat → one sub-section per stress location.
            #    Driven by the LIST at
            #    bundle.json["Static"]["Static_result_details"]["{name}"].
            #    {instance_name} is the safe-id of the outer {name}.
            - number: "4"
              Section_name: Results Details
              sections:
                - kind: repeat
                  instances_list_from_json: "Static.Static_result_details.{name}"
                  template:
                    Section_name: "Detail {index_1} — {location}"
                    elements:
                      - kind: paragraph
                        mode: finetuned
                        para_prompt: >-
                          Write three to five sentences describing the stress
                          result at the {location} location for {name}.
                          State von Mises stress, principal stress, shear,
                          utilisation, and pass/fail. Use only JSON facts.
                        para_input_from_json_path: "Static.Static_result_details.{name}.{index}"
                      - kind: image
                        img_path: "images/detail_{instance_name}_{index_1}.png"
                        img_name: "Stress Detail — {name} — {location}"
                      - kind: table
                        csv_path: "tables/detail_{instance_name}_{index_1}.csv"
                        caption: "Stress Detail — {name} — {location}"

  # ─────────────────────────────────────────────────────────────────
  # 4. Conclusion
  # ─────────────────────────────────────────────────────────────────
  - number: "4"
    Section_name: Conclusion
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write six to nine sentences summarising conclusions across all
          static load cases. State maximum stress utilisation, worst-case
          load case, and overall recommendation. Use only JSON facts.
        para_input_from_json: conclusion
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    print("Building Static Structural sample assets …")

    tables = BUNDLE_DIR / "tables"
    images = BUNDLE_DIR / "images"
    for d in (tables, images):
        d.mkdir(parents=True, exist_ok=True)

    _build_template(BUNDLE_DIR / "template.docx")

    # Mesh overview figure
    _fig(images / "mesh.png", "FE Mesh — Valve Rev B", "1,112,425 elements  |  1,760,037 nodes", 0)

    # Shared tables
    _csv_element_quality(tables / "element_quality.csv")

    # Per-load-case assets
    for i, lc in enumerate(LOAD_CASES):
        safe = _safe_id(lc)
        print(f"  {lc} …")

        _csv_loads(tables / f"loads_{safe}.csv", i)
        _csv_bc(tables / f"bc_{safe}.csv", i)
        _csv_summary(tables / f"summary_{safe}.csv", i)

        # Per-detail assets (3 stress locations each)
        for j in range(3):
            locs = ["Bore fillet", "Thread root", "Bonnet face"]
            _fig(
                images / f"detail_{safe}_{j+1}.png",
                f"Stress Detail — {lc}",
                f"Location {j+1}: {locs[j]}",
                i,
            )
            _csv_detail(tables / f"detail_{safe}_{j+1}.csv", i, j)

    # bundle.json
    data = _build_json()
    (BUNDLE_DIR / "bundle.json").write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print("  bundle.json → done")

    # ZIP
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in BUNDLE_DIR.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(BUNDLE_DIR).as_posix())
    print(f"  static_report.zip → {ZIP_PATH}")

    YAML_PATH.write_text(YAML_CONTENT, encoding="utf-8")
    print(f"  static_report.yaml → {YAML_PATH}")

    print("\nDone. Run:")
    print(f"  python -m docgen --zip {ZIP_PATH} --yaml {YAML_PATH} --out example/static_report.docx --no-llm")


if __name__ == "__main__":
    main()

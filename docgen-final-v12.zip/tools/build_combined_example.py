"""
Build combined Static + Harmonic analysis report.

Single bundle.json structure (matches real data from screenshots):
{
  "report_meta": { ... },
  "fem_model":   { ... },

  "Static": {
    "Static_loads":               { "Static Structural": {...}, "Static Structural 2": {...}, ... },
    "Static_boundary_condition":  { same keys },
    "Static_result_summary":      { same keys },
    "Static_result_details":      { "Static Structural": [{...},{...},...], ... }
  },

  "Harmonic": {
    "Harmonic_Loads":             { "X Direction Harmonic Excitation": {...}, "Y Direction...": {...}, ... },
    "Harmonic_Boundary_condition":{ same keys },
    "Harmonic_Result_Summary":    { same keys },
    "Harmonic_Result_Details":    { "X Direction Harmonic Excitation": [{...},...], ... }
  },

  "static_repeat_instances":   [ ... ]   ← driven by keys of Static.Static_loads
  "harmonic_repeat_instances": [ ... ]   ← driven by keys of Harmonic.Harmonic_Loads
  "conclusion": { ... }
}

YAML uses:
  Section 3 Static Analysis
    → outer repeat: instances_keys_from_json: "Static.Static_loads"
      3.N.1 Loads | 3.N.2 BC | 3.N.3 Results Summary
      3.N.4 Results Details
        → inner repeat: instances_list_from_json: "Static.Static_result_details.{name}"

  Section 4 Harmonic Analysis
    → outer repeat: instances_keys_from_json: "Harmonic.Harmonic_Loads"
      4.N.1 Loads | 4.N.2 BC | 4.N.3 Results Summary
      4.N.4 Results Details
        → inner repeat: instances_list_from_json: "Harmonic.Harmonic_Result_Details.{name}"

Usage:
  python tools/build_combined_example.py
  python -m docgen --zip example/combined_report.zip \\
                   --yaml example/combined_report.yaml \\
                   --out  example/combined_report.docx \\
                   --no-llm
"""
from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image, ImageDraw

ROOT       = Path(__file__).resolve().parents[1]
BUNDLE_DIR = ROOT / "example" / "combined_bundle"
ZIP_PATH   = ROOT / "example" / "combined_report.zip"
YAML_PATH  = ROOT / "example" / "combined_report.yaml"

# ── Data definitions ──────────────────────────────────────────────────────────
STATIC_LOAD_CASES = ["Static Structural", "Static Structural 2", "Static Structural 3"]
HARMONIC_DIRS     = ["X Direction Harmonic Excitation",
                     "Y Direction Harmonic Excitation",
                     "Z Direction Harmonic Excitation"]

STATIC_PRESSURES  = [250, 180, 320]
STATIC_TEMPS      = [None, 180, None]
STATIC_PEAK_S     = [312.4, 274.1, 358.2]
STATIC_PEAK_D     = [0.142, 0.318, 0.091]

HARM_AMPLITUDES   = [1.0, 0.8, 0.5]
HARM_PEAK_FREQ    = [412.3, 487.6, 521.0]
HARM_PEAK_STRESS  = [312.4, 278.1, 241.7]
HARM_PEAK_DISP    = [0.142, 0.118, 0.094]

RESULT_LOCATIONS  = ["Bore–body fillet", "Stem thread root", "Body–bonnet face"]
RESULT_FACTORS    = [1.00, 0.60, 0.45]

STATIC_PALETTE  = [(26, 58, 108),  (100, 40, 120), (20, 100, 60)]
HARMONIC_PALETTE= [(180, 60, 0),   (0, 100, 140),  (80, 130, 0)]


def _safe_id(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", s).strip("_")


# ─────────────────────────────────────────────────────────────────────────────
# PIL helpers
# ─────────────────────────────────────────────────────────────────────────────

def _font(size: int = 18):
    from PIL import ImageFont
    for name in ("arial.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _fig(path: Path, title: str, subtitle: str, fg: tuple) -> None:
    bg = tuple(min(255, c + 140) for c in fg)
    im = Image.new("RGB", (1024, 540), (248, 250, 252))
    dr = ImageDraw.Draw(im)
    dr.rectangle((0, 0, 1024, 68), fill=fg)
    dr.text((16, 16), title, fill=(255, 255, 255), font=_font(20))
    dr.rectangle((16, 84, 1008, 520), fill=bg, outline=fg, width=3)
    dr.text((30, 100), subtitle, fill=fg, font=_font(15))
    for x in range(40, 1005, 80):
        dr.line([(x, 140), (x, 510)], fill=(*fg, 40), width=1)
    for y in range(160, 515, 60):
        dr.line([(28, y), (1000, y)], fill=(*fg, 40), width=1)
    dr.text((28, 523), f"docgen combined sample — {path.stem}", fill=(130, 130, 130), font=_font(11))
    im.save(path)


# ─────────────────────────────────────────────────────────────────────────────
# Template .docx
# ─────────────────────────────────────────────────────────────────────────────

def _add_field(para, code: str) -> None:
    run = para.add_run()
    fb = OxmlElement("w:fldChar"); fb.set(qn("w:fldCharType"), "begin")
    ins = OxmlElement("w:instrText"); ins.set(qn("xml:space"), "preserve"); ins.text = f" {code} "
    fe = OxmlElement("w:fldChar"); fe.set(qn("w:fldCharType"), "end")
    run._r.extend([fb, ins, fe])


def _page_break(doc: Document) -> None:
    p = doc.add_paragraph()
    r = p.add_run()
    br = OxmlElement("w:br"); br.set(qn("w:type"), "page")
    r._r.append(br)


def _build_template(path: Path) -> None:
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)

    sec = doc.sections[0]
    sec.top_margin = sec.bottom_margin = Inches(1.0)
    sec.left_margin = sec.right_margin = Inches(1.25)

    # Header
    hdr = sec.header.paragraphs[0]
    hdr.clear(); hdr.alignment = WD_PARAGRAPH_ALIGNMENT.RIGHT
    r = hdr.add_run("ACME Aerospace  |  Structural Analysis Report — Static & Harmonic")
    r.font.name = "Calibri"; r.font.size = Pt(9)
    r.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    # Footer
    ftr = sec.footer.paragraphs[0]
    ftr.clear(); ftr.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    ftr.add_run("Page ").font.size = Pt(9)
    _add_field(ftr, "PAGE")
    ftr.add_run(" of ").font.size = Pt(9)
    _add_field(ftr, "NUMPAGES")

    # ── Page 1: Title ──────────────────────────────────────────────────────
    for _ in range(5): doc.add_paragraph()

    tp = doc.add_paragraph(); tp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    r = tp.add_run("Structural Analysis Report")
    r.bold = True; r.font.size = Pt(28)
    r.font.color.rgb = RGBColor(0x1A, 0x3A, 0x6C)

    sp = doc.add_paragraph(); sp.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
    sp.add_run("Static Structural & Harmonic Response — Valve Assembly Rev B").font.size = Pt(14)
    doc.add_paragraph()

    meta = [
        ("Assembly",       "Valve Rev B"),
        ("Analysis Types", "Static Structural | Harmonic Response"),
        ("Static Cases",   "Static Structural 1, 2, 3"),
        ("Harmonic Cases", "X, Y, Z Direction Excitation (0–500 Hz)"),
        ("Tool",           "Ansys 2022R1"),
        ("Document No.",   "STR-2026-0042"),
        ("Revision",       "A"),
        ("Date",           "20 May 2026"),
        ("Prepared by",    "Srujan K S"),
        ("Classification", "CONFIDENTIAL"),
    ]
    tbl = doc.add_table(rows=len(meta), cols=2)
    tbl.style = "Table Grid"
    for i, (k, v) in enumerate(meta):
        c = tbl.rows[i].cells
        c[0].text = k; c[0].paragraphs[0].runs[0].bold = True
        c[1].text = v
        for cell in c:
            cell.paragraphs[0].runs[0].font.size = Pt(11)

    _page_break(doc)

    # ── Page 2: TOC placeholder ────────────────────────────────────────────
    doc.add_heading("Table of Contents", level=1)

    toc = [
        ("1",     "Introduction"),
        ("2",     "FE Model Description"),
        ("3",     "Static Analysis"),
        ("3.1",   "Static Structural"),
        ("3.1.1", "Loads"), ("3.1.2", "Boundary Conditions"),
        ("3.1.3", "Results Summary"), ("3.1.4", "Results Details"),
        ("3.2",   "Static Structural 2  …  (same structure)"),
        ("3.3",   "Static Structural 3  …  (same structure)"),
        ("4",     "Harmonic Analysis"),
        ("4.1",   "X Direction Harmonic Excitation"),
        ("4.1.1", "Loads"), ("4.1.2", "Boundary Conditions"),
        ("4.1.3", "Results Summary"), ("4.1.4", "Results Details"),
        ("4.2",   "Y Direction  …  (same structure)"),
        ("4.3",   "Z Direction  …  (same structure)"),
        ("5",     "Conclusion"),
        ("",      "List of Tables"),
        ("",      "List of Figures"),
    ]
    for num, name in toc:
        p = doc.add_paragraph()
        p.paragraph_format.tab_stops.add_tab_stop(
            Inches(5.5), WD_PARAGRAPH_ALIGNMENT.RIGHT)  # type: ignore
        label = f"{num}  {name}".strip() if num else name
        r = p.add_run(label); r.font.size = Pt(11)
        if not num: r.italic = True
        p.add_run("\t")
        _add_field(p, "PAGE")

    doc.save(str(path))
    print(f"  template.docx → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# bundle.json
# ─────────────────────────────────────────────────────────────────────────────

def _build_json() -> dict:
    data: dict = {
        "report_meta": {
            "domain": "Structures",
            "assembly": "Valve Rev B",
            "tool": "Ansys 2022R1",
            "static_load_cases": STATIC_LOAD_CASES,
            "harmonic_directions": HARMONIC_DIRS,
            "n_elements": 1112425,
            "n_nodes": 1760037,
        },
        "fem_model": {
            "domain": "Structures",
            "total_elements": 1112425,
            "total_nodes": 1760037,
            "element_types": ["Hex20 (SOLID186)", "Tet10 (SOLID187)", "kHex8"],
            "mesh_quality": "Acceptable — all metrics within Ansys defaults",
        },

        # ── Static ──────────────────────────────────────────────────────────
        "Static": {
            "Static_loads": {},
            "Static_boundary_condition": {},
            "Static_result_summary": {},
            "Static_result_details": {},
        },

        # ── Harmonic ────────────────────────────────────────────────────────
        "Harmonic": {
            "Harmonic_Loads": {},
            "Harmonic_Boundary_condition": {},
            "Harmonic_Result_Summary": {},
            "Harmonic_Result_Details": {},
        },

        "conclusion": {
            "domain": "Structures",
            "static_verdict": "Pass — max utilisation 95.3% (Static Structural 3)",
            "harmonic_verdict": "Pass — all directions clear of excitation frequency",
            "max_static_stress_MPa": 358.2,
            "max_harmonic_stress_MPa": 312.4,
            "allowable_MPa": 376,
            "recommendation": "Assembly safe under all static and harmonic load cases.",
        },
    }

    # ── Fill Static ──────────────────────────────────────────────────────────
    for i, lc in enumerate(STATIC_LOAD_CASES):
        ps = STATIC_PEAK_S[i]; pd_ = STATIC_PEAK_D[i]; pr = STATIC_PRESSURES[i]

        loads: dict = {
            "domain": "Structures", "load_case": lc,
            "pressure_bar": pr, "pressure_surface": "Inlet bore and bonnet face",
        }
        if STATIC_TEMPS[i]:
            loads["temperature_C"] = STATIC_TEMPS[i]
            loads["thermal_surface"] = "All bodies"
        data["Static"]["Static_loads"][lc] = loads

        data["Static"]["Static_boundary_condition"][lc] = {
            "domain": "Structures", "load_case": lc,
            "fixed_support": "Flange bolt holes — UX=UY=UZ=0",
            "contact_type": "Bonded (all interfaces)",
        }

        data["Static"]["Static_result_summary"][lc] = {
            "domain": "Structures", "load_case": lc,
            "max_vonMises_MPa": ps, "max_vonMises_component": "Valve body — bore fillet",
            "allowable_MPa": 376, "utilisation_pct": round(ps / 376 * 100, 1),
            "max_displacement_mm": pd_, "displacement_limit_mm": 0.5, "verdict": "Pass",
        }

        data["Static"]["Static_result_details"][lc] = [
            {
                "domain": "Structures", "load_case": lc,
                "location": loc,
                "vonMises_MPa": round(ps * f, 1),
                "allowable_MPa": 376,
                "utilisation_pct": round(ps * f / 376 * 100, 1),
                "principal_1_MPa": round(ps * f * 1.1, 1),
                "shear_MPa": round(ps * f * 0.55, 1),
                "verdict": "Pass",
                "image_path": f"images/s_detail_{_safe_id(lc)}_{j+1}.png",
            }
            for j, (loc, f) in enumerate(zip(RESULT_LOCATIONS, RESULT_FACTORS))
        ]

    # ── Fill Harmonic ────────────────────────────────────────────────────────
    for i, hd in enumerate(HARMONIC_DIRS):
        D   = ["X", "Y", "Z"][i]
        amp = HARM_AMPLITUDES[i]
        pf  = HARM_PEAK_FREQ[i]
        ps  = HARM_PEAK_STRESS[i]
        pd_ = HARM_PEAK_DISP[i]

        data["Harmonic"]["Harmonic_Loads"][hd] = {
            "domain": "Structures", "direction": D, "load_case": hd,
            "base_excitation_amplitude_g": amp, "frequency_range_Hz": "0–500",
            "phase_deg": 0.0, "load_application": "Flange base — displacement-controlled",
        }

        data["Harmonic"]["Harmonic_Boundary_condition"][hd] = {
            "domain": "Structures", "direction": D, "load_case": hd,
            "fixed_support": "Flange bolt holes (UX=UY=UZ=0)",
            "excitation_dof": f"U{D} ≠ 0 at flange base",
        }

        data["Harmonic"]["Harmonic_Result_Summary"][hd] = {
            "domain": "Structures", "direction": D, "load_case": hd,
            "peak_response_freq_Hz": pf,
            "max_displacement_mm": pd_, "max_vonMises_MPa": ps,
            "allowable_MPa": 376, "utilisation_pct": round(ps / 376 * 100, 1),
            "verdict": "Pass",
        }

        data["Harmonic"]["Harmonic_Result_Details"][hd] = [
            {
                "domain": "Structures", "direction": D, "load_case": hd,
                "location": loc,
                "peak_freq_Hz": pf, "excitation_freq_Hz": 50.0,
                "freq_margin_pct": round((pf - 50.0) / 50.0 * 100, 1),
                "vonMises_MPa": round(ps * f, 1),
                "utilisation_pct": round(ps * f / 376 * 100, 1),
                "amplification_Q": 25.0, "verdict": "Pass",
                "image_path": f"images/h_detail_{_safe_id(hd)}_{j+1}.png",
            }
            for j, (loc, f) in enumerate(zip(RESULT_LOCATIONS, RESULT_FACTORS))
        ]

    # ── Repeat instance lists (used by instances_keys_from_json indirectly) ──
    # These are derived at docgen runtime from the dict keys — no need to
    # store them explicitly. But we keep harmonic_repeat_instances for
    # backwards-compat with the harmonic-only YAML.
    data["harmonic_repeat_instances"] = [
        {"name": hd, "number": str(i + 1),
         "vars": {"json_key_suffix": f"_{['x','y','z'][i]}", "csv_suffix": f"_{['x','y','z'][i]}",
                  "img_suffix": f"_{['x','y','z'][i]}", "dir_label": hd}}
        for i, hd in enumerate(HARMONIC_DIRS)
    ]

    return data


# ─────────────────────────────────────────────────────────────────────────────
# CSVs
# ─────────────────────────────────────────────────────────────────────────────

def _csv_element_quality(path: Path) -> None:
    pd.DataFrame([
        {"type": "Hex20", "count": 980000, "avg_AR": 1.8, "min_Jac": 0.72, "pass": "Yes"},
        {"type": "Tet10", "count": 112000, "avg_AR": 2.2, "min_Jac": 0.68, "pass": "Yes"},
        {"type": "kHex8", "count":  20425, "avg_AR": 2.6, "min_Jac": 0.61, "pass": "Review"},
    ]).to_csv(path, index=False)


def _csv_modal(path: Path) -> None:
    freqs = [412.3, 487.6, 521.0, 689.4, 742.1, 818.5, 903.2, 961.7, 1024.8, 1187.3]
    modes = ["1st bending X", "1st bending Y", "Torsion Z", "2nd bending X",
             "2nd bending Y", "Axial", "3rd bending X", "3rd bending Y", "Combined", "4th bending X"]
    pd.DataFrame([
        {"mode": i+1, "freq_Hz": f, "description": m,
         "cumul_mass_pct": round(min(100, 40+(i+1)*6.5), 1)}
        for i, (f, m) in enumerate(zip(freqs, modes))
    ]).to_csv(path, index=False)


def _csv_static_loads(path: Path, i: int) -> None:
    rows = [
        {"load_id": f"LD-S{i+1:02d}-01", "type": "Pressure",
         "value": f"{STATIC_PRESSURES[i]} bar", "surface": "Inlet bore"},
        {"load_id": f"LD-S{i+1:02d}-02", "type": "Pressure",
         "value": f"{STATIC_PRESSURES[i]} bar", "surface": "Bonnet face"},
    ]
    if STATIC_TEMPS[i]:
        rows.append({"load_id": f"LD-S{i+1:02d}-03", "type": "Temperature",
                     "value": f"{STATIC_TEMPS[i]} °C", "surface": "All bodies"})
    pd.DataFrame(rows).to_csv(path, index=False)


def _csv_static_bc(path: Path, i: int) -> None:
    pd.DataFrame([
        {"bc_id": f"BC-S{i+1:02d}-01", "type": "Fixed Support",
         "dof": "UX=UY=UZ=0", "surface": "Flange bolt holes"},
        {"bc_id": f"BC-S{i+1:02d}-02", "type": "Bonded Contact",
         "dof": "All DOF", "surface": "All interfaces"},
    ]).to_csv(path, index=False)


def _csv_static_summary(path: Path, i: int) -> None:
    ps = STATIC_PEAK_S[i]; pd_ = STATIC_PEAK_D[i]
    pd.DataFrame([
        {"component": "Valve body",      "stress_MPa": ps,           "allow": 376, "util%": round(ps/376*100,1),           "disp_mm": pd_,            "pass": "Yes"},
        {"component": "Stem",            "stress_MPa": round(ps*.6,1),"allow": 376, "util%": round(ps*.6/376*100,1),        "disp_mm": round(pd_*.4,3),"pass": "Yes"},
        {"component": "Spring retainer", "stress_MPa": round(ps*.3,1),"allow": 828, "util%": round(ps*.3/828*100,1),        "disp_mm": round(pd_*.2,3),"pass": "Yes"},
        {"component": "Seat ring",       "stress_MPa": round(ps*.1,1),"allow":  11, "util%": round(ps*.1/11*100,1),         "disp_mm": round(pd_*.6,3),"pass": "Yes"},
    ]).to_csv(path, index=False)


def _csv_static_detail(path: Path, lc_i: int, det_i: int) -> None:
    ps = STATIC_PEAK_S[lc_i]; f = RESULT_FACTORS[det_i]
    pd.DataFrame([
        {"metric": "Location",        "value": RESULT_LOCATIONS[det_i]},
        {"metric": "Von Mises (MPa)", "value": round(ps * f, 1)},
        {"metric": "Principal (MPa)", "value": round(ps * f * 1.1, 1)},
        {"metric": "Shear (MPa)",     "value": round(ps * f * 0.55, 1)},
        {"metric": "Allowable (MPa)", "value": 376},
        {"metric": "Utilisation (%)", "value": round(ps * f / 376 * 100, 1)},
        {"metric": "Pass / Fail",     "value": "Pass"},
    ]).to_csv(path, index=False)


def _csv_harmonic_loads(path: Path, i: int) -> None:
    D = ["X", "Y", "Z"][i]
    pd.DataFrame([
        {"load_id": f"LD-H{i+1:02d}-01", "type": "Base Excitation",
         "direction": D, "amplitude_g": HARM_AMPLITUDES[i], "phase_deg": 0.0, "surface": "Flange base"},
        {"load_id": f"LD-H{i+1:02d}-02", "type": "Inertia Relief",
         "direction": D, "amplitude_g": HARM_AMPLITUDES[i], "phase_deg": 180.0, "surface": "All bodies"},
    ]).to_csv(path, index=False)


def _csv_harmonic_bc(path: Path, i: int) -> None:
    D = ["X", "Y", "Z"][i]
    pd.DataFrame([
        {"bc_id": f"BC-H{i+1:02d}-01", "type": "Fixed Support", "dof": "UX=UY=UZ=0", "surface": "Flange bolt holes"},
        {"bc_id": f"BC-H{i+1:02d}-02", "type": "Displacement",  "dof": f"U{D}≠0",    "surface": "Flange base"},
    ]).to_csv(path, index=False)


def _csv_harmonic_summary(path: Path, i: int) -> None:
    ps = HARM_PEAK_STRESS[i]; pd_ = HARM_PEAK_DISP[i]; pf = HARM_PEAK_FREQ[i]
    pd.DataFrame([
        {"component": "Valve body",      "peak_Hz": pf, "stress_MPa": ps,            "allow": 376, "util%": round(ps/376*100,1),            "disp_mm": pd_,            "pass": "Yes"},
        {"component": "Stem",            "peak_Hz": pf, "stress_MPa": round(ps*.6,1),"allow": 376, "util%": round(ps*.6/376*100,1),          "disp_mm": round(pd_*.4,3),"pass": "Yes"},
        {"component": "Spring retainer", "peak_Hz": pf, "stress_MPa": round(ps*.3,1),"allow": 828, "util%": round(ps*.3/828*100,1),          "disp_mm": round(pd_*.2,3),"pass": "Yes"},
    ]).to_csv(path, index=False)


def _csv_harmonic_detail(path: Path, hd_i: int, det_i: int) -> None:
    ps = HARM_PEAK_STRESS[hd_i]; f = RESULT_FACTORS[det_i]; pf = HARM_PEAK_FREQ[hd_i]
    pd.DataFrame([
        {"metric": "Location",            "value": RESULT_LOCATIONS[det_i]},
        {"metric": "Peak Freq (Hz)",      "value": pf},
        {"metric": "Von Mises (MPa)",     "value": round(ps * f, 1)},
        {"metric": "Utilisation (%)",     "value": round(ps * f / 376 * 100, 1)},
        {"metric": "Freq margin (%)",     "value": round((pf - 50) / 50 * 100, 1)},
        {"metric": "Amplification Q",     "value": 25.0},
        {"metric": "Pass / Fail",         "value": "Pass"},
    ]).to_csv(path, index=False)


# ─────────────────────────────────────────────────────────────────────────────
# YAML
# ─────────────────────────────────────────────────────────────────────────────

YAML_CONTENT = """\
title: "Structural Analysis Report — Static & Harmonic — Valve Rev B"

sections:
  # ═══════════════════════════════════════════════════════════════════
  # 1. Introduction
  # ═══════════════════════════════════════════════════════════════════
  - number: "1"
    Section_name: Introduction
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write seven to ten sentences introducing this combined static and
          harmonic structural analysis report. State the assembly, tool,
          number of static load cases, harmonic excitation directions,
          element and node counts. Use only JSON facts.
        para_input_from_json: report_meta

  # ═══════════════════════════════════════════════════════════════════
  # 2. FE Model Description
  # ═══════════════════════════════════════════════════════════════════
  - number: "2"
    Section_name: FE Model Description
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write five to seven sentences describing the FE model: elements,
          nodes, element types, and mesh quality. Reference Table 1 and
          Figure 1. Use only JSON facts.
        para_input_from_json: fem_model
      - kind: image
        img_path: images/mesh.png
        img_name: FE Mesh Overview — Valve Rev B
      - kind: table
        csv_path: tables/element_quality.csv
        caption: Element Quality Summary

  # ═══════════════════════════════════════════════════════════════════
  # 3. Static Analysis
  #    Outer repeat → keys of Static.Static_loads
  #    (add a key there → new section appears automatically)
  # ═══════════════════════════════════════════════════════════════════
  - number: "3"
    Section_name: Static Analysis
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write three to five sentences giving an overview of the static
          analysis covering all load cases. Use only JSON facts.
        para_input_from_json: report_meta

    sections:
      - kind: repeat
        instances_keys_from_json: "Static.Static_loads"
        number_start: 1
        template:
          Section_name: "{name}"
          sections:

            # 3.N.1  Loads ───────────────────────────────────────────
            - number: "1"
              Section_name: Loads
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write four to six sentences describing the loads for
                    the {name} load case. State pressure, surfaces, and
                    any thermal load. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_loads.{name}"
                - kind: table
                  csv_path: "tables/s_loads_{instance_name}.csv"
                  caption: "Applied Loads — {name}"

            # 3.N.2  Boundary Conditions ────────────────────────────
            - number: "2"
              Section_name: Boundary Conditions
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write three to five sentences on boundary conditions
                    for the {name} load case. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_boundary_condition.{name}"
                - kind: table
                  csv_path: "tables/s_bc_{instance_name}.csv"
                  caption: "Boundary Conditions — {name}"

            # 3.N.3  Results Summary ─────────────────────────────────
            - number: "3"
              Section_name: Results Summary
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write five to eight sentences summarising results for
                    {name}. State max von Mises, allowable, utilisation,
                    max displacement, and verdict. Use only JSON facts.
                  para_input_from_json_path: "Static.Static_result_summary.{name}"
                - kind: table
                  csv_path: "tables/s_summary_{instance_name}.csv"
                  caption: "Results Summary — {name}"

            # 3.N.4  Results Details (inner repeat over list) ─────────
            - number: "4"
              Section_name: Results Details
              sections:
                - kind: repeat
                  instances_list_from_json: "Static.Static_result_details.{name}"
                  template:
                    Section_name: "Detail {index_1} — {location}"
                    elements:
                      - kind: paragraph
                        mode: finetuned
                        para_prompt: >-
                          Write three to five sentences on the stress result
                          at {location} for {name}. State von Mises, principal,
                          shear, utilisation and verdict. Use only JSON facts.
                        para_input_from_json_path: "Static.Static_result_details.{name}.{index}"
                      - kind: image
                        img_path: "images/s_detail_{instance_name}_{index_1}.png"
                        img_name: "Stress Detail — {name} — {location}"
                      - kind: table
                        csv_path: "tables/s_detail_{instance_name}_{index_1}.csv"
                        caption: "Stress Detail — {name} — {location}"

  # ═══════════════════════════════════════════════════════════════════
  # 4. Harmonic Analysis
  #    Outer repeat → keys of Harmonic.Harmonic_Loads
  # ═══════════════════════════════════════════════════════════════════
  - number: "4"
    Section_name: Harmonic Analysis
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write three to five sentences giving an overview of the harmonic
          analysis covering all excitation directions. Use only JSON facts.
        para_input_from_json: report_meta
      - kind: table
        csv_path: tables/modal_frequencies.csv
        caption: Extracted Natural Frequencies (Modal Extraction)

    sections:
      - kind: repeat
        instances_keys_from_json: "Harmonic.Harmonic_Loads"
        number_start: 1
        template:
          Section_name: "{name}"
          sections:

            # 4.N.1  Loads ───────────────────────────────────────────
            - number: "1"
              Section_name: Loads
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write four to six sentences on the harmonic loads for
                    {name}. State amplitude, direction, frequency range,
                    phase, and surfaces. Use only JSON facts.
                  para_input_from_json_path: "Harmonic.Harmonic_Loads.{name}"
                - kind: table
                  csv_path: "tables/h_loads_{instance_name}.csv"
                  caption: "Harmonic Loads — {name}"

            # 4.N.2  Boundary Conditions ────────────────────────────
            - number: "2"
              Section_name: Boundary Conditions
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write three to five sentences on boundary conditions
                    for {name}. State fixed supports and excited DOF.
                    Use only JSON facts.
                  para_input_from_json_path: "Harmonic.Harmonic_Boundary_condition.{name}"
                - kind: table
                  csv_path: "tables/h_bc_{instance_name}.csv"
                  caption: "Boundary Conditions — {name}"

            # 4.N.3  Results Summary ─────────────────────────────────
            - number: "3"
              Section_name: Results Summary
              elements:
                - kind: paragraph
                  mode: finetuned
                  para_prompt: >-
                    Write five to eight sentences summarising harmonic
                    results for {name}. State peak frequency, max displacement,
                    max stress, utilisation, and verdict. Use only JSON facts.
                  para_input_from_json_path: "Harmonic.Harmonic_Result_Summary.{name}"
                - kind: image
                  img_path: "images/h_response_{instance_name}.png"
                  img_name: "Harmonic Frequency Response — {name}"
                - kind: table
                  csv_path: "tables/h_summary_{instance_name}.csv"
                  caption: "Results Summary — {name}"

            # 4.N.4  Results Details (inner repeat over list) ─────────
            - number: "4"
              Section_name: Results Details
              sections:
                - kind: repeat
                  instances_list_from_json: "Harmonic.Harmonic_Result_Details.{name}"
                  template:
                    Section_name: "Detail {index_1} — {location}"
                    elements:
                      - kind: paragraph
                        mode: finetuned
                        para_prompt: >-
                          Write three to five sentences on the harmonic
                          result at {location} for {name}. State peak frequency,
                          frequency margin, von Mises stress, utilisation,
                          and verdict. Use only JSON facts.
                        para_input_from_json_path: "Harmonic.Harmonic_Result_Details.{name}.{index}"
                      - kind: image
                        img_path: "images/h_detail_{instance_name}_{index_1}.png"
                        img_name: "Harmonic Detail — {name} — {location}"
                      - kind: table
                        csv_path: "tables/h_detail_{instance_name}_{index_1}.csv"
                        caption: "Harmonic Detail — {name} — {location}"

  # ═══════════════════════════════════════════════════════════════════
  # 5. Conclusion
  # ═══════════════════════════════════════════════════════════════════
  - number: "5"
    Section_name: Conclusion
    elements:
      - kind: paragraph
        mode: finetuned
        para_prompt: >-
          Write seven to ten sentences summarising conclusions for both
          the static and harmonic analyses. Confirm pass/fail for each,
          state worst-case utilisation, and give the overall recommendation.
          Use only JSON facts.
        para_input_from_json: conclusion
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    print("Building Combined Static + Harmonic sample assets …")

    tables = BUNDLE_DIR / "tables"
    images = BUNDLE_DIR / "images"
    for d in (tables, images): d.mkdir(parents=True, exist_ok=True)

    _build_template(BUNDLE_DIR / "template.docx")

    # Mesh + modal
    _fig(images / "mesh.png", "FE Mesh — Valve Rev B",
         "1,112,425 elements  |  1,760,037 nodes", (26, 58, 108))
    _csv_element_quality(tables / "element_quality.csv")
    _csv_modal(tables / "modal_frequencies.csv")

    # ── Static assets ────────────────────────────────────────────────────────
    print("  Static load cases …")
    for i, lc in enumerate(STATIC_LOAD_CASES):
        safe = _safe_id(lc)
        _csv_static_loads(tables / f"s_loads_{safe}.csv", i)
        _csv_static_bc(tables / f"s_bc_{safe}.csv", i)
        _csv_static_summary(tables / f"s_summary_{safe}.csv", i)
        for j in range(3):
            lbl = ["Bore fillet", "Thread root", "Bonnet face"][j]
            _fig(images / f"s_detail_{safe}_{j+1}.png",
                 f"Static Detail — {lc}", f"Location {j+1}: {lbl}",
                 STATIC_PALETTE[i])
            _csv_static_detail(tables / f"s_detail_{safe}_{j+1}.csv", i, j)
        print(f"    {lc} → done")

    # ── Harmonic assets ──────────────────────────────────────────────────────
    print("  Harmonic directions …")
    for i, hd in enumerate(HARMONIC_DIRS):
        safe = _safe_id(hd)
        _csv_harmonic_loads(tables / f"h_loads_{safe}.csv", i)
        _csv_harmonic_bc(tables / f"h_bc_{safe}.csv", i)
        _csv_harmonic_summary(tables / f"h_summary_{safe}.csv", i)
        _fig(images / f"h_response_{safe}.png",
             f"Harmonic Response — {hd}",
             f"Peak at {HARM_PEAK_FREQ[i]} Hz", HARMONIC_PALETTE[i])
        for j in range(3):
            lbl = ["Bore fillet", "Thread root", "Bonnet face"][j]
            _fig(images / f"h_detail_{safe}_{j+1}.png",
                 f"Harmonic Detail — {hd}", f"Location {j+1}: {lbl}",
                 HARMONIC_PALETTE[i])
            _csv_harmonic_detail(tables / f"h_detail_{safe}_{j+1}.csv", i, j)
        print(f"    {hd} → done")

    # bundle.json
    data = _build_json()
    (BUNDLE_DIR / "bundle.json").write_text(
        json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print("  bundle.json → done")

    # ZIP
    with zipfile.ZipFile(ZIP_PATH, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in BUNDLE_DIR.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=p.relative_to(BUNDLE_DIR).as_posix())
    print(f"  combined_report.zip → {ZIP_PATH}")

    YAML_PATH.write_text(YAML_CONTENT, encoding="utf-8")
    print(f"  combined_report.yaml → {YAML_PATH}")

    print("\nDone. Run:")
    print(f"  python -m docgen --zip {ZIP_PATH} --yaml {YAML_PATH} "
          f"--out example/combined_report.docx --no-llm")


if __name__ == "__main__":
    main()

"""Merge block-level OOXML from one Word document into another (formulas, paragraphs, tables)."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn


def append_body_from_external_docx(target: Document, source_path: Path) -> None:
    """Append every body block from ``source_path`` except the source section properties.

    Elements are inserted immediately before the target document's ``sectPr`` so they
    appear in the correct page flow. (``dst_body.append()`` would place them after
    ``sectPr``, which Word treats as content outside the last section.)

    Use small snippet .docx files (formula only, derivation only) created in Word so
    equations stay native. Embedded images or OLE in snippets may not resolve if they
    depend on the snippet file's package relationships.
    """
    src_doc = Document(str(source_path))
    dst_body = target._element.body
    # Find the sectPr to use as the insertion anchor
    sect_pr = dst_body.find(qn("w:sectPr"))
    for child in src_doc._element.body:
        if child.tag == qn("w:sectPr"):
            continue
        node = deepcopy(child)
        if sect_pr is not None:
            dst_body.insert(list(dst_body).index(sect_pr), node)
        else:
            dst_body.append(node)

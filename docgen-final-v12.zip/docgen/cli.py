from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

from docgen.docx_builder import build_docx
from docgen.llm import LLMLogContext
from docgen.models import DocumentConfig, ParagraphElement, SectionNode
from docgen.yaml_config import load_document_config
from docgen.zip_bundle import ZipBundle


# ─────────────────────────────────────────────────────────────────────────────
# Env loading — tries every sensible location so the file is always found
# ─────────────────────────────────────────────────────────────────────────────

def _load_env() -> None:
    """Load environment variables from .env / env files.

    Search order (all are loaded; later values override earlier ones):
      1. .env  in the current working directory
      2. env   in the current working directory   ← your file without the dot
      3. .env  next to the docgen package root
      4. env   next to the docgen package root
    """
    cwd = Path.cwd()
    repo_root = Path(__file__).resolve().parent.parent

    seen: set[Path] = set()
    candidates = [
        cwd / ".env",
        cwd / "env",
        repo_root / ".env",
        repo_root / "env",
    ]

    loaded: list[Path] = []
    for path in candidates:
        resolved = path.resolve()
        if path.is_file() and resolved not in seen:
            load_dotenv(path, override=True)
            loaded.append(path)
            seen.add(resolved)

    # Always also call the bare load_dotenv() so any system-level .env is picked up
    load_dotenv(override=False)

    if loaded:
        print(f"[docgen] Loaded env from: {', '.join(str(p) for p in loaded)}", flush=True)
    else:
        print("[docgen] Warning: no .env / env file found. Set model_path= before running.", flush=True)

    # Debug: show the three key variables (mask empty values)
    for key in ("model_path", "adapter_path", "cuda_device"):
        val = os.environ.get(key, "")
        display = val if val else "(not set)"
        print(f"[docgen]   {key} = {display}", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# Section progress printer
# ─────────────────────────────────────────────────────────────────────────────

def _count_paragraphs(node: SectionNode) -> int:
    n = sum(1 for el in node.elements if isinstance(el, ParagraphElement))
    for ch in node.children:
        n += _count_paragraphs(ch)
    return n


def _total_paragraphs(cfg: DocumentConfig) -> int:
    return sum(_count_paragraphs(s) for s in cfg.root_sections)


def _print_section_plan(cfg: DocumentConfig) -> None:
    """Print a summary of what will be generated before starting."""
    total_para = _total_paragraphs(cfg)
    print(f"\n[docgen] Document: {cfg.title!r}", flush=True)
    print(f"[docgen] Sections to generate:", flush=True)

    def _walk(node: SectionNode, indent: int = 2) -> None:
        prefix = " " * indent
        para_els = [e for e in node.elements if isinstance(e, ParagraphElement)]
        mode_summary = ""
        if para_els:
            modes = set(e.mode for e in para_els)
            mode_summary = f"  [{'/'.join(sorted(modes))} ×{len(para_els)}]"
        other = len(node.elements) - len(para_els)
        other_summary = f"  +{other} other elements" if other else ""
        print(f"[docgen] {prefix}{node.section_id}  {node.name}{mode_summary}{other_summary}", flush=True)
        for ch in node.children:
            _walk(ch, indent + 2)

    for root in cfg.root_sections:
        _walk(root)
    print(f"[docgen] Total LLM paragraphs: {total_para}", flush=True)
    print(flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main(argv: list[str] | None = None) -> int:
    _load_env()

    p = argparse.ArgumentParser(
        description="Generate a Word document from a ZIP bundle (JSON, CSVs, images) and input.yaml.",
    )
    p.add_argument("--zip",  required=True, type=Path, help="Path to uploaded ZIP archive.")
    p.add_argument("--yaml", required=True, type=Path, help="Path to structure template (input.yaml).")
    p.add_argument("--out",  required=True, type=Path, help="Output .docx path.")
    p.add_argument(
        "--no-llm",
        action="store_true",
        help="Do not call the local model (use stub paragraph text).",
    )
    p.add_argument(
        "--llm-log",
        type=Path,
        default=None,
        metavar="PATH",
        help="Custom path for the LLM trace file (default: llm_out.txt next to --out).",
    )
    p.add_argument(
        "--no-llm-log",
        action="store_true",
        help="Do not write an LLM trace file.",
    )
    args = p.parse_args(argv)

    # ── LLM log setup ──
    llm_log_ctx: LLMLogContext | None = None
    if not args.no_llm_log:
        log_path = args.llm_log if args.llm_log is not None else args.out.parent / "llm_out.txt"
        llm_log_ctx = LLMLogContext(log_path)
        llm_log_ctx.reset()
        llm_log_ctx.append(
            f"docgen LLM trace\n"
            f"Output document : {args.out.resolve()}\n"
            f"model_path      : {os.environ.get('model_path', '(not set)')}\n"
            f"adapter_path    : {os.environ.get('adapter_path', '(none)')}\n"
            f"cuda_device     : {os.environ.get('cuda_device', 'cuda:0')}\n"
            f"--no-llm        : {args.no_llm}\n\n"
        )

    # ── Load assets ──
    print("[docgen] Loading ZIP bundle ...", flush=True)
    bundle = ZipBundle.from_zip(args.zip)

    print("[docgen] Parsing YAML structure ...", flush=True)
    cfg = load_document_config(args.yaml, bundle_data=bundle.data)
    _print_section_plan(cfg)

    # ── Build ──
    print("[docgen] Building document ...", flush=True)
    build_docx(
        bundle,
        cfg,
        args.out,
        use_llm=not args.no_llm,
        llm_log_ctx=llm_log_ctx,
    )

    print(f"\n[docgen] ✓ Wrote {args.out.resolve()}", flush=True)
    if llm_log_ctx:
        print(f"[docgen] ✓ Wrote {llm_log_ctx.path.resolve()}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

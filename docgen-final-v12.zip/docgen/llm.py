"""docgen LLM backend — local model only (no cloud API).

Two generation modes
--------------------
finetuned  (default)
    Calls the fine-tuned model with an [INST] … [/INST] prompt.
    The model has been trained on domain examples so it generates directly.

cot
    Chain-of-Thought: builds a prompt from CoT examples defined in the YAML
    (question/thought/answer triplets) then appends the live question and asks
    the model to think step-by-step before writing the final paragraph.

The model and LoRA adapter are loaded **once** when the first paragraph is
generated and cached for the entire document build.

Environment (.env)
------------------
model_path=<path to HuggingFace model dir or GGUF file>
adapter_path=<path to LoRA adapter dir>   # optional
cuda_device=cuda:1                         # optional, default cuda:0
"""
from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# ─────────────────────────────────────────────────────────────────────────────
# Log context
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LLMLogContext:
    """Append-only log of all LLM calls for one document build."""

    path: Path
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _seq: int = 0

    def reset(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")
        self._seq = 0

    def next_seq(self) -> int:
        self._seq += 1
        return self._seq

    def append(self, text: str) -> None:
        with self._lock:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(text)


# ─────────────────────────────────────────────────────────────────────────────
# Model singleton  (loaded once per process)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class _ModelSingleton:
    tokenizer: Any = None
    model: Any = None
    loaded: bool = False
    load_error: str | None = None
    _lock: threading.Lock = field(default_factory=threading.Lock)


_MODEL = _ModelSingleton()


def _load_model_once() -> tuple[Any, Any] | None:
    """Load the HuggingFace model + optional LoRA adapter.

    Returns (tokenizer, model) on success, or None if unavailable.
    The result is cached — subsequent calls return immediately.
    """
    with _MODEL._lock:
        if _MODEL.loaded:
            return (_MODEL.tokenizer, _MODEL.model) if _MODEL.tokenizer else None

        model_path = os.environ.get("model_path", "").strip()
        adapter_path = os.environ.get("adapter_path", "").strip()
        cuda_device = os.environ.get("cuda_device", "cuda:0").strip() or "cuda:0"

        if not model_path:
            _MODEL.load_error = (
                "model_path is not set in .env — set model_path=/path/to/model"
            )
            _MODEL.loaded = True
            print(f"  [docgen] {_MODEL.load_error}", flush=True)
            return None

        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer

            print(f"  [docgen] Loading tokenizer from: {model_path}", flush=True)
            tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=True,
                use_fast=True,
            )
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token

            dtype = torch.float16 if torch.cuda.is_available() else torch.float32
            print(f"  [docgen] Loading model ({dtype}) on {cuda_device} ...", flush=True)
            model = AutoModelForCausalLM.from_pretrained(
                model_path,
                torch_dtype=dtype,
                device_map=cuda_device,
                trust_remote_code=True,
            )

            if adapter_path:
                print(f"  [docgen] Merging LoRA adapter: {adapter_path}", flush=True)
                from peft import PeftModel
                model = PeftModel.from_pretrained(model, adapter_path)
                model = model.merge_and_unload()

            model.eval()
            _MODEL.tokenizer = tokenizer
            _MODEL.model = model
            _MODEL.loaded = True
            print(f"  [docgen] Model ready on {cuda_device}", flush=True)
            return tokenizer, model

        except Exception as exc:  # noqa: BLE001
            _MODEL.load_error = str(exc)
            _MODEL.loaded = True
            print(f"  [docgen] Model load error: {exc}", flush=True)
            return None


# ─────────────────────────────────────────────────────────────────────────────
# Low-level inference
# ─────────────────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = (
    "You are a technical writer for formal engineering reports. "
    "Write concise, precise prose using only the facts provided. "
    "Do not invent specifications, measurements, or names. "
    "Use exact figure and table labels as given (e.g. 'Figure 1', 'Table 2')."
)


def _run_inference(prompt: str) -> str:
    """Pass a fully-built prompt string to the model and return new tokens only."""
    pair = _load_model_once()
    if pair is None:
        return f"[Model unavailable: {_MODEL.load_error or 'unknown'}]"

    tokenizer, model = pair
    import torch

    inputs = tokenizer(
        prompt,
        return_tensors="pt",
        truncation=True,
        max_length=2048,
    )
    input_ids = inputs["input_ids"].to(model.device)

    max_new = int(os.environ.get("DOCGEN_MAX_NEW_TOKENS", 512))
    temperature = float(os.environ.get("DOCGEN_TEMPERATURE", 0.3))
    top_p = float(os.environ.get("DOCGEN_TOP_P", 0.9))

    with torch.no_grad():
        output_ids = model.generate(
            input_ids,
            max_new_tokens=max_new,
            temperature=temperature,
            top_p=top_p,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )

    new_tokens = output_ids[0][input_ids.shape[-1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


# ─────────────────────────────────────────────────────────────────────────────
# Mode: finetuned  —  direct [INST] / [/INST] generation
# ─────────────────────────────────────────────────────────────────────────────

def _build_finetuned_prompt(prompt: str, json_context: dict[str, Any]) -> str:
    """Build the [INST] prompt that matches the fine-tuning data format."""
    domain = json_context.get("domain", "Structures")
    facts_str = json.dumps(json_context, ensure_ascii=False, indent=2)
    return (
        f"<s>[INST]\n"
        f"You are working in the domain of {domain}. "
        f"{prompt}\n\n"
        f"Input:\n{facts_str}\n"
        f"[/INST]"
    )


def _generate_finetuned(prompt: str, json_context: dict[str, Any]) -> str:
    return _run_inference(_build_finetuned_prompt(prompt, json_context))


# ─────────────────────────────────────────────────────────────────────────────
# Mode: cot  —  chain-of-thought with examples from YAML
# ─────────────────────────────────────────────────────────────────────────────

def _build_cot_prompt(
    prompt: str,
    json_context: dict[str, Any],
    cot_examples: list[dict[str, str]],
) -> str:
    """Build a Chain-of-Thought prompt using examples from the YAML.

    Each example dict must have:
        question  – the writing task
        thought   – step-by-step reasoning before writing
        answer    – the final paragraph

    The model is expected to continue the pattern by outputting
    ``Thought: ...\nAnswer: ...`` for the live question.
    """
    lines: list[str] = [
        "<s>[INST]",
        _SYSTEM_PROMPT,
        "",
        "You will reason step-by-step before writing (Chain-of-Thought).",
        "Always output exactly two sections: 'Thought:' then 'Answer:'.",
        "",
    ]

    for i, ex in enumerate(cot_examples, start=1):
        q = str(ex.get("question", "")).strip()
        t = str(ex.get("thought", "")).strip()
        a = str(ex.get("answer", "")).strip()
        lines += [
            f"### Example {i}",
            f"Question: {q}",
            f"Thought: {t}",
            f"Answer: {a}",
            "",
        ]

    facts_str = json.dumps(json_context, ensure_ascii=False, indent=2)
    lines += [
        "### Now write the following:",
        f"Question: {prompt}",
        f"Input facts:\n{facts_str}",
        "[/INST]",
        "Thought:",          # prime the model to start with Thought:
    ]
    return "\n".join(lines)


def _generate_cot(
    prompt: str,
    json_context: dict[str, Any],
    cot_examples: list[dict[str, str]],
) -> tuple[str, str]:
    """Run CoT inference. Returns (raw_output, extracted_answer)."""
    full_prompt = _build_cot_prompt(prompt, json_context, cot_examples)
    # Prepend "Thought:" because we primed the model with it
    raw = "Thought: " + _run_inference(full_prompt)

    if "Answer:" in raw:
        answer = raw.split("Answer:", 1)[-1].strip()
        # Trim any bleed-back into another Thought block
        if "Thought:" in answer:
            answer = answer.split("Thought:")[0].strip()
    else:
        # Model didn't follow format — return whole output as answer
        answer = raw.strip()

    return raw, answer


# ─────────────────────────────────────────────────────────────────────────────
# Stub (--no-llm)
# ─────────────────────────────────────────────────────────────────────────────

def _stub_paragraph(json_context: dict[str, Any], prompt: str) -> str:
    bits = ", ".join(
        f"{k}={v}" for k, v in list(json_context.items())[:6] if v is not None
    )
    return (
        f"[STUB — LLM disabled] Context: {bits}. "
        f"Instruction: {prompt[:200]}{'…' if len(prompt) > 200 else ''}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Log writer
# ─────────────────────────────────────────────────────────────────────────────

def _write_log_block(
    ctx: LLMLogContext,
    *,
    seq: int,
    mode: str,
    prompt_sent: str,
    facts_json: dict[str, Any],
    raw_output: str,
    final_text: str,
    error: str | None = None,
) -> None:
    lines = [
        "=" * 80,
        f"CALL #{seq}  {datetime.now(timezone.utc).isoformat()}",
        f"MODE: {mode}",
        f"model_path:   {os.environ.get('model_path', '(not set)')}",
        f"adapter_path: {os.environ.get('adapter_path', '(none)')}",
        f"cuda_device:  {os.environ.get('cuda_device', 'cuda:0')}",
        "",
        "--- Prompt sent to model ---",
        prompt_sent,
        "",
        "--- Facts JSON ---",
        json.dumps(facts_json, ensure_ascii=False, indent=2),
        "",
    ]
    if error:
        lines += ["--- Error ---", error, ""]
    lines += [
        "--- Raw model output ---",
        raw_output or "(empty)",
        "",
        "--- Final text written to Word document ---",
        final_text or "(empty)",
        "",
    ]
    ctx.append("\n".join(lines))


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def log_paragraph_disabled(
    ctx: LLMLogContext,
    *,
    instruction_prompt: str,
    facts_json: dict[str, Any],
    body: str,
) -> None:
    """Log a stub entry when --no-llm is active."""
    seq = ctx.next_seq()
    _write_log_block(
        ctx,
        seq=seq,
        mode="llm_disabled (--no-llm)",
        prompt_sent="(no request sent)",
        facts_json=facts_json,
        raw_output="",
        final_text=body,
        error="--no-llm flag set; no inference performed.",
    )


def generate_paragraph_sync(
    prompt: str,
    json_context: dict[str, Any],
    *,
    mode: str = "finetuned",
    cot_examples: list[dict[str, str]] | None = None,
    log_ctx: LLMLogContext | None = None,
    # Legacy keyword args kept for call-site compatibility (ignored)
    model: str | None = None,
    base_url: str | None = None,
) -> str:
    """Generate a paragraph using the local fine-tuned model.

    Parameters
    ----------
    prompt:
        Instruction string — what to write.
    json_context:
        Facts dict from bundle.json used as grounding input.
    mode:
        ``"finetuned"`` — direct [INST]/[/INST] generation (default).
        ``"cot"``       — Chain-of-Thought using cot_examples from YAML.
    cot_examples:
        List of {question, thought, answer} dicts. Required when mode="cot".
    log_ctx:
        Append-only log context; pass None to skip logging.
    """
    seq = log_ctx.next_seq() if log_ctx else 0
    mode = (mode or "finetuned").strip().lower()
    cot_examples = cot_examples or []

    error: str | None = None
    raw_output = ""
    final_text = ""
    prompt_sent = ""

    try:
        if mode == "cot" and not cot_examples:
            error = "mode=cot but cot_examples is empty — falling back to finetuned."
            mode = "finetuned"

        if mode == "cot":
            prompt_sent = _build_cot_prompt(prompt, json_context, cot_examples)
            raw_output, final_text = _generate_cot(prompt, json_context, cot_examples)
        else:
            prompt_sent = _build_finetuned_prompt(prompt, json_context)
            final_text = _generate_finetuned(prompt, json_context)
            raw_output = final_text

    except Exception as exc:  # noqa: BLE001
        error = (error + " " if error else "") + f"Runtime error: {exc}"
        final_text = _stub_paragraph(json_context, prompt)
        raw_output = ""
        prompt_sent = prompt_sent or prompt

    if log_ctx:
        _write_log_block(
            log_ctx,
            seq=seq,
            mode=mode,
            prompt_sent=prompt_sent,
            facts_json=json_context,
            raw_output=raw_output,
            final_text=final_text,
            error=error,
        )

    return final_text

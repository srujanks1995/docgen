# docgen

Generate a Word report (`.docx`) from:
- a **ZIP bundle** containing `bundle.json` + `tables/` + `images/` (+ optional `content/` and `.docx` math snippets)
- a **YAML template** describing the document structure

The generator also writes **`llm_out.txt`** (prompt + inputs + responses) next to the output document by default.

## Word template (header/footer + pre-existing pages)

If the ZIP bundle contains **exactly one `.docx` file**, `docgen` uses it as the **base template** (so the report keeps the template's **header and footer**). Any body content inside the template is cleared before writing the generated report content.

### Template with title page and index page

If your template already has a **title page (page 1)** and an **index/TOC page (page 2)**, pass `--template-pages 2` (which is the **default**). `docgen` will insert two page-breaks at the start so all generated content — List of Tables, List of Figures, and body sections — begins on **page 3**.

```powershell
# default (template has title on page 1, index on page 2 → content starts page 3)
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx

# template has only a title page (content starts page 2)
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --template-pages 1

# no pre-existing template pages
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --template-pages 0
```

## List of Figures / List of Tables (with page numbers)

`docgen` automatically generates a **List of Tables** and **List of Figures** with:
- Clickable hyperlinks to each figure/table in the document body
- Dot-leader (`........`) separating the caption from the page number
- **PAGEREF** page numbers — these update automatically when you open the document in Word and press `Ctrl+A → F9` (or print/save as PDF)

These lists are placed at the start of the generated content (page 3 when using the default `--template-pages 2`).

## How to run (example report ~10 pages)

From the repo root:

```powershell
python -m pip install -e ".[dev]"
python tools\build_example.py
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx
```

Outputs:
- `example\report.docx`
- `example\llm_out.txt`

## LLM configuration (`.env`)

Create/update `.env` in the repo root (it is gitignored).

### Option A: Google Gemini API (default)

```ini
DOCGEN_LLM_SOURCE=api
GEMINI_API_KEY=YOUR_KEY
```

Optional:

```ini
GEMINI_MODEL=gemini-2.0-flash
GEMINI_API_BASE=https://generativelanguage.googleapis.com/v1beta
```

### Option B: Local model command (model path + adapter path)

`docgen` can call a **local command** that reads a JSON request from stdin and prints the generated text to stdout.

```ini
DOCGEN_LLM_SOURCE=local
DOCGEN_LOCAL_LLM_COMMAND=python tools/local_llm_runner.py
DOCGEN_LOCAL_MODEL_PATH=C:\models\my-model.gguf
DOCGEN_LOCAL_ADAPTER_PATH=C:\models\my-adapter.safetensors
```

Notes:
- `DOCGEN_LOCAL_ADAPTER_PATH` is optional (use it for fine-tuned/LoRA adapters).
- The local command receives these environment variables:
  - `DOCGEN_LOCAL_MODEL_PATH`
  - `DOCGEN_LOCAL_ADAPTER_PATH`

### No LLM (stub text)

```powershell
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --no-llm
```

## LLM trace file (`llm_out.txt`)

By default, `docgen` writes `llm_out.txt` next to `--out`.

You can override or disable it:

```powershell
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --llm-log example\my_trace.txt
python -m docgen --zip example\report.zip --yaml example\report.yaml --out example\report.docx --no-llm-log
```

## CLI reference

| Flag | Default | Description |
|------|---------|-------------|
| `--zip` | *(required)* | Path to the ZIP bundle |
| `--yaml` | *(required)* | Path to the YAML structure template |
| `--out` | *(required)* | Output `.docx` path |
| `--template-pages` | `2` | Pages already in the template to skip (title=1, index=2) |
| `--no-llm` | off | Disable LLM calls; use stub text |
| `--llm-log` | `llm_out.txt` | Custom path for LLM trace file |
| `--no-llm-log` | off | Disable LLM trace file |

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal  # noqa: F401


@dataclass
class ParagraphElement:
    kind: Literal["paragraph"] = "paragraph"
    prompt: str = ""
    json_key: str = ""          # top-level key in bundle.json
    json_path: str = ""         # dot-path e.g. "Static.Static_loads.Static_Structural"
    mode: str = "finetuned"     # "finetuned" | "cot"
    cot_examples: list[dict] = field(default_factory=list)


@dataclass
class FileParagraphElement:
    """Body text loaded verbatim from a UTF-8 file inside the ZIP (no LLM)."""
    kind: Literal["paragraph_file"] = "paragraph_file"
    text_path: str = ""


@dataclass
class TableElement:
    kind: Literal["table"] = "table"
    csv_path: str = ""
    caption: str = ""


@dataclass
class MultiTableElement:
    """Multiple CSV tables rendered sequentially, each with its own caption.

    YAML example::

        - kind: multi_table
          tables:
            - csv_path: tables/stress_x.csv
              caption: Stress Results — X Direction
            - csv_path: tables/stress_y.csv
              caption: Stress Results — Y Direction
    """
    kind: Literal["multi_table"] = "multi_table"
    tables: list[TableElement] = field(default_factory=list)


@dataclass
class ImageElement:
    """A figure to embed in the report.

    Two mutually-exclusive sourcing modes:

    1. **Direct** (``img_path``): a fixed path to a PNG/JPG in the ZIP.
       ``caption`` is used as-is.

    2. **JSON-driven** (``json_path``): a dot-path into bundle.json (may
       contain ``{var}`` placeholders already substituted at parse time,
       e.g. from an outer ``repeat`` block)::

           kind: image
           para_input_from_json_path: "Harmonic.Harmonic_Result_Summary.{name}"

       At render time the node found at that path is searched recursively
       for **any** key whose name contains ``figure_id`` (e.g.
       ``figure_id``, ``stress_figure_id``, ``response_figure_id``) with a
       non-null value. Each such id is looked up by exact match against the
       ``Updated Figure Number`` column of ``tables/figure_name.csv``; the
       matching row's ``Name`` column gives the image file to embed and its
       ``Caption`` column gives the figure caption. If the JSON node
       contains multiple figure ids (nested and/or inside a list), every
       one of them is placed as its own figure, in the order encountered.
       If no ids resolve, no image is placed for this element.
    """
    kind: Literal["image"] = "image"
    img_path: str = ""
    caption: str = ""
    json_path: str = ""   # dot-path into bundle.json for JSON-driven figure lookup


@dataclass
class MathBlockElement:
    """Formula authored in Word, supplied as .docx snippet files in the ZIP."""
    kind: Literal["math"] = "math"
    docx_path: str = ""
    derivation_docx_paths: list[str] = field(default_factory=list)
    caption: str = ""


@dataclass
class PatternRepeatElement:
    """Repeat an image and/or table block for every matched file in the ZIP.

    Two matching modes — use one or both:

    **ends-with** (``img_pattern`` / ``csv_pattern``):
        Matches any file whose stem *ends with* the pattern string.
        Files are sorted alphabetically.

    **starts-with + numeric index** (``img_prefix`` / ``csv_prefix``):
        Matches files whose path starts with the prefix.
        If the prefix contains ``{index}``, the ``{index}`` portion is
        treated as a numeric placeholder: files are matched by replacing
        ``{index}`` with any integer and are then **sorted numerically**
        by that captured index, so ``_01``, ``_2``, ``_10`` sort as
        1 → 2 → 10 (not lexicographic).

        Example::

            img_prefix: "images/s_detail_{instance_name}_{index}_"
            # matches: images/s_detail_lc1_1_stress.png
            #          images/s_detail_lc1_2_disp.png
            #          images/s_detail_lc1_10_strain.png
            # sorted numerically by {index}: 1, 2, 10

    **{instance_name} substitution** — all ``{var}`` placeholders except
    ``{index}`` are substituted from the outer repeat vars before matching.

    **Caption control** — three options (evaluated in order):

    ``caption_parts`` (list of ints):
        Pick parts from the file stem split by ``_``.  1-based index.
        ``abc_def_hij_klm_nop.png`` with ``caption_parts: [2, 4]``
        → ``"def klm"``

    ``caption_template`` (string, optional, used with ``caption_parts``):
        Controls how the selected parts and repeat-vars are combined.
        Available placeholders:
          ``{part}``          — the joined selected parts (space-separated)
          ``{instance_name}`` — outer repeat instance id
          ``{name}``          — outer repeat instance display name
          ``{stem}``          — full stem with ``_`` → space
        Example::

            caption_parts: [3, 5]
            caption_template: "{part} — {name}"
            # s_loads_lc1_stress_disp.png → "stress disp — Load Case 1"

        If omitted, just the joined parts are used.

    ``caption`` (string):
        A free template string when ``caption_parts`` is not used.
        Supports ``{instance_name}``, ``{name}``, ``{stem}``.
        Example: ``"Load — {name}"``

    *(neither)*:
        Full stem with underscores replaced by spaces.
    """
    kind: Literal["pattern_repeat"] = "pattern_repeat"
    img_pattern: str = ""
    csv_pattern: str = ""
    img_prefix: str = ""
    csv_prefix: str = ""
    caption: str = ""
    caption_parts: list = field(default_factory=list)
    caption_template: str = ""


DocElement = (
    ParagraphElement
    | FileParagraphElement
    | TableElement
    | MultiTableElement
    | ImageElement
    | MathBlockElement
    | PatternRepeatElement
)


@dataclass
class SectionNode:
    """Hierarchical section node (supports arbitrary depth via section_id dotted path)."""
    section_id: str          # e.g. "3.6.1"
    name: str
    elements: list[DocElement] = field(default_factory=list)
    children: list["SectionNode"] = field(default_factory=list)
    json_vars: dict[str, str] = field(default_factory=dict)
    """Mapping of variable name → JSON dot-path, resolved from bundle.json.
    Values are substituted into Section_name and element templates.
    Example::

        json_vars:
          component_name: fem_model.component
          solver: fem_model.fem_analysis.solver
        Section_name: "{component_name} — {solver} Analysis"
    """


@dataclass
class DocumentConfig:
    title: str
    root_sections: list[SectionNode]

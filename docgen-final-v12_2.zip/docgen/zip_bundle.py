from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path
from typing import Any


class ZipBundle:
    """Extracted upload: JSON dict, resolved paths for CSVs and images."""

    def __init__(self, root: Path, data: dict[str, Any]) -> None:
        self.root = root
        self.data = data

    @classmethod
    def from_zip(cls, zip_path: Path) -> ZipBundle:
        tmp = Path(tempfile.mkdtemp(prefix="docgen_zip_"))
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(tmp)

        json_files = list(tmp.rglob("*.json"))
        if not json_files:
            raise ValueError("ZIP must contain exactly one JSON file (none found).")
        if len(json_files) > 1:
            raise ValueError(
                "ZIP must contain exactly one JSON file "
                f"(found {len(json_files)}: {[str(p) for p in json_files]})."
            )
        with open(json_files[0], encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("Root JSON must be an object (dictionary).")
        return cls(tmp, data)

    def find_template_docx(self) -> Path | None:
        """Return the Word template .docx from the ZIP, if one can be identified.

        Detection order (first match wins):
        1. A file named exactly ``template.docx`` anywhere in the ZIP.
        2. A file whose name contains ``template`` (case-insensitive).
        3. Any single .docx when the ZIP contains exactly one .docx.

        Files inside a ``formulas/`` or ``math/`` subdirectory are excluded so
        that formula snippets do not interfere with template detection.
        """
        all_docxs = list(self.root.rglob("*.docx"))
        # Exclude formula/math snippet subdirectories
        candidates = [
            p for p in all_docxs
            if not any(part.lower() in ("formulas", "math", "equations")
                       for part in p.relative_to(self.root).parts[:-1])
        ]
        # 1. Exact name match
        for p in candidates:
            if p.name.lower() == "template.docx":
                return p
        # 2. Name contains "template"
        for p in candidates:
            if "template" in p.name.lower():
                return p
        # 3. Single non-formula .docx
        if len(candidates) == 1:
            return candidates[0]
        return None

    def match_pattern(self, pattern: str) -> list[Path]:
        """Return all files in the ZIP whose stem ends with *pattern* (sans extension).

        ``pattern`` is matched against the file stem (filename without extension),
        so  ``_loads_lc1``  matches  ``tables/s_loads_lc1.csv``  and
        ``images/h_loads_lc1.png``  regardless of directory or extension.

        The pattern is substituted with repeat-vars before this call, so e.g.
        ``_loads_{instance_name}`` becomes ``_loads_Static_Structural_2`` and
        then matches any file whose stem ends with that string.

        Files are returned sorted by full path so document order is deterministic.
        """
        pattern_norm = pattern.replace("\\", "/")
        results: list[Path] = []
        for p in sorted(self.root.rglob("*")):
            if not p.is_file():
                continue
            if p.stem.endswith(pattern_norm):
                results.append(p)
        return results
        """Resolve a path relative to ZIP root (POSIX or OS separators)."""
        rel_norm = rel.replace("\\", "/").lstrip("/")
        # try exact relative to root
        p = (self.root / rel_norm).resolve()
        if p.is_file():
            return p
        # basename match anywhere (helps messy zips)
        name = Path(rel_norm).name
        matches = list(self.root.rglob(name))
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ValueError(f"Ambiguous path {rel!r}: multiple files named {name!r}.")
        raise FileNotFoundError(f"Not found in ZIP: {rel!r}")
